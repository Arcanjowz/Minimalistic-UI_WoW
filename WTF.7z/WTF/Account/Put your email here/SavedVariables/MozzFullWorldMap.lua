
MozzFullWorldMap = {
	["Enabled"] = true,
	["transparency"] = 1,
	["Errata"] = {
	},
	["version"] = "v3.36.30304",
	["colorStyle"] = 0,
}
