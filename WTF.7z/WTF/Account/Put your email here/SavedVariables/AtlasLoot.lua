
AtlasLootOptions = nil
AtlasLootDB = {
	["profileKeys"] = {
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Kezan"] = {
			["AtlasType"] = "Unknown",
		},
	},
}
AtlasLootWishList = {
	["Shared"] = {
	},
	["Options"] = {
		["Arcanjo"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
	},
	["Own"] = {
		["Arcanjo"] = {
		},
	},
}
