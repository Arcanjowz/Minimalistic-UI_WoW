
WeakAurasOptionsSaved = {
	["locale"] = "enUS",
	["needsRebuild"] = true,
	["version"] = "5.20.2 Beta",
	["magnetAlign"] = true,
	["spellCache"] = {
	},
	["spellCacheStrings"] = true,
	["spellCacheAchievements"] = true,
	["build"] = "l�`0",
}
