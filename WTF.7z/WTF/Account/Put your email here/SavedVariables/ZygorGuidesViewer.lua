
ZygorGuidesViewerSettings = {
	["char"] = {
		["Arcanjo - Kezan"] = {
			["taxis"] = {
			},
			["maint_fetchitemdata"] = true,
			["maint_fetchquestdata"] = true,
			["starting"] = false,
			["debuglog"] = {
				"18:12:01> Viewer started. ---------------------------", -- [1]
				"18:12:03> PLAYER_ENTERING_WORLD (dead?)", -- [2]
				"18:12:03> PLAYER_ALIVE (dead?)", -- [3]
				"18:12:03> CacheQuestLog cached 0 quests", -- [4]
				"18:12:04> Got completed quests list", -- [5]
				"18:12:04> CacheQuestLog cached 0 quests", -- [6]
				"18:12:04> CacheQuestLog cached 9 quests", -- [7]
				"18:12:04> New Quest: Just Desserts id 26768", -- [8]
				"18:12:04> New Quest: Princess Must Die! id 88", -- [9]
				"18:12:04> New Quest: Cloth and Leather Armor id 59", -- [10]
				"18:12:04> New Quest: Protect the Frontier id 52", -- [11]
				"18:12:04> New Quest: Report to Gryan Stoutmantle id 109", -- [12]
				"18:12:04> New Quest: Westbrook Garrison Needs Help! id 239", -- [13]
				"18:12:04> New Quest: Snatch and Grab id 2206", -- [14]
				"18:12:04> New Quest: Humble Beginnings id 399", -- [15]
				"18:12:04> New Quest: Stormpike's Delivery id 353", -- [16]
				"18:12:04> ZONE_CHANGED_NEW_AREA (dead?)", -- [17]
				"18:12:04> Guides loaded. -----", -- [18]
				"18:12:05> CacheQuestLog cached 9 quests", -- [19]
			},
		},
	},
	["profileKeys"] = {
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Kezan"] = {
			["arrowcam"] = false,
			["arrowsmooth"] = true,
		},
	},
}
