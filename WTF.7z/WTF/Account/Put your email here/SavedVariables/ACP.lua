
ACP_Data = {
	["sorter"] = "Group By Name",
	["NoRecurse"] = false,
	["NoChildren"] = true,
	["collapsed"] = {
	},
	["ProtectedAddons"] = {
		["ACP"] = true,
	},
}
