
AUCTIONATOR_SAVEDVARS = {
	["_200000"] = 1000,
	["_50000"] = 500,
	["STARTING_DISCOUNT"] = 5,
	["_1000000"] = 2500,
	["_5000000"] = 10000,
	["_500"] = 5,
	["_10000"] = 200,
	["_2000"] = 100,
}
AUCTIONATOR_PRICING_HISTORY = {
}
AUCTIONATOR_SHOPPING_LISTS = nil
AUCTIONATOR_PRICE_DATABASE = {
	["__dbversion"] = 2,
	["Kezan_Alliance"] = {
	},
}
AUCTIONATOR_LAST_SCAN_TIME = nil
AUCTIONATOR_TOONS = {
	["Arcanjo"] = {
		["firstSeen"] = 1755568640,
		["guid"] = "0x000000000000887D",
		["firstVersion"] = "2.6.3",
	},
}
AUCTIONATOR_STACKING_PREFS = {
}
AUCTIONATOR_SCAN_MINLEVEL = 1
