
WeakAurasArchive = {
	["RawData"] = {
	},
	["ReadOnly"] = {
	},
	["Repository"] = {
		["migration"] = {
			["timestamp"] = 1755568671,
			["version"] = 1,
			["data"] = "lUIlj)IsTyRuZiD0rnd1bWp",
		},
	},
}
