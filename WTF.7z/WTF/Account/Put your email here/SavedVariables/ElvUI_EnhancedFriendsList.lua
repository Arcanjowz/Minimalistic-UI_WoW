
EnhancedFriendsListDB = {
	["Kezan"] = {
		["Gaff"] = {
			3, -- [1]
			"Hunter", -- [2]
			"Elwynn Forest", -- [3]
			"1755570289", -- [4]
		},
		["Hallelujaah"] = {
			13, -- [1]
			"Paladin", -- [2]
			"Ragefire Chasm", -- [3]
			"1755739205", -- [4]
		},
		["Mariewiz"] = {
			3, -- [1]
			"Mage", -- [2]
			"Elwynn Forest", -- [3]
			"1755570399", -- [4]
		},
	},
}
