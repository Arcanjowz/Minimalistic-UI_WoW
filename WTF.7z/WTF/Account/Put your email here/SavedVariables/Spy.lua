
SpyDB = {
	["kosData"] = {
		["Kezan"] = {
			["Alliance"] = {
				["Arcanjo"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["Kezan"] = {
			["Alliance"] = {
			},
		},
	},
	["profileKeys"] = {
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Kezan"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 192.9999855702925,
					["x"] = 433.0000063600133,
					["w"] = 141.9999993161276,
					["h"] = 45.00000280387682,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
		},
	},
}
