
Broker_ItemRackConfig = {
	["MenuOrientation"] = "VERTICAL",
	["EnableEvents"] = "ON",
}
