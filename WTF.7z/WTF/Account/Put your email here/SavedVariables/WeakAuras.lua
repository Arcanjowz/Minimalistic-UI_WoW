
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["editor_tab_spaces"] = 4,
	["displays"] = {
	},
	["lastUpgrade"] = 1755568639,
	["lastArchiveClear"] = 1755568638,
	["minimap"] = {
		["minimapPos"] = 247.4464128959077,
		["hide"] = false,
	},
	["historyCutoff"] = 730,
	["dbVersion"] = 85,
	["migrationCutoff"] = 730,
	["registered"] = {
	},
	["editor_font_size"] = 12,
	["features"] = {
	},
	["login_squelch_time"] = 10,
}
