
PB_DB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Arcanjo - Kezan"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
