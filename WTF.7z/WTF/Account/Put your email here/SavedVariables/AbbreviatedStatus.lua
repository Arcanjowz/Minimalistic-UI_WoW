
AbbreviatedStatusDB = {
	["profileKeys"] = {
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["global"] = {
		{
			["pet"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["player"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["party"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["prefix"] = 3,
			["focus"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["target"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["arena"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["remainder"] = 1,
			["version"] = "1.2.1",
		}, -- [1]
	},
}
