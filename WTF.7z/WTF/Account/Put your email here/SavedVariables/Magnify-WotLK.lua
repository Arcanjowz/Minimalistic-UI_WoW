
MagnifyOptions = {
	["enablePersistZoom"] = false,
	["enableOldPartyIcons"] = false,
}
