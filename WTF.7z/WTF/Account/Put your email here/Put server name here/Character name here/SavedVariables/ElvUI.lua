
ElvCharacterDB = {
	["ChatEditHistory"] = {
		"/lootinfo", -- [1]
		"/s gg", -- [2]
		"/p gz", -- [3]
		"/p hardest quest ever", -- [4]
		"/p why have so many ppl :(", -- [5]
		"/p yeah", -- [6]
		"/p are u done?", -- [7]
		"/p Im done here", -- [8]
		"/p gg", -- [9]
		"/p gl", -- [10]
	},
	["ChatHistoryLog"] = {
		{
			"LFG RFC hunter", -- [1]
			"Dragonfury", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Dragonfury", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4742, -- [11]
			"0x000000000000219C", -- [12]
			0, -- [13]
			[51] = 1755739685,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Dragonfury|r",
		}, -- [1]
		{
			"Tank LFG WC", -- [1]
			"Percius", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Percius", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4743, -- [11]
			"0x00000000000035C3", -- [12]
			0, -- [13]
			[51] = 1755739685,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaPercius|r",
		}, -- [2]
		{
			"rfc lvl 16 lock ", -- [1]
			"Afflictive", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Afflictive", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4747, -- [11]
			"0x000000000000C4EA", -- [12]
			0, -- [13]
			[51] = 1755739692,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Afflictive|r",
		}, -- [3]
		{
			"{diamond} <V O I D> {diamond} SEMI-HC || NA || XFACTION || TUE/TH 9-12 EST || SR LOOT SYSTEM || Experienced guild structure looking to fill Raid 1. Casuals/Socials welcome.", -- [1]
			"Deadgenius", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Deadgenius", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4749, -- [11]
			"0x0000000000005096", -- [12]
			0, -- [13]
			[51] = 1755739692,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefDeadgenius|r",
		}, -- [4]
		{
			"lf tank heals RFK", -- [1]
			"Drtyblumpkin", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Drtyblumpkin", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4755, -- [11]
			"0x0000000000005B53", -- [12]
			0, -- [13]
			[51] = 1755739697,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dDrtyblumpkin|r",
		}, -- [5]
		{
			"26 Mage LFG BFD / Stocks", -- [1]
			"Dwarvenkilla", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Dwarvenkilla", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4761, -- [11]
			"0x0000000000000482", -- [12]
			0, -- [13]
			[51] = 1755739700,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefDwarvenkilla|r",
		}, -- [6]
		{
			"Guild latina <Blasphemy> Recluta gente que le interese formar parte de una buena comunidad con amplia trayectoria en wow, en sus diferentes versiones, todos son bienvenidos, tenemos discord armado y mucho hype. ", -- [1]
			"Gorilita", -- [2]
			"", -- [3]
			"5. World", -- [4]
			"Gorilita", -- [5]
			"", -- [6]
			30, -- [7]
			5, -- [8]
			"World", -- [9]
			0, -- [10]
			4765, -- [11]
			"0x000000000000E852", -- [12]
			0, -- [13]
			[51] = 1755739702,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dGorilita|r",
		}, -- [7]
		{
			"TANK LFG WC", -- [1]
			"Appranax", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Appranax", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4766, -- [11]
			"0x000000000000EED5", -- [12]
			0, -- [13]
			[51] = 1755739705,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaAppranax|r",
		}, -- [8]
		{
			"moog city 2 or wet hands", -- [1]
			"Sleepy", -- [2]
			"", -- [3]
			"5. World", -- [4]
			"Sleepy", -- [5]
			"", -- [6]
			30, -- [7]
			5, -- [8]
			"World", -- [9]
			0, -- [10]
			4767, -- [11]
			"0x0000000000003216", -- [12]
			0, -- [13]
			[51] = 1755739706,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aSleepy|r",
		}, -- [9]
		{
			"pet taming has failed 6 times in a row, is this normal?", -- [1]
			"Aesdana", -- [2]
			"", -- [3]
			"5. World", -- [4]
			"Aesdana", -- [5]
			"", -- [6]
			30, -- [7]
			5, -- [8]
			"World", -- [9]
			0, -- [10]
			4771, -- [11]
			"0x00000000000193A4", -- [12]
			0, -- [13]
			[51] = 1755739708,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Aesdana|r",
		}, -- [10]
		{
			"anyone know how to do this quest? |cffffff00|Hquest:26769:8|h[Just Desserts]|h|r", -- [1]
			"Marco", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Marco", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4773, -- [11]
			"0x0000000000005082", -- [12]
			0, -- [13]
			[51] = 1755739711,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffMarco|r",
		}, -- [11]
		{
			"22 DPS LFG DM", -- [1]
			"Leeox", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Leeox", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			4774, -- [11]
			"0x000000000000F688", -- [12]
			0, -- [13]
			[51] = 1755739711,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddLeeox|r",
		}, -- [12]
		{
			"LFG DPS - DM", -- [1]
			"Blowa", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Blowa", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			10, -- [11]
			"0x00000000000049F0", -- [12]
			0, -- [13]
			[51] = 1755897126,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Blowa|r",
		}, -- [13]
		{
			"LF1M Ring of Strength 1Heal", -- [1]
			"Conditions", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Conditions", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			11, -- [11]
			"0x0000000000002D77", -- [12]
			0, -- [13]
			[51] = 1755897128,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaConditions|r",
		}, -- [14]
		{
			"WTS |cff1eff00|Hitem:13926:0:0:0:0:0:0:0:44|h[Golden Pearl]|h|r", -- [1]
			"Gnometta", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Gnometta", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			12, -- [11]
			"0x00000000000021D0", -- [12]
			0, -- [13]
			[51] = 1755897128,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefGnometta|r",
		}, -- [15]
		{
			"dps LFG WC", -- [1]
			"Soleus", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Soleus", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			13, -- [11]
			"0x0000000000006D04", -- [12]
			0, -- [13]
			[51] = 1755897129,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Soleus|r",
		}, -- [16]
		{
			"LFM Glittermurk need all", -- [1]
			"Hersh", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Hersh", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			14, -- [11]
			"0x000000000000094F", -- [12]
			0, -- [13]
			[51] = 1755897130,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Hersh|r",
		}, -- [17]
		{
			"LOL", -- [1]
			"Priority", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Priority", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			15, -- [11]
			"0x0000000000001971", -- [12]
			0, -- [13]
			[51] = 1755897132,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddPriority|r",
		}, -- [18]
		{
			" |cff1eff00|Hitem:60200:0:0:0:0:0:0:0:16|h[Conjured Dagger]|h|r What is this for", -- [1]
			"Yareyaredaze", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Yareyaredaze", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			16, -- [11]
			"0x0000000000018D34", -- [12]
			0, -- [13]
			[51] = 1755897132,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefYareyaredaze|r",
		}, -- [19]
		{
			"Raining in game, Raining IRL= Max Comfy", -- [1]
			"Mabon", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Mabon", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			17, -- [11]
			"0x000000000000C8D3", -- [12]
			0, -- [13]
			[51] = 1755897132,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dMabon|r",
		}, -- [20]
		{
			"LFG ST", -- [1]
			"Laesir", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Laesir", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			18, -- [11]
			"0x0000000000011075", -- [12]
			0, -- [13]
			[51] = 1755897132,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dLaesir|r",
		}, -- [21]
		{
			"LFM DD WC", -- [1]
			"Jahbull", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Jahbull", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			19, -- [11]
			"0x00000000000041DA", -- [12]
			0, -- [13]
			[51] = 1755897133,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aJahbull|r",
		}, -- [22]
		{
			"LFM |cffff2020|Hquest:26803:23|h[Breaking the Armory]|h|r |cffff2020|Hquest:26825:24|h[Syndicate Magic]|h|r |cffff2020|Hquest:26830:26|h[WANTED: Beve Perenolde]|h|r", -- [1]
			"Weemace", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Weemace", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			20, -- [11]
			"0x000000000001B021", -- [12]
			0, -- [13]
			[51] = 1755897137,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaWeemace|r",
		}, -- [23]
		{
			"can someone link mats to |cff0070dd|Hitem:62121:0:0:0:0:0:0:0:1|h[Shiny Agate Ring]|h|r", -- [1]
			"Selselsel", -- [2]
			"", -- [3]
			"2. Trade - City", -- [4]
			"Selselsel", -- [5]
			"", -- [6]
			2, -- [7]
			2, -- [8]
			"Trade - City", -- [9]
			0, -- [10]
			21, -- [11]
			"0x000000000001685C", -- [12]
			0, -- [13]
			[51] = 1755897138,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Selselsel|r",
		}, -- [24]
		{
			"which warlock spec is best to lvl with?", -- [1]
			"Gustav", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Gustav", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			22, -- [11]
			"0x00000000000046C6", -- [12]
			0, -- [13]
			[51] = 1755897138,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Gustav|r",
		}, -- [25]
		{
			"Boats'n Hoes Boats'n Hoes", -- [1]
			"Puttblug", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Puttblug", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			23, -- [11]
			"0x00000000000151AC", -- [12]
			0, -- [13]
			[51] = 1755897139,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dPuttblug|r",
		}, -- [26]
		{
			"healer LFG SFK", -- [1]
			"Boog", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Boog", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			25, -- [11]
			"0x0000000000006398", -- [12]
			0, -- [13]
			[51] = 1755897141,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddBoog|r",
		}, -- [27]
		{
			"LFM DM need ALL + 20", -- [1]
			"Kjuba", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Kjuba", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			26, -- [11]
			"0x0000000000006E7D", -- [12]
			0, -- [13]
			[51] = 1755897146,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Kjuba|r",
		}, -- [28]
		{
			"LFG stockade melee dps", -- [1]
			"Eluon", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Eluon", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			29, -- [11]
			"0x000000000000870B", -- [12]
			0, -- [13]
			[51] = 1755897149,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Eluon|r",
		}, -- [29]
		{
			"hunter 31 lfg gnome", -- [1]
			"Culnamo", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Culnamo", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			32, -- [11]
			"0x0000000000000288", -- [12]
			0, -- [13]
			[51] = 1755897150,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Culnamo|r",
		}, -- [30]
		{
			"[RU]<Vroter Dam> Semi-hc Guild Ishet people dla osvoenia contenta https://discord.gg/eHpvDHQzKj", -- [1]
			"Egormashina", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Egormashina", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			34, -- [11]
			"0x0000000000002795", -- [12]
			0, -- [13]
			[51] = 1755897151,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaEgormashina|r",
		}, -- [31]
		{
			"LFM HEAL RFK LAST SLOT", -- [1]
			"Podguznik", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Podguznik", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			36, -- [11]
			"0x000000000000B3E3", -- [12]
			0, -- [13]
			[51] = 1755897153,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dPodguznik|r",
		}, -- [32]
		{
			"LF3M Glittermurk need all", -- [1]
			"Hersh", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Hersh", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			38, -- [11]
			"0x000000000000094F", -- [12]
			0, -- [13]
			[51] = 1755897154,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Hersh|r",
		}, -- [33]
		{
			"LF1M SFK NEED TANK", -- [1]
			"Vordray", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Vordray", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			39, -- [11]
			"0x00000000000000B6", -- [12]
			0, -- [13]
			[51] = 1755897155,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Vordray|r",
		}, -- [34]
		{
			"WTS |cff1eff00|Hitem:15230:0:0:0:0:0:1551:0:13|h[Ridge Cleaver of Power]|h|r", -- [1]
			"Garzoc", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Garzoc", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			41, -- [11]
			"0x0000000000015AA1", -- [12]
			0, -- [13]
			[51] = 1755897155,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Garzoc|r",
		}, -- [35]
		{
			"fastest destro chillest aff", -- [1]
			"Hellonasty", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Hellonasty", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			42, -- [11]
			"0x000000000001E373", -- [12]
			0, -- [13]
			[51] = 1755897156,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dHellonasty|r",
		}, -- [36]
		{
			"dps+heal 22lvl LFG WC", -- [1]
			"Parsnipirl", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Parsnipirl", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			43, -- [11]
			"0x0000000000004428", -- [12]
			0, -- [13]
			[51] = 1755897157,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aParsnipirl|r",
		}, -- [37]
		{
			"{skull}<Bulgarian Knights> {skull} is a Bulgarian casual cross-faction guild is recruiting members for leveling and dungeons! /w for inv || 100+ members", -- [1]
			"Zall", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Zall", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			44, -- [11]
			"0x0000000000002E01", -- [12]
			0, -- [13]
			[51] = 1755897157,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefZall|r",
		}, -- [38]
		{
			"DPS 34 LFG any SM", -- [1]
			"Seezy", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Seezy", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			46, -- [11]
			"0x0000000000005381", -- [12]
			0, -- [13]
			[51] = 1755897158,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Seezy|r",
		}, -- [39]
		{
			"dps lfg rfc", -- [1]
			"Xiji", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Xiji", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			48, -- [11]
			"0x000000000000627B", -- [12]
			0, -- [13]
			[51] = 1755897160,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefXiji|r",
		}, -- [40]
		{
			"last spot for RFK need DPS or TANK", -- [1]
			"Unholyholly", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Unholyholly", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			49, -- [11]
			"0x0000000000000C66", -- [12]
			0, -- [13]
			[51] = 1755897161,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaUnholyholly|r",
		}, -- [41]
		{
			"how change language ? ", -- [1]
			"Rabbitt", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Rabbitt", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			50, -- [11]
			"0x000000000001EC98", -- [12]
			0, -- [13]
			[51] = 1755897165,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aRabbitt|r",
		}, -- [42]
		{
			"Any GM online?", -- [1]
			"Ibororca", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Ibororca", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			51, -- [11]
			"0x00000000000072E6", -- [12]
			0, -- [13]
			[51] = 1755897165,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dIbororca|r",
		}, -- [43]
		{
			"WTS |cff0070dd|Hitem:13124:0:0:0:0:0:0:0:38|h[Ravasaur Scale Boots]|h|r", -- [1]
			"Tekkra", -- [2]
			"", -- [3]
			"2. Trade - City", -- [4]
			"Tekkra", -- [5]
			"", -- [6]
			2, -- [7]
			2, -- [8]
			"Trade - City", -- [9]
			0, -- [10]
			52, -- [11]
			"0x0000000000000250", -- [12]
			0, -- [13]
			[51] = 1755897166,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aTekkra|r",
		}, -- [44]
		{
			"Healer LFG SM CATH run or multiple", -- [1]
			"Episcopus", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Episcopus", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			53, -- [11]
			"0x0000000000000DB5", -- [12]
			0, -- [13]
			[51] = 1755897168,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffEpiscopus|r",
		}, -- [45]
		{
			"LF1M DM healer!", -- [1]
			"Bronzepact", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Bronzepact", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			54, -- [11]
			"0x000000000000CA67", -- [12]
			0, -- [13]
			[51] = 1755897168,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Bronzepact|r",
		}, -- [46]
		{
			"DPS LFG WC", -- [1]
			"Pawpawpew", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Pawpawpew", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			57, -- [11]
			"0x000000000000991B", -- [12]
			0, -- [13]
			[51] = 1755897173,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaPawpawpew|r",
		}, -- [47]
		{
			"EU {rt3} <Reborn> {rt3} We are an english speaking casual raiding guild looking for members for upcoming content, we plan to raid Sat/Sun at 18:00 CET, besides that all content will be enjoyed, we maintain a chill but mature vibe in chat. w/info", -- [1]
			"Vanguard", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Vanguard", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			58, -- [11]
			"0x000000000000070A", -- [12]
			0, -- [13]
			[51] = 1755897177,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dVanguard|r",
		}, -- [48]
		{
			"{star} <Team Træls> {star} Søger alle Danskere til at samle det Danske fælleskab på serveren. Vi har raidet siden 2018 Classic. Vi påbegynder raids straks så snart vi har nok i 60. Samtligt content clearet.", -- [1]
			"Junzo", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Junzo", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			59, -- [11]
			"0x000000000000717C", -- [12]
			0, -- [13]
			[51] = 1755897180,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Junzo|r",
		}, -- [49]
		{
			"LFM Uldaman", -- [1]
			"Ciggan", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Ciggan", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			60, -- [11]
			"0x0000000000005CD3", -- [12]
			0, -- [13]
			[51] = 1755897182,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefCiggan|r",
		}, -- [50]
		{
			"Anyone know where this guy is |cffff2020|Hquest:27217:20|h[Auntie VanCleef]|h|r? Steven Molsen", -- [1]
			"Redrice", -- [2]
			"", -- [3]
			"1. General - Stormwind City", -- [4]
			"Redrice", -- [5]
			"", -- [6]
			1, -- [7]
			1, -- [8]
			"General - Stormwind City", -- [9]
			0, -- [10]
			61, -- [11]
			"0x0000000000019BB3", -- [12]
			0, -- [13]
			[51] = 1755897187,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddRedrice|r",
		}, -- [51]
		{
			"where are glyphs from ? ?", -- [1]
			"Darnien", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Darnien", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			62, -- [11]
			"0x00000000000122F3", -- [12]
			0, -- [13]
			[51] = 1755897188,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefDarnien|r",
		}, -- [52]
		{
			"LF Tank Gnomer, All quests", -- [1]
			"Outward", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Outward", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			64, -- [11]
			"0x0000000000000E04", -- [12]
			0, -- [13]
			[51] = 1755897191,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaOutward|r",
		}, -- [53]
		{
			"LF1M SFK NEED TANK", -- [1]
			"Vordray", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Vordray", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			65, -- [11]
			"0x00000000000000B6", -- [12]
			0, -- [13]
			[51] = 1755897191,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Vordray|r",
		}, -- [54]
		{
			"You guys having fun?", -- [1]
			"Vyremage", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Vyremage", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			66, -- [11]
			"0x000000000002048E", -- [12]
			0, -- [13]
			[51] = 1755897193,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefVyremage|r",
		}, -- [55]
		{
			"LFG DM / WC 21 Lock", -- [1]
			"Yukav", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Yukav", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			67, -- [11]
			"0x000000000001C879", -- [12]
			0, -- [13]
			[51] = 1755897194,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Yukav|r",
		}, -- [56]
		{
			"DPS LFG DM", -- [1]
			"Juntaro", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Juntaro", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			68, -- [11]
			"0x00000000000153FB", -- [12]
			0, -- [13]
			[51] = 1755897195,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Juntaro|r",
		}, -- [57]
		{
			"LFM HEAL RFK LAST SLOT", -- [1]
			"Podguznik", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Podguznik", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			69, -- [11]
			"0x000000000000B3E3", -- [12]
			0, -- [13]
			[51] = 1755897197,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dPodguznik|r",
		}, -- [58]
		{
			"Nope", -- [1]
			"Mageforaday", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Mageforaday", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			70, -- [11]
			"0x000000000001950A", -- [12]
			0, -- [13]
			[51] = 1755897199,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefMageforaday|r",
		}, -- [59]
		{
			"Santa Claus", -- [1]
			"Ollo", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Ollo", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			71, -- [11]
			"0x0000000000016604", -- [12]
			0, -- [13]
			[51] = 1755897200,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aOllo|r",
		}, -- [60]
		{
			"yes", -- [1]
			"Talle", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Talle", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			72, -- [11]
			"0x00000000000001D3", -- [12]
			0, -- [13]
			[51] = 1755897201,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddTalle|r",
		}, -- [61]
		{
			"HOW DO I GET MY PFQUEST TO TRACK EPOCH QUESTS?", -- [1]
			"Sybaun", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Sybaun", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			73, -- [11]
			"0x000000000001E71A", -- [12]
			0, -- [13]
			[51] = 1755897202,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefSybaun|r",
		}, -- [62]
		{
			"can any1 help me with some paladin quest info |cffff2020|Hquest:26310:25|h[Trial of the Willing]|h|r ?", -- [1]
			"Psofoklanhs", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Psofoklanhs", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			74, -- [11]
			"0x0000000000017888", -- [12]
			0, -- [13]
			[51] = 1755897202,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaPsofoklanhs|r",
		}, -- [63]
		{
			"Healer 19 lfg WC", -- [1]
			"Moolas", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Moolas", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			75, -- [11]
			"0x0000000000001ED9", -- [12]
			0, -- [13]
			[51] = 1755897205,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aMoolas|r",
		}, -- [64]
		{
			"LFM DM need ALL + 20 2/5", -- [1]
			"Kjuba", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Kjuba", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			76, -- [11]
			"0x0000000000006E7D", -- [12]
			0, -- [13]
			[51] = 1755897205,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Kjuba|r",
		}, -- [65]
		{
			"LF1DPS SM GY!", -- [1]
			"Nocc", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Nocc", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			77, -- [11]
			"0x000000000000022A", -- [12]
			0, -- [13]
			[51] = 1755897206,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dNocc|r",
		}, -- [66]
		{
			"Hunter or shaman?", -- [1]
			"Brai", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Brai", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			78, -- [11]
			"0x000000000001E612", -- [12]
			0, -- [13]
			[51] = 1755897208,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddBrai|r",
		}, -- [67]
		{
			"26 dps shaman LFG BFD (can summ)", -- [1]
			"Wfproc", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Wfproc", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			79, -- [11]
			"0x000000000000E37C", -- [12]
			0, -- [13]
			[51] = 1755897209,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddWfproc|r",
		}, -- [68]
		{
			"WTS |cff0070dd|Hitem:4446:0:0:0:0:0:0:0:28|h[Blackvenom Blade]|h|r 2.5g", -- [1]
			"Prowling", -- [2]
			"", -- [3]
			"2. Trade - City", -- [4]
			"Prowling", -- [5]
			"", -- [6]
			2, -- [7]
			2, -- [8]
			"Trade - City", -- [9]
			0, -- [10]
			80, -- [11]
			"0x000000000000CBC1", -- [12]
			0, -- [13]
			[51] = 1755897210,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Prowling|r",
		}, -- [69]
		{
			"Healer LFG SM CATH run or multiple", -- [1]
			"Episcopus", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Episcopus", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			81, -- [11]
			"0x0000000000000DB5", -- [12]
			0, -- [13]
			[51] = 1755897213,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffEpiscopus|r",
		}, -- [70]
		{
			"[Aube] recrute ! Guilde cross-faction conviviale, raids,Donjons, entraide et bonne humeur au rendez-vous. Rejoins-nous à l’aube d’une nouvelle aventure ! /w pour plus d’infos.", -- [1]
			"Lazarglace", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Lazarglace", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			82, -- [11]
			"0x00000000000078FC", -- [12]
			0, -- [13]
			[51] = 1755897221,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefLazarglace|r",
		}, -- [71]
		{
			"25 healer LFG SFK", -- [1]
			"Boog", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Boog", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			83, -- [11]
			"0x0000000000006398", -- [12]
			0, -- [13]
			[51] = 1755897221,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddBoog|r",
		}, -- [72]
		{
			"[RU]<Vroter Dam> Semi-hc Guild Ishet people dla osvoenia contenta https://discord.gg/eHpvDHQzKj", -- [1]
			"Egormashina", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Egormashina", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			84, -- [11]
			"0x0000000000002795", -- [12]
			0, -- [13]
			[51] = 1755897222,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaEgormashina|r",
		}, -- [73]
		{
			"where are glyphs from ? ?", -- [1]
			"Darnien", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Darnien", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			85, -- [11]
			"0x00000000000122F3", -- [12]
			0, -- [13]
			[51] = 1755897227,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefDarnien|r",
		}, -- [74]
		{
			"<Impalde> Is Looking for Socials, levelers and recruiting for end game content! We are a PVE focused guild currently LF Boomkin Chad and other dps classes to fill our rosters. Raid times: Sat & Sun 17-20 GMT. PST for details!", -- [1]
			"Naalqt", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Naalqt", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			86, -- [11]
			"0x0000000000000A03", -- [12]
			0, -- [13]
			[51] = 1755897227,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefNaalqt|r",
		}, -- [75]
		{
			"last spot for RFK need DPS or TANK", -- [1]
			"Unholyholly", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Unholyholly", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			87, -- [11]
			"0x0000000000000C66", -- [12]
			0, -- [13]
			[51] = 1755897227,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaUnholyholly|r",
		}, -- [76]
		{
			"guys ambershire 10k, this server only 7k what happened? turtle is winning!! surely this server will make a comeback right?", -- [1]
			"Fortnitekid", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Fortnitekid", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			88, -- [11]
			"0x000000000000B7FF", -- [12]
			0, -- [13]
			[51] = 1755897232,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aFortnitekid|r",
		}, -- [77]
		{
			"Ah !@#$, <Here We Go Again>, another social/leveling guild with PvE/PvP and endgame content down the line. 60+ members and growing! PST for an invite, both factions are welcome. NA/English guild.", -- [1]
			"Juicylucy", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Juicylucy", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			89, -- [11]
			"0x000000000001ABFC", -- [12]
			0, -- [13]
			[51] = 1755897234,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aJuicylucy|r",
		}, -- [78]
		{
			"WTS |cff0070dd|Hitem:13124:0:0:0:0:0:0:0:38|h[Ravasaur Scale Boots]|h|r 2g", -- [1]
			"Tekkra", -- [2]
			"", -- [3]
			"2. Trade - City", -- [4]
			"Tekkra", -- [5]
			"", -- [6]
			2, -- [7]
			2, -- [8]
			"Trade - City", -- [9]
			0, -- [10]
			90, -- [11]
			"0x0000000000000250", -- [12]
			0, -- [13]
			[51] = 1755897240,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aTekkra|r",
		}, -- [79]
		{
			"LF1M SFK NEED TANK", -- [1]
			"Vordray", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Vordray", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			91, -- [11]
			"0x00000000000000B6", -- [12]
			0, -- [13]
			[51] = 1755897240,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Vordray|r",
		}, -- [80]
		{
			"i believe in more than 2 genders", -- [1]
			"Hotwoman", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Hotwoman", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			92, -- [11]
			"0x00000000000117E5", -- [12]
			0, -- [13]
			[51] = 1755897243,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Hotwoman|r",
		}, -- [81]
		{
			"Boats'n Hoes Boats'n Hoes", -- [1]
			"Puttblug", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Puttblug", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			93, -- [11]
			"0x00000000000151AC", -- [12]
			0, -- [13]
			[51] = 1755897253,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dPuttblug|r",
		}, -- [82]
		{
			"Healer LFG SM CATH ", -- [1]
			"Episcopus", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Episcopus", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			94, -- [11]
			"0x0000000000000DB5", -- [12]
			0, -- [13]
			[51] = 1755897253,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffEpiscopus|r",
		}, -- [83]
		{
			"LFM DM need tank and DPS + 20 3/5", -- [1]
			"Kjuba", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Kjuba", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			95, -- [11]
			"0x0000000000006E7D", -- [12]
			0, -- [13]
			[51] = 1755897253,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Kjuba|r",
		}, -- [84]
		{
			"your trash", -- [1]
			"Liliam", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Liliam", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			96, -- [11]
			"0x0000000000009FF2", -- [12]
			0, -- [13]
			[51] = 1755897255,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffLiliam|r",
		}, -- [85]
		{
			"LFG WC dps 20lvl", -- [1]
			"Soullesspal", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Soullesspal", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			97, -- [11]
			"0x0000000000000CB0", -- [12]
			0, -- [13]
			[51] = 1755897256,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaSoullesspal|r",
		}, -- [86]
		{
			"I also believe in fairy tales", -- [1]
			"Souldaddy", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Souldaddy", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			98, -- [11]
			"0x0000000000009C7E", -- [12]
			0, -- [13]
			[51] = 1755897258,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Souldaddy|r",
		}, -- [87]
		{
			"Where is Steven Molsen? |cffff2020|Hquest:27217:20|h[Auntie VanCleef]|h|r", -- [1]
			"Redrice", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Redrice", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			99, -- [11]
			"0x0000000000019BB3", -- [12]
			0, -- [13]
			[51] = 1755897258,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddRedrice|r",
		}, -- [88]
		{
			"troll..but still delusional", -- [1]
			"Seaker", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Seaker", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			100, -- [11]
			"0x0000000000000934", -- [12]
			0, -- [13]
			[51] = 1755897259,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Seaker|r",
		}, -- [89]
		{
			"meow", -- [1]
			"Useme", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Useme", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			101, -- [11]
			"0x0000000000014EC6", -- [12]
			0, -- [13]
			[51] = 1755897259,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaUseme|r",
		}, -- [90]
		{
			"dps LFG WC", -- [1]
			"Soleus", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Soleus", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			102, -- [11]
			"0x0000000000006D04", -- [12]
			0, -- [13]
			[51] = 1755897259,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Soleus|r",
		}, -- [91]
		{
			"LF2M Glittermurk need Tank and Heals", -- [1]
			"Hersh", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Hersh", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			104, -- [11]
			"0x000000000000094F", -- [12]
			0, -- [13]
			[51] = 1755897261,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Hersh|r",
		}, -- [92]
		{
			"just like god, its not real", -- [1]
			"Psychonelyy", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Psychonelyy", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			105, -- [11]
			"0x0000000000000C14", -- [12]
			0, -- [13]
			[51] = 1755897262,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddPsychonelyy|r",
		}, -- [93]
		{
			"WTS |cff0070dd|Hitem:4446:0:0:0:0:0:0:0:28|h[Blackvenom Blade]|h|r 2.5g |cff1eff00|Hitem:12008:0:0:0:0:0:132:0:28|h[Savannah Ring of Agility]|h|r 60s", -- [1]
			"Prowling", -- [2]
			"", -- [3]
			"2. Trade - City", -- [4]
			"Prowling", -- [5]
			"", -- [6]
			2, -- [7]
			2, -- [8]
			"Trade - City", -- [9]
			0, -- [10]
			106, -- [11]
			"0x000000000000CBC1", -- [12]
			0, -- [13]
			[51] = 1755897267,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Prowling|r",
		}, -- [94]
		{
			"hey you dont say that", -- [1]
			"Rip", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Rip", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			108, -- [11]
			"0x0000000000000E8B", -- [12]
			0, -- [13]
			[51] = 1755897272,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aRip|r",
		}, -- [95]
		{
			"LF1M Gnomer, Tank", -- [1]
			"Outward", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Outward", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			109, -- [11]
			"0x0000000000000E04", -- [12]
			0, -- [13]
			[51] = 1755897272,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaOutward|r",
		}, -- [96]
		{
			"LFM DM Tank & Dps", -- [1]
			"Boogersxgar", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Boogersxgar", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			110, -- [11]
			"0x0000000000006AEC", -- [12]
			0, -- [13]
			[51] = 1755897273,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddBoogersxgar|r",
		}, -- [97]
		{
			"LF 1 dps for SFK, RDPS pref", -- [1]
			"Tyrelys", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Tyrelys", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			111, -- [11]
			"0x000000000000F14B", -- [12]
			0, -- [13]
			[51] = 1755897273,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Tyrelys|r",
		}, -- [98]
		{
			"LFG stockade dps", -- [1]
			"Eluon", -- [2]
			"", -- [3]
			"5. LookingForGroup", -- [4]
			"Eluon", -- [5]
			"", -- [6]
			26, -- [7]
			5, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			112, -- [11]
			"0x000000000000870B", -- [12]
			0, -- [13]
			[51] = 1755897277,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Eluon|r",
		}, -- [99]
		{
			"LFM |cffff2020|Hquest:253:30|h[Bride of the Embalmer]|h|r |cffff2020|Hquest:253:30|h[Bride of the Embalmer]|h|r", -- [1]
			"Yyds", -- [2]
			"", -- [3]
			"6. World", -- [4]
			"Yyds", -- [5]
			"", -- [6]
			30, -- [7]
			6, -- [8]
			"World", -- [9]
			0, -- [10]
			113, -- [11]
			"0x000000000000F8C5", -- [12]
			0, -- [13]
			[51] = 1755897278,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddYyds|r",
		}, -- [100]
	},
}
