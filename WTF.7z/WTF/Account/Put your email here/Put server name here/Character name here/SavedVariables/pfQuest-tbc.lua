
pfQuest_config = {
	["trackerpos"] = {
		"TOPRIGHT", -- [1]
		-51.75, -- [2]
		-244.5, -- [3]
	},
	["welcome"] = "1",
	["currentquestgivers"] = "1",
	["showclustermini"] = "0",
	["worldmapmenu"] = "1",
	["clustermono"] = "0",
	["minimapnodes"] = "1",
	["showcluster"] = "1",
	["mouseover"] = "1",
	["trackerexpand"] = "0",
	["favonlogin"] = "0",
	["minimapbutton"] = "1",
	["spawncolors"] = "0",
	["cutoutminimap"] = "1",
	["questlinks"] = "1",
	["showspawnmini"] = "1",
	["showids"] = "0",
	["routes"] = "1",
	["showtracker"] = "1",
	["nodefade"] = "0.3",
	["showhighlevel"] = "0",
	["mindropchance"] = "1",
	["questlogbuttons"] = "1",
	["trackerlevel"] = "1",
	["routestarter"] = "0",
	["worldmaptransp"] = "1.0",
	["cutoutworldmap"] = "0",
	["showfestival"] = "0",
	["trackingmethod"] = 1,
	["showspawn"] = "1",
	["showtooltips"] = "1",
	["trackingicons"] = "1",
	["trackeralpha"] = "0",
	["trackerfontsize"] = "12",
	["showlowlevel"] = "0",
	["tooltiphelp"] = "1",
	["routecluster"] = "1",
	["allquestgivers"] = "1",
	["questloglevel"] = "0",
	["minimaptransp"] = "1.0",
	["routeender"] = "1",
	["routeminimap"] = "0",
	["arrow"] = "1",
}
pfBrowser_fav = {
	["objects"] = {
	},
	["items"] = {
	},
	["quests"] = {
	},
	["units"] = {
	},
}
pfQuest_history = {
}
pfQuest_colors = {
}
pfQuest_server = {
	["items"] = {
	},
}
pfQuest_track = {
}
