
pfQuest_config = {
	["trackerpos"] = {
		"TOPRIGHT", -- [1]
		-31, -- [2]
		-245, -- [3]
	},
	["welcome"] = "1",
	["currentquestgivers"] = "1",
	["showclustermini"] = "0",
	["worldmapmenu"] = "1",
	["clustermono"] = "0",
	["minimapnodes"] = "1",
	["showcluster"] = "1",
	["mouseover"] = "1",
	["trackerexpand"] = "0",
	["favonlogin"] = "0",
	["minimapbutton"] = "1",
	["spawncolors"] = "0",
	["cutoutminimap"] = "1",
	["questlinks"] = "1",
	["showspawnmini"] = "1",
	["showids"] = "0",
	["routes"] = "1",
	["showtracker"] = "1",
	["nodefade"] = "0.3",
	["showhighlevel"] = "0",
	["mindropchance"] = "1",
	["questlogbuttons"] = "1",
	["trackerlevel"] = "1",
	["routestarter"] = "0",
	["worldmaptransp"] = "1.0",
	["cutoutworldmap"] = "0",
	["showfestival"] = "0",
	["trackingmethod"] = 1,
	["showspawn"] = "1",
	["showtooltips"] = "1",
	["trackingicons"] = "1",
	["trackeralpha"] = "0",
	["trackerfontsize"] = "12",
	["showlowlevel"] = "0",
	["tooltiphelp"] = "1",
	["routecluster"] = "1",
	["allquestgivers"] = "1",
	["questloglevel"] = "0",
	["minimaptransp"] = "1.0",
	["routeender"] = "1",
	["routeminimap"] = "0",
	["arrow"] = "1",
}
pfBrowser_fav = {
	["objects"] = {
	},
	["items"] = {
	},
	["quests"] = {
	},
	["units"] = {
	},
}
pfQuest_history = {
	[26777] = {
		1755737574, -- [1]
		5, -- [2]
	},
	[7] = {
		1755735997, -- [1]
		4, -- [2]
	},
	[15] = {
		1755738557, -- [1]
		5, -- [2]
	},
	[26779] = {
		1755739382, -- [1]
		6, -- [2]
	},
	[33] = {
		1755735649, -- [1]
		4, -- [2]
	},
	[5261] = {
		1755739174, -- [1]
		6, -- [2]
	},
	[18] = {
		1755737656, -- [1]
		5, -- [2]
	},
	[21] = {
		1755739161, -- [1]
		6, -- [2]
	},
	[3861] = {
		1755739183, -- [1]
		6, -- [2]
	},
	[2158] = {
		1755739367, -- [1]
		6, -- [2]
	},
	[3905] = {
		1755738661, -- [1]
		6, -- [2]
	},
	[3903] = {
		1755737785, -- [1]
		5, -- [2]
	},
	[26778] = {
		1755737746, -- [1]
		5, -- [2]
	},
	[3904] = {
		1755738605, -- [1]
		5, -- [2]
	},
	[6] = {
		1755738544, -- [1]
		5, -- [2]
	},
	[3102] = {
		1755736037, -- [1]
		4, -- [2]
	},
	[54] = {
		1755739289, -- [1]
		6, -- [2]
	},
	[783] = {
		1755739172, -- [1]
		6, -- [2]
	},
	[26776] = {
		1755737673, -- [1]
		5, -- [2]
	},
	[26780] = {
		1755739406, -- [1]
		6, -- [2]
	},
}
pfQuest_colors = {
	["Skirmish at Echo Ridge"] = {
		0.9411764705882353, -- [1]
		0.3725490196078432, -- [2]
		0.8470588235294118, -- [3]
	},
	["Eagan Peltskinner"] = {
		0.8235294117647058, -- [1]
		0.3647058823529412, -- [2]
		0.8627450980392157, -- [3]
	},
}
pfQuest_server = {
	["items"] = {
	},
}
pfQuest_track = {
}
