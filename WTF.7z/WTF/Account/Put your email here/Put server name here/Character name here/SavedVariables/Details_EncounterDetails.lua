
EncounterDetailsDB = {
	["emotes"] = {
	},
	["encounter_spells"] = {
	},
}
