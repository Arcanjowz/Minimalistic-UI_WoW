
_detalhes_database = {
	["savedbuffs"] = {
	},
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 74,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008426,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 74,
							},
							["pets"] = {
							},
							["last_event"] = 1755739098,
							["end_time"] = 1755739099,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 74.008426,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 74.008426,
							["classe"] = "ROGUE",
							["damage_taken"] = 17.008426,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 33,
										},
										["n_dmg"] = 33,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 33,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 5,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["Kobold Laborer"] = 19,
										},
										["n_dmg"] = 19,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 10.5605630707738,
							["colocacao"] = 1,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739092,
							["serial"] = "0x000000000000887D",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005134,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 23,
							},
							["pets"] = {
							},
							["last_event"] = 1755739098,
							["end_time"] = 1755739099,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 23.005134,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 23.005134,
							["classe"] = "ROGUE",
							["damage_taken"] = 0.005134,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 13,
										},
										["n_dmg"] = 13,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 13,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kobold Laborer"] = 10,
										},
										["n_dmg"] = 10,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 3.282696061643073,
							["colocacao"] = 2,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739096,
							["serial"] = "0x000000000000C7E6",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.005583,
							["damage_from"] = {
								["Misfired"] = true,
								["Arcanjo"] = true,
								["Bohunter"] = true,
								["Viennetta"] = true,
								["Evander"] = true,
							},
							["targets"] = {
								["Evander"] = 40,
								["Misfired"] = 24,
								["Arcanjo"] = 17,
								["Bohunter"] = 63,
							},
							["pets"] = {
							},
							["nome"] = "Kobold Laborer",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 144.005583,
							["last_event"] = 1755739124,
							["fight_component"] = true,
							["total"] = 144.005583,
							["delay"] = 1755739124,
							["classe"] = "UNKNOW",
							["timeMachine"] = 1,
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Evander"] = 40,
											["Misfired"] = 24,
											["Arcanjo"] = 17,
											["Bohunter"] = 63,
										},
										["n_dmg"] = 134,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 37,
										["total"] = 144,
										["c_max"] = 10,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["c_min"] = 10,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 34,
										["MISS"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 417.005583,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = true,
							["start_time"] = 1755739092,
							["serial"] = "0xF13000005000354F",
							["dps_started"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 74,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 74,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 74,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 74,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9634.822,
				["tempo_start"] = 1755739092,
				["last_events_tables"] = {
				},
				["combat_counter"] = 115,
				["totals"] = {
					240.8159819999992, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:18:19",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 6.608000000000175,
				["CombatEndedAt"] = 9641.43,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 74.008426,
							["Viennetta"] = 23.005134,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9641.826000000001,
				["combat_id"] = 74,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:18:12",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					97, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9634.817999999999,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 73,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006125,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 55,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 55.006125,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755739091,
							["total"] = 55.006125,
							["damage_taken"] = 0.006125,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 14,
										},
										["n_dmg"] = 14,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 21,
										},
										["n_dmg"] = 21,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["Kobold Laborer"] = 20,
										},
										["n_dmg"] = 20,
										["n_min"] = 20,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 7.842333190760179,
							["colocacao"] = 1,
							["last_event"] = 1755739091,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739087,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00211,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 46,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 46.00211,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755739091,
							["total"] = 46.00211,
							["damage_taken"] = 8.00211,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 14,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 35,
										},
										["n_dmg"] = 21,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 35,
										["c_max"] = 14,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 14,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 11,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 6.558612774450132,
							["colocacao"] = 2,
							["last_event"] = 1755739090,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739084,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006219,
							["damage_from"] = {
								["Viennetta"] = true,
								["Arcanjo"] = true,
								["Evander"] = true,
							},
							["targets"] = {
								["Arcanjo"] = 8,
								["Evander"] = 8,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 16.006219,
							["last_event"] = 1755739090,
							["fight_component"] = true,
							["total"] = 16.006219,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["Arcanjo"] = 8,
											["Evander"] = 8,
										},
										["n_dmg"] = 16,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["spellschool"] = 1,
										["DODGE"] = 2,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 151.006219,
							["end_time"] = 1755739091,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755739086,
							["serial"] = "0xF13000005000354A",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 73,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 73,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 73,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 73,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9627.02,
				["tempo_start"] = 1755739084,
				["last_events_tables"] = {
				},
				["combat_counter"] = 114,
				["totals"] = {
					116.994685, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:18:12",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 6.505999999999403,
				["CombatEndedAt"] = 9633.526,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 46.00211,
							["Viennetta"] = 55.006125,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9634.030000000001,
				["combat_id"] = 73,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:18:05",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					101, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9627.016,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 2,
				},
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 72,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007501,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 65,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 65.00750099999999,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755739080,
							["total"] = 65.00750099999999,
							["damage_taken"] = 6.007501,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 13,
										},
										["n_dmg"] = 13,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 13,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2764] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kobold Laborer"] = 10,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 10,
										["c_max"] = 10,
										["id"] = 2764,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 10,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["Kobold Laborer"] = 20,
										},
										["n_dmg"] = 20,
										["n_min"] = 20,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 12.99370397761184,
							["colocacao"] = 1,
							["last_event"] = 1755739080,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739075,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006525,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 17,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 17.006525,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755739080,
							["total"] = 17.006525,
							["damage_taken"] = 0.006525,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 7,
										},
										["n_dmg"] = 7,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 7,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kobold Laborer"] = 10,
										},
										["n_dmg"] = 10,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 3.399265440735143,
							["colocacao"] = 2,
							["last_event"] = 1755739080,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739079,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.004619,
							["damage_from"] = {
								["Viennetta"] = true,
								["Arcanjo"] = true,
								["Evander"] = true,
							},
							["targets"] = {
								["Arcanjo"] = 6,
								["Evander"] = 16,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 22.004619,
							["last_event"] = 1755739084,
							["fight_component"] = true,
							["total"] = 22.004619,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["Arcanjo"] = 6,
											["Evander"] = 16,
										},
										["n_dmg"] = 22,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 129.004619,
							["end_time"] = 1755739084,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755739075,
							["serial"] = "0xF13000005000353B",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 72,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 72,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 72,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 72,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["tempo_start"] = 1755739075,
				["last_events_tables"] = {
				},
				["enemy"] = "Kobold Laborer",
				["combat_counter"] = 113,
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					103.986693, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					82, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 65.00750099999999,
							["Viennetta"] = 17.006525,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:17:56",
				["end_time"] = 9623.291000000001,
				["TotalElapsedCombatTime"] = 9622.847,
				["combat_id"] = 72,
				["player_last_events"] = {
				},
				["CombatEndedAt"] = 9622.847,
				["hasSaved"] = true,
				["frags"] = {
					["Kobold Worker"] = 1,
					["Kobold Laborer"] = 1,
				},
				["data_fim"] = "22:18:01",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 9618.288000000001,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 71,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005026,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 85,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 85.005026,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755739060,
							["total"] = 85.005026,
							["damage_taken"] = 6.005026,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 3,
										["DODGE"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 35,
										},
										["n_dmg"] = 35,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 35,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 28,
										["targets"] = {
											["Kobold Laborer"] = 28,
										},
										["n_dmg"] = 28,
										["n_min"] = 28,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 28,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 10.6004521760815,
							["colocacao"] = 1,
							["last_event"] = 1755739060,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739052,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.004474,
							["damage_from"] = {
								["Evander"] = true,
								["Arcanjo"] = true,
								["Bohunter"] = true,
							},
							["targets"] = {
								["Bohunter"] = 47,
								["Arcanjo"] = 6,
								["Evander"] = 13,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 66.004474,
							["last_event"] = 1755739073,
							["fight_component"] = true,
							["total"] = 66.004474,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 8,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["Bohunter"] = 47,
											["Arcanjo"] = 6,
											["Evander"] = 13,
										},
										["n_dmg"] = 58,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 24,
										["total"] = 66,
										["c_max"] = 8,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["c_min"] = 8,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 18,
										["DODGE"] = 4,
										["MISS"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 242.004474,
							["end_time"] = 1755739075,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755739052,
							["serial"] = "0xF130000050003526",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 71,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 71,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 71,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 71,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9617.675000000001,
				["tempo_start"] = 1755739052,
				["last_events_tables"] = {
				},
				["combat_counter"] = 112,
				["totals"] = {
					150.972728, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:17:40",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 7.827000000001135,
				["CombatEndedAt"] = 9602.529000000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 85.005026,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9602.718000000001,
				["combat_id"] = 71,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:17:32",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					85, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9594.699000000001,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Worker"] = 1,
					["Kobold Laborer"] = 1,
				},
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 70,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007938000000000001,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 51,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 51.007938,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755739020,
							["total"] = 51.007938,
							["damage_taken"] = 3.007938,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Kobold Laborer"] = 12,
										},
										["n_dmg"] = 12,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 12,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Kobold Laborer"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 24,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 36,
										},
										["n_dmg"] = 12,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 36,
										["c_max"] = 24,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 24,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 10.18529113418569,
							["colocacao"] = 1,
							["last_event"] = 1755739018,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739015,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.004568,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 29,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 29.004568,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755739020,
							["total"] = 29.004568,
							["damage_taken"] = 0.004568,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 8,
										},
										["n_dmg"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 21,
										},
										["n_dmg"] = 21,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 5.791646964856449,
							["colocacao"] = 2,
							["last_event"] = 1755739020,
							["friendlyfire"] = {
							},
							["start_time"] = 1755739018,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.008558,
							["damage_from"] = {
								["Evander"] = true,
								["Viennetta"] = true,
								["Arcanjo"] = true,
								["Bohunter"] = true,
							},
							["targets"] = {
								["Bohunter"] = 84,
								["Arcanjo"] = 3,
								["Evander"] = 3,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 90.00855799999999,
							["last_event"] = 1755739051,
							["fight_component"] = true,
							["total"] = 90.00855799999999,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 8,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Bohunter"] = 84,
											["Arcanjo"] = 3,
											["Evander"] = 3,
										},
										["n_dmg"] = 82,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 29,
										["total"] = 90,
										["c_max"] = 8,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 8,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 23,
										["spellschool"] = 1,
										["DODGE"] = 5,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 225.008558,
							["end_time"] = 1755739052,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755739016,
							["serial"] = "0xF1300000500034FB",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 70,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 70,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 70,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 70,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["tempo_start"] = 1755739015,
				["last_events_tables"] = {
				},
				["enemy"] = "Kobold Laborer",
				["combat_counter"] = 111,
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					169.98981, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					80, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 51.007938,
							["Viennetta"] = 29.004568,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:16:55",
				["end_time"] = 9562.575000000001,
				["TotalElapsedCombatTime"] = 9562.370000000001,
				["combat_id"] = 70,
				["player_last_events"] = {
				},
				["CombatEndedAt"] = 9562.370000000001,
				["hasSaved"] = true,
				["frags"] = {
					["Kobold Laborer"] = 2,
				},
				["data_fim"] = "22:17:00",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 9557.567000000001,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 69,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001884,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 72,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 72.001884,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738946,
							["total"] = 72.001884,
							["damage_taken"] = 6.001884,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 16,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 29,
										},
										["n_dmg"] = 13,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 29,
										["c_max"] = 16,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 16,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 20,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 43,
										},
										["n_dmg"] = 23,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 43,
										["c_max"] = 20,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 20,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 11.98832567432324,
							["colocacao"] = 1,
							["last_event"] = 1755738945,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738940,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001122,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 10,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 10.001122,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738946,
							["total"] = 10.001122,
							["damage_taken"] = 0.001122,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kobold Laborer"] = 10,
										},
										["n_dmg"] = 10,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 1.665188478188139,
							["colocacao"] = 2,
							["last_event"] = 1755738945,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738945,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.002783,
							["damage_from"] = {
								["Arcanjo"] = true,
								["Bohunter"] = true,
								["Viennetta"] = true,
								["Lazerwolf"] = true,
								["Evander"] = true,
							},
							["targets"] = {
								["Evander"] = 86,
								["Arcanjo"] = 6,
								["Lazerwolf"] = 35,
								["Bohunter"] = 8,
							},
							["pets"] = {
							},
							["total"] = 135.002783,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 135.002783,
							["last_event"] = 1755739015,
							["fight_component"] = true,
							["end_time"] = 1755739015,
							["delay"] = 1755738971,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 8,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Evander"] = 86,
											["Arcanjo"] = 6,
											["Lazerwolf"] = 35,
											["Bohunter"] = 8,
										},
										["n_dmg"] = 127,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 37,
										["total"] = 135,
										["c_max"] = 8,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["c_min"] = 8,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 34,
										["MISS"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 623.002783,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738962,
							["serial"] = "0xF1300000500034AE",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 69,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 69,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 69,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 3,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 69,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9556.74,
				["tempo_start"] = 1755738940,
				["last_events_tables"] = {
				},
				["combat_counter"] = 110,
				["totals"] = {
					216.983186, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:15:46",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 5.488000000001193,
				["CombatEndedAt"] = 9487.602000000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 72.001884,
							["Viennetta"] = 10.001122,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9488.119000000001,
				["combat_id"] = 69,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:15:40",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					82, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9482.112999999999,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 68,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001044,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 85,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 85.00104400000001,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738922,
							["total"] = 85.00104400000001,
							["damage_taken"] = 9.001044,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 28,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 35,
										},
										["n_dmg"] = 7,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 35,
										["c_max"] = 16,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 12,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 22,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 33,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 33,
										["c_max"] = 22,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 22,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["Kobold Laborer"] = 17,
										},
										["n_dmg"] = 17,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 17,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 14.14562223331666,
							["colocacao"] = 1,
							["last_event"] = 1755738921,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738916,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005989,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 19,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19.005989,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738922,
							["total"] = 19.005989,
							["damage_taken"] = 0.005989,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 8,
										},
										["n_dmg"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 11,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 3.162920452654344,
							["colocacao"] = 2,
							["last_event"] = 1755738922,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738922,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.004504,
							["damage_from"] = {
								["Arcanjo"] = true,
								["Viennetta"] = true,
								["Lazerwolf"] = true,
								["Evander"] = true,
							},
							["targets"] = {
								["Arcanjo"] = 9,
								["Lazerwolf"] = 9,
								["Evander"] = 9,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 27.004504,
							["last_event"] = 1755738938,
							["fight_component"] = true,
							["total"] = 27.004504,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Arcanjo"] = 9,
											["Lazerwolf"] = 9,
											["Evander"] = 9,
										},
										["n_dmg"] = 27,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 27,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 7,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 247.004504,
							["end_time"] = 1755738940,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738916,
							["serial"] = "0xF130000050003496",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 68,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 68,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 68,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 68,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9458.338,
				["tempo_start"] = 1755738916,
				["last_events_tables"] = {
				},
				["combat_counter"] = 109,
				["totals"] = {
					130.988738, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:15:22",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 5.782000000001062,
				["CombatEndedAt"] = 9464.120000000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 85.00104400000001,
							["Viennetta"] = 19.005989,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9464.343000000001,
				["combat_id"] = 68,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:15:16",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					104, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9458.334000000001,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 67,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00494,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 50,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 50.00494,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738911,
							["total"] = 50.00494,
							["damage_taken"] = 3.00494,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 12,
										},
										["n_dmg"] = 12,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 12,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 5,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 24,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 35,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 35,
										["c_max"] = 24,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 24,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Kobold Laborer"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 14.25860849729273,
							["colocacao"] = 1,
							["last_event"] = 1755738910,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738907,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.002916,
							["damage_from"] = {
								["Arcanjo"] = true,
								["Viennetta"] = true,
							},
							["targets"] = {
								["Arcanjo"] = 3,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3.002916,
							["last_event"] = 1755738909,
							["fight_component"] = true,
							["total"] = 3.002916,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Arcanjo"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 80.002916,
							["end_time"] = 1755738911,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738909,
							["serial"] = "0xF130000050003489",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001616,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 30,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 30.001616,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738911,
							["total"] = 30.001616,
							["damage_taken"] = 0.001616,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 8,
										},
										["n_dmg"] = 8,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 8,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 8.554780724266712,
							["colocacao"] = 2,
							["last_event"] = 1755738911,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738909,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 67,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 67,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 67,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 67,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["tempo_start"] = 1755738907,
				["last_events_tables"] = {
				},
				["enemy"] = "Kobold Laborer",
				["combat_counter"] = 108,
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					83, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					80, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 50.00494,
							["Viennetta"] = 30.001616,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:15:08",
				["end_time"] = 9453.950000000001,
				["TotalElapsedCombatTime"] = 9453.303,
				["combat_id"] = 67,
				["player_last_events"] = {
				},
				["CombatEndedAt"] = 9453.303,
				["hasSaved"] = true,
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
				["data_fim"] = "22:15:12",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 9449.946,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 66,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002731,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 52,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 52.002731,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738899,
							["total"] = 52.002731,
							["damage_taken"] = 6.002731,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Kobold Laborer"] = 18,
										},
										["n_dmg"] = 18,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 18,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 22,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 34,
										},
										["n_dmg"] = 12,
										["n_min"] = 12,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 34,
										["c_max"] = 22,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 22,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 15.61174752326567,
							["colocacao"] = 1,
							["last_event"] = 1755738898,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738895,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.002783,
							["damage_from"] = {
								["Arcanjo"] = true,
								["Viennetta"] = true,
							},
							["targets"] = {
								["Viennetta"] = 6,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 6.002783,
							["last_event"] = 1755738897,
							["fight_component"] = true,
							["total"] = 6.002783,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Viennetta"] = 6,
										},
										["n_dmg"] = 6,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 6,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 85.00278299999999,
							["end_time"] = 1755738899,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738895,
							["serial"] = "0xF13000005000347D",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008683,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 33,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 33.00868300000001,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738899,
							["total"] = 33.00868300000001,
							["damage_taken"] = 0.008683,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Kobold Laborer"] = 12,
										},
										["n_dmg"] = 12,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 12,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 21,
										},
										["n_dmg"] = 21,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 9.909541579104985,
							["colocacao"] = 2,
							["last_event"] = 1755738897,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738895,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 66,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 66,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 66,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 66,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9448.875,
				["tempo_start"] = 1755738895,
				["last_events_tables"] = {
				},
				["combat_counter"] = 107,
				["totals"] = {
					90.99769000000001, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:14:59",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 2.992000000000189,
				["CombatEndedAt"] = 9440.821,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 33.00868300000001,
							["Viennetta"] = 52.002731,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9441.585999999999,
				["combat_id"] = 66,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:14:55",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					85, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9437.587,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 65,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002953,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 55,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 55.002953,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738887,
							["total"] = 55.002953,
							["damage_taken"] = 15.002953,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 19,
										},
										["n_dmg"] = 19,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 22,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 33,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 33,
										["c_max"] = 22,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 22,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Kobold Laborer"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kobold Laborer"] = 0,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 6.862501933874484,
							["colocacao"] = 1,
							["last_event"] = 1755738887,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738879,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008074,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 51,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 51.008074,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738887,
							["total"] = 51.008074,
							["damage_taken"] = 0.008074,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Kobold Laborer"] = 20,
										},
										["n_dmg"] = 20,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kobold Laborer"] = 20,
										},
										["n_dmg"] = 20,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 11,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 6.364076606363532,
							["colocacao"] = 2,
							["last_event"] = 1755738887,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738881,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.001931,
							["damage_from"] = {
								["Evander"] = true,
								["Viennetta"] = true,
								["Arcanjo"] = true,
								["Bohunter"] = true,
							},
							["targets"] = {
								["Evander"] = 16,
								["Arcanjo"] = 15,
								["Bohunter"] = 6,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 37.001931,
							["last_event"] = 1755738890,
							["fight_component"] = true,
							["total"] = 37.001931,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Evander"] = 16,
											["Arcanjo"] = 15,
											["Bohunter"] = 6,
										},
										["n_dmg"] = 37,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 176.001931,
							["end_time"] = 1755738895,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738880,
							["serial"] = "0xF13000005000346C",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 65,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 65,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 65,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 3,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 65,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["tempo_start"] = 1755738879,
				["last_events_tables"] = {
				},
				["enemy"] = "Kobold Laborer",
				["combat_counter"] = 106,
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					142.992624, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					106, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 55.002953,
							["Viennetta"] = 51.008074,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:14:39",
				["end_time"] = 9429.561,
				["TotalElapsedCombatTime"] = 9429.224,
				["combat_id"] = 65,
				["player_last_events"] = {
				},
				["CombatEndedAt"] = 9429.224,
				["hasSaved"] = true,
				["frags"] = {
					["Kobold Laborer"] = 2,
				},
				["data_fim"] = "22:14:47",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 9421.546,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [10]
			{
				{
					["tipo"] = 2,
					["combatId"] = 64,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004437,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 63,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 63.004437,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738875,
							["total"] = 63.004437,
							["damage_taken"] = 6.004436999999999,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 16,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Kobold Laborer"] = 22,
										},
										["n_dmg"] = 6,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 22,
										["c_max"] = 16,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 16,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["a_dmg"] = 0,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["Kobold Laborer"] = 19,
										},
										["n_dmg"] = 19,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 15.73930477141903,
							["colocacao"] = 1,
							["last_event"] = 1755738874,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738871,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.007950000000000001,
							["damage_from"] = {
								["Dakota"] = true,
								["Mullenkamp"] = true,
								["Arcanjo"] = true,
								["Evander"] = true,
							},
							["targets"] = {
								["Arcanjo"] = 6,
								["Evander"] = 20,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 26.00795,
							["last_event"] = 1755738878,
							["fight_component"] = true,
							["total"] = 26.00795,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 8,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["Arcanjo"] = 6,
											["Evander"] = 20,
										},
										["n_dmg"] = 18,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 26,
										["c_max"] = 8,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 8,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 108.00795,
							["end_time"] = 1755738879,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738871,
							["serial"] = "0xF130000050003466",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 64,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 64,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 64,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 64,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9420.673000000001,
				["tempo_start"] = 1755738871,
				["last_events_tables"] = {
				},
				["combat_counter"] = 105,
				["totals"] = {
					88.983476, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:14:35",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 3.713999999999942,
				["CombatEndedAt"] = 9416.805,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 63.004437,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9417.09,
				["combat_id"] = 64,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:14:31",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					63, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9413.087,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
			}, -- [11]
			{
				{
					["tipo"] = 2,
					["combatId"] = 63,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00605,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 43,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 43.00605,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738829,
							["total"] = 43.00605,
							["damage_taken"] = 3.00605,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 21,
										},
										["n_dmg"] = 21,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 21,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 10.75958218664163,
							["colocacao"] = 1,
							["last_event"] = 1755738829,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738825,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007745,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 37,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 37.007745,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738829,
							["total"] = 37.007745,
							["damage_taken"] = 3.007745,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 12,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 26,
										},
										["n_dmg"] = 14,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 26,
										["c_max"] = 12,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 12,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 11,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 9.258880410309146,
							["colocacao"] = 2,
							["last_event"] = 1755738829,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738826,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.003929,
							["damage_from"] = {
								["Mullenkamp"] = true,
								["Arcanjo"] = true,
								["Rulqua"] = true,
								["Dakota"] = true,
								["Viennetta"] = true,
								["Lazerwolf"] = true,
								["Evander"] = true,
							},
							["targets"] = {
								["Mullenkamp"] = 6,
								["Viennetta"] = 3,
								["Arcanjo"] = 3,
								["Rulqua"] = 3,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 15.003929,
							["last_event"] = 1755738870,
							["fight_component"] = true,
							["total"] = 15.003929,
							["delay"] = 1755738833,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Arcanjo"] = 3,
											["Rulqua"] = 3,
											["Viennetta"] = 3,
											["Mullenkamp"] = 6,
											["Evander"] = 0,
										},
										["n_dmg"] = 15,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 5,
										["MISS"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 205.003929,
							["end_time"] = 1755738871,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738863,
							["serial"] = "0xF130000050003422",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 63,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 63,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 63,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Viennetta",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000C7E6",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 63,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9368.759,
				["tempo_start"] = 1755738825,
				["last_events_tables"] = {
				},
				["combat_counter"] = 104,
				["totals"] = {
					94.96743099999999, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:13:50",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 3.860000000000582,
				["CombatEndedAt"] = 9372.619000000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 43.00605,
							["Viennetta"] = 37.007745,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9372.755999999999,
				["combat_id"] = 63,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:13:46",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					80, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9368.759,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
			}, -- [12]
			{
				{
					["tipo"] = 2,
					["combatId"] = 62,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006757,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 34,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 34.006757,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738825,
							["total"] = 34.006757,
							["damage_taken"] = 0.006757,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 14,
										},
										["n_dmg"] = 14,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 14,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 20,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["Kobold Laborer"] = 20,
										},
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 20,
										["c_max"] = 20,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 20,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 11.30919753907697,
							["colocacao"] = 1,
							["last_event"] = 1755738824,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738823,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00583,
							["damage_from"] = {
							},
							["targets"] = {
								["Kobold Laborer"] = 25,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 25.00583,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738825,
							["total"] = 25.00583,
							["damage_taken"] = 0.00583,
							["nome"] = "Viennetta",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 15,
										},
										["n_dmg"] = 15,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 15,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Kobold Laborer"] = 10,
										},
										["n_dmg"] = 10,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 10,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 8.31587296308722,
							["colocacao"] = 2,
							["last_event"] = 1755738823,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738822,
							["serial"] = "0x000000000000C7E6",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.004329,
							["damage_from"] = {
								["Viennetta"] = true,
								["Arcanjo"] = true,
								["Mullenkamp"] = true,
							},
							["targets"] = {
								["Mullenkamp"] = 3,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3.004329,
							["last_event"] = 1755738825,
							["fight_component"] = true,
							["total"] = 3.004329,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Viennetta"] = 0,
											["Mullenkamp"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 64.004329,
							["end_time"] = 1755738825,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738825,
							["serial"] = "0xF130000050003426",
							["dps_started"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 62,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 62,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 62,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 62,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
					["Viennetta"] = true,
				},
				["CombatStartedAt"] = 9365.838,
				["tempo_start"] = 1755738822,
				["last_events_tables"] = {
				},
				["combat_counter"] = 103,
				["totals"] = {
					61.987169, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:13:46",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 1.416000000001077,
				["CombatEndedAt"] = 9367.254000000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 34.006757,
							["Viennetta"] = 25.00583,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9368.178,
				["combat_id"] = 62,
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["data_inicio"] = "22:13:43",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					59, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9365.171,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 1,
				},
			}, -- [13]
			{
				{
					["tipo"] = 2,
					["combatId"] = 61,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008977000000000001,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 103,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 103.008977,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738762,
							["total"] = 103.008977,
							["damage_taken"] = 14.008977,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 16,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 45,
										},
										["n_dmg"] = 29,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 45,
										["c_max"] = 16,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 16,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 24,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Kobold Laborer"] = 35,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 35,
										["c_max"] = 24,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 24,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["Kobold Laborer"] = 4,
										},
										["n_dmg"] = 4,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["Kobold Laborer"] = 19,
										},
										["n_dmg"] = 19,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 12.85202457891547,
							["colocacao"] = 1,
							["last_event"] = 1755738761,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738754,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006294,
							["damage_from"] = {
								["Strixter"] = true,
								["Arcanjo"] = true,
								["Rulqua"] = true,
								["Dakota"] = true,
								["Viennetta"] = true,
								["Lazerwolf"] = true,
								["Mullenkamp"] = true,
							},
							["targets"] = {
								["Lazerwolf"] = 28,
								["Viennetta"] = 9,
								["Arcanjo"] = 14,
								["Strixter"] = 19,
							},
							["pets"] = {
							},
							["total"] = 70.006294,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 70.006294,
							["last_event"] = 1755738821,
							["fight_component"] = true,
							["end_time"] = 1755738822,
							["delay"] = 1755738775,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 6,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Lazerwolf"] = 28,
											["Viennetta"] = 9,
											["Arcanjo"] = 14,
											["Strixter"] = 19,
										},
										["n_dmg"] = 64,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 70,
										["c_max"] = 6,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["c_min"] = 6,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 14,
										["MISS"] = 3,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 455.006294,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738789,
							["serial"] = "0xF130000050003402",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 61,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 61,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 61,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 61,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
				},
				["tempo_start"] = 1755738754,
				["last_events_tables"] = {
				},
				["combat_counter"] = 102,
				["playing_solo"] = true,
				["totals"] = {
					172.9535129999999, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:12:42",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 9304.326000000001,
				["CombatEndedAt"] = 9304.326000000001,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 103.008977,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9304.679,
				["combat_id"] = 61,
				["data_inicio"] = "22:12:34",
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					103, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9296.664000000001,
				["TimeData"] = {
				},
				["frags"] = {
					["Kobold Laborer"] = 2,
					["Kobold Worker"] = 1,
				},
			}, -- [14]
			{
				{
					["tipo"] = 2,
					["combatId"] = 60,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005374,
							["damage_from"] = {
								["Kobold Laborer"] = true,
							},
							["targets"] = {
								["Kobold Laborer"] = 104,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 104.005374,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738735,
							["total"] = 104.005374,
							["damage_taken"] = 28.005374,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 12,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Kobold Laborer"] = 53,
										},
										["n_dmg"] = 41,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 53,
										["c_max"] = 12,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 12,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["spellschool"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Kobold Laborer"] = 35,
										},
										["n_dmg"] = 35,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 35,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 16,
										["targets"] = {
											["Kobold Laborer"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 8.659176921155304,
							["colocacao"] = 1,
							["last_event"] = 1755738734,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738723,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 0.006994,
							["damage_from"] = {
								["Arcanjo"] = true,
								["Rulqua"] = true,
								["Dakota"] = true,
								["Holynow"] = true,
								["Lazerwolf"] = true,
								["Mullenkamp"] = true,
							},
							["targets"] = {
								["Holynow"] = 6,
								["Arcanjo"] = 28,
								["Lazerwolf"] = 15,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 49.006994,
							["last_event"] = 1755738751,
							["fight_component"] = true,
							["total"] = 49.006994,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Kobold Laborer",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Holynow"] = 6,
											["Arcanjo"] = 28,
											["Lazerwolf"] = 15,
										},
										["n_dmg"] = 49,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 49,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 12,
										["spellschool"] = 1,
										["MISS"] = 2,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 416.006994,
							["end_time"] = 1755738754,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738723,
							["serial"] = "0xF1300000500033E2",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 60,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 60,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 60,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 3,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 60,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Arcanjo"] = true,
				},
				["CombatStartedAt"] = 9295.757,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					152.965864, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					104, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:12:16",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "Kobold Laborer",
				["TotalElapsedCombatTime"] = 11.46599999999853,
				["CombatEndedAt"] = 9277.433999999999,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:12:04",
				["end_time"] = 9277.975,
				["combat_id"] = 60,
				["tempo_start"] = 1755738723,
				["frags"] = {
					["Kobold Laborer"] = 4,
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 104.005374,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["combat_counter"] = 101,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 9265.964,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [15]
			{
				{
					["tipo"] = 2,
					["combatId"] = 59,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007963,
							["damage_from"] = {
								["Defias Thug"] = true,
							},
							["targets"] = {
								["Garrick Padfoot"] = 39,
								["Defias Thug"] = 83,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 122.007963,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 122.007963,
							["delay"] = 1755738491,
							["dps_started"] = false,
							["end_time"] = 1755738723,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 15.007963,
							["nome"] = "Wovv",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Garrick Padfoot"] = 5,
											["Defias Thug"] = 28,
										},
										["n_dmg"] = 33,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 33,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["MISS"] = 4,
									}, -- [1]
									[1752] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 12,
										["targets"] = {
											["Garrick Padfoot"] = 19,
											["Defias Thug"] = 32,
										},
										["n_dmg"] = 51,
										["n_min"] = 9,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 51,
										["c_max"] = 0,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["Garrick Padfoot"] = 15,
											["Defias Thug"] = 20,
										},
										["n_dmg"] = 35,
										["n_min"] = 15,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 35,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 3,
										["targets"] = {
											["Defias Thug"] = 3,
										},
										["n_dmg"] = 3,
										["n_min"] = 3,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 3,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 15.24146945659116,
							["colocacao"] = 1,
							["last_event"] = 1755738491,
							["on_hold"] = false,
							["start_time"] = 1755738699,
							["serial"] = "0x000000000001C681",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00697,
							["damage_from"] = {
								["Environment (Falling)"] = true,
								["Garrick Padfoot"] = true,
							},
							["targets"] = {
								["Garrick Padfoot"] = 91,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 91.00697,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738472,
							["total"] = 91.00697,
							["damage_taken"] = 25.00697,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 14,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Garrick Padfoot"] = 29,
										},
										["n_dmg"] = 15,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 29,
										["c_max"] = 14,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 4,
										["a_dmg"] = 0,
										["c_min"] = 14,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 20,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Garrick Padfoot"] = 39,
										},
										["n_dmg"] = 19,
										["n_min"] = 8,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 39,
										["c_max"] = 20,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 20,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 23,
										["targets"] = {
											["Garrick Padfoot"] = 23,
										},
										["n_dmg"] = 23,
										["n_min"] = 23,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 23,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 11.36876577139402,
							["colocacao"] = 2,
							["last_event"] = 1755738472,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738464,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006463,
							["damage_from"] = {
								["Arcanjo"] = true,
								["Wovv"] = true,
							},
							["targets"] = {
								["Arcanjo"] = 16,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 16.006463,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1755738472,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 130.006463,
							["nome"] = "Garrick Padfoot",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 6,
										["targets"] = {
											["Arcanjo"] = 16,
										},
										["n_dmg"] = 16,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 16,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["total"] = 16.006463,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1755738470,
							["on_hold"] = false,
							["start_time"] = 1755738464,
							["serial"] = "0xF1300000670032D0",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 59,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 59,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 59,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 3,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000000887D",
							["last_event"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Wovv",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 2,
								[2098] = 1,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000001C681",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 59,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Wovv"] = true,
					["Arcanjo"] = true,
				},
				["CombatStartedAt"] = 9007.214,
				["tempo_start"] = 1755738464,
				["last_events_tables"] = {
				},
				["combat_counter"] = 100,
				["totals"] = {
					228.8759910000001, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["Wovv"] = {
						{
							true, -- [1]
							1, -- [2]
							3, -- [3]
							1755738488.463, -- [4]
							0, -- [5]
							"Defias Thug", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							0, -- [10]
						}, -- [1]
						{
							true, -- [1]
							1, -- [2]
							3, -- [3]
							1755738490.472, -- [4]
							0, -- [5]
							"Defias Thug", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							0, -- [10]
						}, -- [2]
						{
							true, -- [1]
							1, -- [2]
							3, -- [3]
							1755738492.51, -- [4]
							0, -- [5]
							"Defias Thug", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							0, -- [10]
						}, -- [3]
						{
							true, -- [1]
							1, -- [2]
							3, -- [3]
							1755738494.519, -- [4]
							0, -- [5]
							"Defias Thug", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							0, -- [10]
						}, -- [4]
						{
							true, -- [1]
							1, -- [2]
							3, -- [3]
							1755738496.601, -- [4]
							0, -- [5]
							"Defias Thug", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							0, -- [10]
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 6,
					},
					["Arcanjo"] = {
						{
							true, -- [1]
							3, -- [2]
							9, -- [3]
							1755738676.746, -- [4]
							121, -- [5]
							"Environment (Falling)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:07:53",
				["cleu_timeline"] = {
				},
				["enemy"] = "Garrick Padfoot",
				["TotalElapsedCombatTime"] = 7.247999999999593,
				["CombatEndedAt"] = 9014.462,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Arcanjo"] = 91.00697,
							["Wovv"] = 39.007963,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 9015.215,
				["combat_id"] = 59,
				["overall_added"] = true,
				["data_inicio"] = "22:07:45",
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["contra"] = "Garrick Padfoot",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					213, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 9007.210000000001,
				["TimeData"] = {
				},
				["frags"] = {
					["Defias Thug"] = 1,
					["Garrick Padfoot"] = 1,
				},
			}, -- [16]
			{
				{
					["tipo"] = 2,
					["combatId"] = 58,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008855,
							["damage_from"] = {
								["Defias Thug"] = true,
							},
							["targets"] = {
								["Defias Thug"] = 54,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 54.008855,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738455,
							["total"] = 54.008855,
							["damage_taken"] = 14.008855,
							["nome"] = "Wovv",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 8,
										["targets"] = {
											["Defias Thug"] = 22,
										},
										["n_dmg"] = 22,
										["n_min"] = 7,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 22,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["MISS"] = 1,
									}, -- [1]
									[1752] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 22,
										["g_amt"] = 0,
										["n_max"] = 10,
										["targets"] = {
											["Defias Thug"] = 32,
										},
										["n_dmg"] = 10,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 32,
										["c_max"] = 22,
										["id"] = 1752,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["PARRY"] = 1,
										["c_min"] = 22,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 10.77590881883345,
							["colocacao"] = 1,
							["last_event"] = 1755738455,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738450,
							["serial"] = "0x000000000001C681",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00319,
							["damage_from"] = {
							},
							["targets"] = {
								["Defias Thug"] = 43,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 43.00319,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738455,
							["total"] = 43.00319,
							["damage_taken"] = 0.00319,
							["nome"] = "Arcanjo",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 7,
										["targets"] = {
											["Defias Thug"] = 13,
										},
										["n_dmg"] = 13,
										["n_min"] = 6,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 13,
										["c_max"] = 0,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									}, -- [1]
									[53] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["Defias Thug"] = 19,
										},
										["n_dmg"] = 19,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 19,
										["c_max"] = 0,
										["id"] = 53,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									[2098] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 11,
										["targets"] = {
											["Defias Thug"] = 11,
										},
										["n_dmg"] = 11,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 11,
										["c_max"] = 0,
										["id"] = 2098,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 8.580045889863255,
							["colocacao"] = 2,
							["last_event"] = 1755738455,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738453,
							["serial"] = "0x000000000000887D",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006914,
							["damage_from"] = {
								["Arcanjo"] = true,
								["Tuggboat"] = true,
								["Wovv"] = true,
								["Palkane"] = true,
								["Airwin"] = true,
							},
							["targets"] = {
								["Palkane"] = 20,
								["Wovv"] = 14,
								["Tuggboat"] = 9,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 43.006914,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1755738464,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 185.006914,
							["nome"] = "Defias Thug",
							["spells"] = {
								["_ActorTable"] = {
									{
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 10,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Palkane"] = 20,
											["Wovv"] = 14,
											["Tuggboat"] = 9,
										},
										["n_dmg"] = 33,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 43,
										["c_max"] = 10,
										["id"] = 1,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["spellschool"] = 1,
										["a_amt"] = 0,
										["c_min"] = 10,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 8,
										["MISS"] = 1,
										["DODGE"] = 1,
									}, -- [1]
								},
								["tipo"] = 2,
							},
							["total"] = 43.006914,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1755738464,
							["on_hold"] = false,
							["start_time"] = 1755738450,
							["serial"] = "0xF1300000260032BF",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 58,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 58,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 58,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 1755738453,
							["buff_uptime"] = 3,
							["tipo"] = 4,
							["spell_cast"] = {
								[53] = 1,
								[2098] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[1784] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 1784,
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "0x000000000000887D",
							["classe"] = "ROGUE",
						}, -- [1]
						{
							["flag_original"] = 1298,
							["nome"] = "Wovv",
							["grupo"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								[1752] = 3,
							},
							["tipo"] = 4,
							["classe"] = "ROGUE",
							["serial"] = "0x000000000001C681",
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 58,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Wovv"] = true,
					["Arcanjo"] = true,
				},
				["CombatStartedAt"] = 8996.082,
				["tempo_start"] = 1755738450,
				["last_events_tables"] = {
				},
				["combat_counter"] = 99,
				["totals"] = {
					139.989489, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:07:36",
				["cleu_timeline"] = {
				},
				["enemy"] = "Defias Thug",
				["TotalElapsedCombatTime"] = 1.869999999998981,
				["CombatEndedAt"] = 8997.951999999999,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Wovv"] = 54.008855,
							["Arcanjo"] = 43.00319,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 8998.116,
				["combat_id"] = 58,
				["overall_added"] = true,
				["data_inicio"] = "22:07:31",
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["contra"] = "Defias Thug",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					97, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 8993.103999999999,
				["TimeData"] = {
				},
				["frags"] = {
					["Defias Thug"] = 1,
				},
			}, -- [17]
			{
				{
					["tipo"] = 2,
					["combatId"] = 57,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008881,
							["damage_from"] = {
							},
							["targets"] = {
								["Rabbit"] = 5,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5.008881,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1755738373,
							["total"] = 5.008881,
							["damage_taken"] = 0.008881,
							["nome"] = "Wovv",
							["spells"] = {
								["_ActorTable"] = {
									[2764] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 5,
										["targets"] = {
											["Rabbit"] = 5,
										},
										["n_dmg"] = 5,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 5,
										["c_max"] = 0,
										["id"] = 2764,
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["b_dmg"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["custom"] = 0,
							["last_dps"] = 5.018918837668251,
							["colocacao"] = 1,
							["last_event"] = 1755738372,
							["friendlyfire"] = {
							},
							["start_time"] = 1755738372,
							["serial"] = "0x000000000001C681",
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.00395,
							["damage_from"] = {
								["Wovv"] = true,
								["Herpexflarex"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00395,
							["last_event"] = 0,
							["fight_component"] = true,
							["total"] = 0.00395,
							["delay"] = 0,
							["classe"] = "UNKNOW",
							["nome"] = "Rabbit",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 8.00395,
							["end_time"] = 1755738373,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1755738373,
							["serial"] = "0xF1300002D10001C7",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 57,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 57,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 57,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "Arcanjo",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["last_event"] = 1755738373,
							["tipo"] = 4,
							["buff_uptime"] = 1,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									[1784] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = 1784,
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "0x000000000000887D",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 57,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["Wovv"] = true,
					["Arcanjo"] = true,
				},
				["tempo_start"] = 1755738372,
				["last_events_tables"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["Wovv"] = 5.008881,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["enemy"] = "Rabbit",
				["combat_counter"] = 98,
				["totals"] = {
					4.967610999999966, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["spells_cast_timeline"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:06:12",
				["end_time"] = 8915.710000000001,
				["overall_added"] = true,
				["instance_type"] = "none",
				["combat_id"] = 57,
				["cleu_timeline"] = {
				},
				["hasSaved"] = true,
				["frags"] = {
					["Rabbit"] = 1,
				},
				["data_fim"] = "22:06:13",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					5, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 8914.712,
				["TimeData"] = {
				},
				["pvp"] = true,
			}, -- [18]
		},
	},
	["combat_counter"] = 116,
	["force_font_outline"] = "",
	["tabela_instancias"] = {
	},
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["is_open"] = true,
			["isLocked"] = false,
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -616.5053133123762,
					["x"] = 1055.507307689441,
					["w"] = 410.9998423674131,
					["h"] = 112.9999669689633,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["last_instance_id"] = 0,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["next"] = "",
		["custom"] = "",
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["reverse"] = false,
		["channel"] = "SELF",
	},
	["active_profile"] = "Arcanjo Ui Details",
	["last_realversion"] = 140,
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["enabled"] = true,
			["encounter_timers_bw"] = {
			},
			["max_emote_segments"] = 3,
			["author"] = "Details! Team",
			["window_scale"] = 1,
			["encounter_timers_dbm"] = {
			},
			["show_icon"] = 5,
			["opened"] = 0,
			["hide_on_combat"] = false,
		},
		["DETAILS_PLUGIN_CHART_VIEWER"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
			["tabs"] = {
				{
					["name"] = "Your Damage",
					["segment_type"] = 2,
					["version"] = "v2.0",
					["data"] = "Player Damage Done",
					["texture"] = "line",
				}, -- [1]
				{
					["name"] = "Class Damage",
					["iType"] = "raid-DAMAGER",
					["segment_type"] = 1,
					["version"] = "v2.0",
					["data"] = "PRESET_DAMAGE_SAME_CLASS",
					["texture"] = "line",
				}, -- [2]
				{
					["name"] = "Raid Damage",
					["segment_type"] = 2,
					["version"] = "v2.0",
					["data"] = "Raid Damage Done",
					["texture"] = "line",
				}, -- [3]
				["last_selected"] = 1,
			},
			["options"] = {
				["show_method"] = 4,
				["auto_create"] = true,
				["window_scale"] = 1,
			},
		},
		["DETAILS_PLUGIN_TIME_LINE"] = {
			["enabled"] = true,
			["author"] = "Details! Team",
		},
		["DETAILS_PLUGIN_DEATH_GRAPHICS"] = {
			["last_boss"] = false,
			["v1"] = true,
			["captures"] = {
				false, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
			},
			["first_run"] = true,
			["endurance_threshold"] = 3,
			["max_deaths_for_timeline"] = 5,
			["deaths_threshold"] = 10,
			["show_icon"] = 1,
			["max_segments_for_current"] = 2,
			["max_deaths_for_current"] = 20,
			["last_player"] = false,
			["author"] = "Details! Team",
			["last_encounter_hash"] = false,
			["enabled"] = true,
			["timeline_cutoff_time"] = 3,
			["last_segment"] = false,
			["last_combat_id"] = 0,
			["timeline_cutoff_delete_time"] = 3,
			["showing_type"] = 4,
			["InstalledAt"] = 1755568638,
		},
	},
	["last_instance_time"] = 0,
	["cached_talents"] = {
		["0x000000000000887D"] = "0/0/0",
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["on_death_menu"] = true,
	["combat_id"] = 74,
	["savedStyles"] = {
	},
	["last_version"] = "v8.3.0.7269",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.4280119999999999,
					["damage_from"] = {
						["Defias Thug"] = true,
						["Young Wolf"] = true,
						["Swiftpaw"] = true,
						["Kobold Vermin"] = true,
						["Kobold Worker"] = true,
						["Garrick Padfoot"] = true,
						["Kobold Laborer"] = true,
					},
					["targets"] = {
						["Garrick Padfoot"] = 135,
						["Young Wolf"] = 678,
						["Swiftpaw"] = 165,
						["Defias Thug"] = 1544,
						["Kobold Worker"] = 1073,
						["Kobold Vermin"] = 861,
						["Kobold Laborer"] = 963,
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["tipo"] = 1,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 5419.428012000001,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1755569166,
					["total"] = 5419.428012000001,
					["on_hold"] = false,
					["nome"] = "Arcanjo",
					["spec"] = 0,
					["grupo"] = true,
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 44,
								["b_amt"] = 8,
								["c_dmg"] = 534,
								["g_amt"] = 5,
								["n_max"] = 8,
								["targets"] = {
									["Garrick Padfoot"] = 39,
									["Young Wolf"] = 253,
									["Swiftpaw"] = 60,
									["Defias Thug"] = 628,
									["Kobold Worker"] = 551,
									["Kobold Vermin"] = 337,
									["Kobold Laborer"] = 378,
								},
								["n_dmg"] = 1690,
								["n_min"] = 0,
								["g_dmg"] = 22,
								["counter"] = 387,
								["total"] = 2246,
								["c_max"] = 16,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["DODGE"] = 21,
								["MISS"] = 20,
								["PARRY"] = 7,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 33,
								["n_amt"] = 290,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							}, -- [1]
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Defias Thug"] = 0,
								},
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = 2,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							}, -- [2]
							[53] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 23,
								["targets"] = {
									["Swiftpaw"] = 17,
									["Kobold Worker"] = 43,
									["Garrick Padfoot"] = 14,
									["Defias Thug"] = 42,
								},
								["n_dmg"] = 116,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 116,
								["c_max"] = 0,
								["id"] = 53,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							[1752] = {
								["c_amt"] = 20,
								["b_amt"] = 12,
								["c_dmg"] = 384,
								["g_amt"] = 0,
								["n_max"] = 12,
								["targets"] = {
									["Garrick Padfoot"] = 46,
									["Young Wolf"] = 224,
									["Swiftpaw"] = 51,
									["Defias Thug"] = 421,
									["Kobold Worker"] = 266,
									["Kobold Vermin"] = 263,
									["Kobold Laborer"] = 424,
								},
								["n_dmg"] = 1311,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 181,
								["total"] = 1695,
								["c_max"] = 24,
								["id"] = 1752,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 99,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 142,
								["DODGE"] = 8,
								["MISS"] = 11,
							},
							[2098] = {
								["c_amt"] = 7,
								["b_amt"] = 1,
								["c_dmg"] = 256,
								["g_amt"] = 0,
								["n_max"] = 37,
								["targets"] = {
									["Garrick Padfoot"] = 36,
									["Young Wolf"] = 187,
									["Swiftpaw"] = 37,
									["Defias Thug"] = 370,
									["Kobold Worker"] = 191,
									["Kobold Vermin"] = 206,
									["Kobold Laborer"] = 138,
								},
								["n_dmg"] = 909,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 70,
								["total"] = 1165,
								["c_max"] = 46,
								["id"] = 2098,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["MISS"] = 5,
								["DODGE"] = 4,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 52,
								["b_dmg"] = 18,
								["r_amt"] = 0,
							},
							[2764] = {
								["c_amt"] = 7,
								["b_amt"] = 1,
								["c_dmg"] = 62,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["Young Wolf"] = 14,
									["Defias Thug"] = 83,
									["Kobold Worker"] = 22,
									["Kobold Vermin"] = 55,
									["Kobold Laborer"] = 23,
								},
								["n_dmg"] = 135,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 42,
								["total"] = 197,
								["c_max"] = 10,
								["id"] = 2764,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 3,
								["n_amt"] = 35,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 778.4280120000001,
					["start_time"] = 1755568479,
					["serial"] = "0x000000000000887D",
					["friendlyfire_total"] = 0,
				}, -- [1]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.15141,
					["damage_from"] = {
						["Leiandrann"] = true,
						["Chodem"] = true,
						["Pulselezz"] = true,
						["Hams"] = true,
						["Tugboatt"] = true,
						["Xwife"] = true,
						["Zodiarkk"] = true,
						["Arcanjo"] = true,
						["Pileofrocks"] = true,
						["Klicc"] = true,
						["Vaermina"] = true,
						["Pepperr"] = true,
						["Evothehunter"] = true,
					},
					["targets"] = {
						["Kleacy"] = 0,
						["Lemonz"] = 0,
						["Genevieve"] = 0,
						["Nusko"] = 0,
						["Tator"] = 0,
						["Youneek"] = 0,
						["Pileofrocks"] = 2,
						["Pepperr"] = 3,
						["Danktank"] = 0,
						["Ramble"] = 0,
						["Doomina"] = 0,
						["Hams"] = 23,
						["Metatron"] = 0,
						["Lhommeananas"] = 0,
						["Painful"] = 0,
						["Czechcee"] = 0,
						["Roque"] = 0,
						["Kaljier"] = 2,
						["Igon"] = 2,
						["Vaze"] = 0,
						["Mallachai"] = 0,
						["Xyechekk"] = 0,
						["Gigabis"] = 0,
						["Notte"] = 0,
						["Jersplivy"] = 0,
						["Pey"] = 0,
						["Humigigiba"] = 0,
						["Weinergirl"] = 0,
						["Djisamsoe"] = 0,
						["Huntreebs"] = 0,
						["Conkers"] = 0,
						["Olmanjoe"] = 0,
						["Vadopa"] = 0,
						["Badtrip"] = 0,
						["Pulselezz"] = 1,
						["Valorian"] = 0,
						["Kayrog"] = 0,
						["Harz"] = 0,
						["Kalifer"] = 0,
						["Auffheimler"] = 0,
						["Rocim"] = 0,
						["Borradorr"] = 0,
						["Denna"] = 0,
						["Vaermina"] = 5,
						["Nifira"] = 0,
						["Zylust"] = 0,
						["Midnightenvy"] = 0,
						["Jolyna"] = 0,
						["Isma"] = 0,
						["Ammara"] = 0,
						["Sunchlp"] = 0,
						["Gowno"] = 0,
						["Delighted"] = 0,
						["Klicc"] = 0,
						["Tacodilla"] = 0,
						["Totoro"] = 0,
						["Mullenkamp"] = 0,
						["Nemps"] = 0,
						["Quickie"] = 0,
						["Melodiana"] = 0,
						["Oakridge"] = 0,
						["Osito"] = 0,
						["Leiandrann"] = 2,
						["Grinjrform"] = 0,
						["Narcine"] = 0,
						["Dekoth"] = 0,
						["Badmfer"] = 0,
						["Corrox"] = 0,
						["Xniggaraper"] = 0,
						["Entilzha"] = 0,
						["Evothehunter"] = 4,
						["Mnightshinod"] = 0,
						["Jagorski"] = 0,
						["Elliana"] = 0,
						["Shalewind"] = 0,
						["Harfiend"] = 0,
						["Mashura"] = 0,
						["Frootloop"] = 0,
						["Sosochekk"] = 0,
						["Dakota"] = 0,
						["Alfreedus"] = 0,
						["Vaskar"] = 0,
						["Laika"] = 0,
						["Sayleh"] = 0,
						["Tugboatt"] = 8,
						["Necaj"] = 0,
						["Dreneth"] = 0,
						["Darkalma"] = 0,
						["Cherrywulf"] = 0,
						["Yasmine"] = 0,
						["Mystereo"] = 0,
						["Dulla"] = 0,
						["Rendyne"] = 0,
						["Zodiarkk"] = 2,
						["Aylia"] = 0,
						["Pumah"] = 0,
						["Yunaara"] = 0,
						["Choli"] = 0,
						["Zendren"] = 0,
						["Magenius"] = 0,
						["Valnor"] = 0,
						["Baldwen"] = 0,
						["Masisi"] = 0,
						["Warann"] = 0,
						["Yellowpanda"] = 0,
						["Dobryden"] = 0,
						["Kopari"] = 0,
						["Ventrix"] = 0,
						["Creta"] = 0,
						["Lighthero"] = 0,
						["Rokar"] = 0,
						["Mematt"] = 0,
						["Sorion"] = 0,
						["Cumbusta"] = 0,
						["Brecon"] = 0,
						["Moubia"] = 0,
						["Drows"] = 0,
						["Yantae"] = 0,
						["Crislet"] = 0,
						["Arcanjo"] = 37,
						["Tarfip <Czechcee>"] = 0,
						["Medaveh"] = 0,
						["Asukalangley"] = 0,
						["Ixibank"] = 0,
						["Grillo"] = 0,
						["Xndr"] = 0,
						["Honeysuckle"] = 0,
						["Rhelt"] = 0,
						["Aidanlynch"] = 0,
						["Hekate"] = 0,
						["Piplop"] = 0,
						["Rabbit"] = 0,
						["Mambofive"] = 0,
						["Kleinhunt"] = 0,
						["Biju"] = 0,
						["Crazee"] = 0,
						["Xwife"] = 5,
						["Goresoak"] = 0,
						["Pyriah"] = 2,
						["Ragebringer"] = 0,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 98.15141000000001,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["end_time"] = 1755569166,
					["delay"] = 0,
					["on_hold"] = false,
					["nome"] = "Young Wolf",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 12,
								["g_amt"] = 0,
								["n_max"] = 1,
								["targets"] = {
									["Kleacy"] = 0,
									["Lemonz"] = 0,
									["Genevieve"] = 0,
									["Nusko"] = 0,
									["Tator"] = 0,
									["Youneek"] = 0,
									["Pileofrocks"] = 2,
									["Pepperr"] = 1,
									["Danktank"] = 0,
									["Ramble"] = 0,
									["Doomina"] = 0,
									["Hams"] = 19,
									["Metatron"] = 0,
									["Lhommeananas"] = 0,
									["Painful"] = 0,
									["Roque"] = 0,
									["Kaljier"] = 2,
									["Igon"] = 2,
									["Vaze"] = 0,
									["Mallachai"] = 0,
									["Xyechekk"] = 0,
									["Gigabis"] = 0,
									["Notte"] = 0,
									["Jersplivy"] = 0,
									["Pey"] = 0,
									["Humigigiba"] = 0,
									["Weinergirl"] = 0,
									["Djisamsoe"] = 0,
									["Huntreebs"] = 0,
									["Asukalangley"] = 0,
									["Olmanjoe"] = 0,
									["Vadopa"] = 0,
									["Badtrip"] = 0,
									["Pulselezz"] = 1,
									["Valorian"] = 0,
									["Kayrog"] = 0,
									["Harz"] = 0,
									["Kalifer"] = 0,
									["Auffheimler"] = 0,
									["Rocim"] = 0,
									["Borradorr"] = 0,
									["Denna"] = 0,
									["Choli"] = 0,
									["Nifira"] = 0,
									["Zylust"] = 0,
									["Midnightenvy"] = 0,
									["Jolyna"] = 0,
									["Isma"] = 0,
									["Ammara"] = 0,
									["Sunchlp"] = 0,
									["Gowno"] = 0,
									["Delighted"] = 0,
									["Klicc"] = 0,
									["Tacodilla"] = 0,
									["Totoro"] = 0,
									["Mullenkamp"] = 0,
									["Nemps"] = 0,
									["Quickie"] = 0,
									["Melodiana"] = 0,
									["Oakridge"] = 0,
									["Osito"] = 0,
									["Leiandrann"] = 0,
									["Grinjrform"] = 0,
									["Narcine"] = 0,
									["Dekoth"] = 0,
									["Badmfer"] = 0,
									["Corrox"] = 0,
									["Piplop"] = 0,
									["Chodem"] = 0,
									["Entilzha"] = 0,
									["Evothehunter"] = 2,
									["Mnightshinod"] = 0,
									["Jagorski"] = 0,
									["Elliana"] = 0,
									["Shalewind"] = 0,
									["Harfiend"] = 0,
									["Mashura"] = 0,
									["Frootloop"] = 0,
									["Sosochekk"] = 0,
									["Dakota"] = 0,
									["Alfreedus"] = 0,
									["Vaskar"] = 0,
									["Hekate"] = 0,
									["Sayleh"] = 0,
									["Tugboatt"] = 8,
									["Necaj"] = 0,
									["Dreneth"] = 0,
									["Darkalma"] = 0,
									["Cherrywulf"] = 0,
									["Yasmine"] = 0,
									["Mystereo"] = 0,
									["Rendyne"] = 0,
									["Aylia"] = 0,
									["Pumah"] = 0,
									["Yunaara"] = 0,
									["Yellowpanda"] = 0,
									["Zodiarkk"] = 2,
									["Vaermina"] = 5,
									["Zendren"] = 0,
									["Baldwen"] = 0,
									["Masisi"] = 0,
									["Dulla"] = 0,
									["Magenius"] = 0,
									["Warann"] = 0,
									["Xniggaraper"] = 0,
									["Ventrix"] = 0,
									["Kopari"] = 0,
									["Rabbit"] = 0,
									["Ixibank"] = 0,
									["Lighthero"] = 0,
									["Sorion"] = 0,
									["Cumbusta"] = 0,
									["Brecon"] = 0,
									["Rokar"] = 0,
									["Mematt"] = 0,
									["Moubia"] = 0,
									["Crislet"] = 0,
									["Laika"] = 0,
									["Arcanjo"] = 37,
									["Creta"] = 0,
									["Drows"] = 0,
									["Yantae"] = 0,
									["Grillo"] = 0,
									["Xndr"] = 0,
									["Honeysuckle"] = 0,
									["Rhelt"] = 0,
									["Aidanlynch"] = 0,
									["Conkers"] = 0,
									["Valnor"] = 0,
									["Dobryden"] = 0,
									["Mambofive"] = 0,
									["Kleinhunt"] = 0,
									["Biju"] = 0,
									["Crazee"] = 0,
									["Xwife"] = 5,
									["Goresoak"] = 0,
									["Pyriah"] = 2,
									["Ragebringer"] = 0,
								},
								["n_dmg"] = 76,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 98,
								["total"] = 88,
								["c_max"] = 2,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 13,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 76,
								["a_dmg"] = 0,
								["MISS"] = 3,
							}, -- [1]
							[87634] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["Olmanjoe"] = 0,
									["Lemonz"] = 0,
									["Quickie"] = 0,
									["Pulselezz"] = 0,
									["Nusko"] = 0,
									["Tugboatt"] = 0,
									["Xwife"] = 0,
									["Dreneth"] = 0,
									["Darkalma"] = 0,
									["Yellowpanda"] = 0,
									["Mystereo"] = 0,
									["Pepperr"] = 2,
									["Rendyne"] = 0,
									["Dekoth"] = 0,
									["Badmfer"] = 0,
									["Metatron"] = 0,
									["Auffheimler"] = 0,
									["Biju"] = 0,
									["Baldwen"] = 0,
									["Piplop"] = 0,
									["Czechcee"] = 0,
									["Hams"] = 4,
									["Badtrip"] = 0,
									["Ixibank"] = 0,
									["Dulla"] = 0,
									["Borradorr"] = 0,
									["Vaermina"] = 0,
									["Evothehunter"] = 2,
									["Cumbusta"] = 0,
									["Vaze"] = 0,
									["Mnightshinod"] = 0,
									["Melodiana"] = 0,
									["Magenius"] = 0,
									["Crislet"] = 0,
									["Medaveh"] = 0,
									["Tarfip <Czechcee>"] = 0,
									["Mambofive"] = 0,
									["Isma"] = 0,
									["Sorion"] = 0,
									["Igon"] = 0,
									["Frootloop"] = 0,
									["Drows"] = 0,
									["Aidanlynch"] = 0,
									["Humigigiba"] = 0,
									["Harfiend"] = 0,
									["Cherrywulf"] = 0,
									["Dakota"] = 0,
									["Klicc"] = 0,
									["Alfreedus"] = 0,
									["Valorian"] = 0,
									["Hekate"] = 0,
									["Harz"] = 0,
									["Totoro"] = 0,
									["Leiandrann"] = 2,
									["Mullenkamp"] = 0,
								},
								["n_dmg"] = 10,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 10,
								["c_max"] = 0,
								["id"] = 87634,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["fight_component"] = true,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 1411.15141,
					["start_time"] = 1755569001,
					["serial"] = "0xF13000012B010081",
					["total"] = 98.15141000000001,
				}, -- [2]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.071492,
					["damage_from"] = {
						["Leiandrann"] = true,
						["Sampson"] = true,
						["Chodem"] = true,
						["Pyriah"] = true,
						["Kaljier"] = true,
						["Zodiarkk"] = true,
						["Kleinhunt"] = true,
						["Xwife"] = true,
						["Zylust"] = true,
						["Arcanjo"] = true,
						["Warann"] = true,
						["Tugboatt"] = true,
						["Baldwen"] = true,
						["Magenius"] = true,
						["Alfreedus"] = true,
					},
					["targets"] = {
						["Sampson"] = 27,
						["Chodem"] = 17,
						["Pyriah"] = 8,
						["Kaljier"] = 8,
						["Igon"] = 0,
						["Tugboatt"] = 28,
						["Xwife"] = 22,
						["Zylust"] = 2,
						["Arcanjo"] = 60,
						["Keltix"] = 0,
						["Leiandrann"] = 29,
						["Gowno"] = 0,
						["Baldwen"] = 2,
						["Kleinhunt"] = 12,
						["Warann"] = 34,
						["Valavar"] = 0,
						["Zodiarkk"] = 38,
						["Magenius"] = 14,
						["Mullenkamp"] = 0,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 301.0714920000002,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 301.0714920000002,
					["serial"] = "0xF1300000060027CD",
					["on_hold"] = false,
					["nome"] = "Kobold Vermin",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 9,
								["b_amt"] = 0,
								["c_dmg"] = 26,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["Sampson"] = 27,
									["Chodem"] = 17,
									["Pyriah"] = 8,
									["Kaljier"] = 8,
									["Igon"] = 0,
									["Tugboatt"] = 28,
									["Xwife"] = 22,
									["Zylust"] = 2,
									["Arcanjo"] = 60,
									["Keltix"] = 0,
									["Leiandrann"] = 29,
									["Gowno"] = 0,
									["Baldwen"] = 2,
									["Kleinhunt"] = 12,
									["Warann"] = 34,
									["Valavar"] = 0,
									["Zodiarkk"] = 38,
									["Magenius"] = 14,
									["Mullenkamp"] = 0,
								},
								["n_dmg"] = 275,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 205,
								["total"] = 301,
								["c_max"] = 4,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 11,
								["DODGE"] = 28,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 157,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["end_time"] = 1755735677,
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 2695.071492,
					["start_time"] = 1755735542,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [3]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.153926,
					["damage_from"] = {
						["Rulqua"] = true,
						["Sorion"] = true,
						["Igon"] = true,
						["Tugboatt"] = true,
						["Xwife"] = true,
						["Arcanjo"] = true,
						["Sunchlp"] = true,
						["Warguy"] = true,
						["Narcine"] = true,
						["Kaljier"] = true,
						["Magenius"] = true,
						["Thederex"] = true,
						["Xndr"] = true,
						["Melodiana"] = true,
						["Baldwen"] = true,
						["Prezcamacho"] = true,
						["Warann"] = true,
						["Kleinhunt"] = true,
						["Lazerwolf"] = true,
						["Vivid"] = true,
						["Mullenkamp"] = true,
					},
					["targets"] = {
						["Sorion"] = 36,
						["Igon"] = 30,
						["Tugboatt"] = 39,
						["Xwife"] = 3,
						["Arcanjo"] = 144,
						["Sunchlp"] = 42,
						["Gowno"] = 3,
						["Narcine"] = 3,
						["Prezcamacho"] = 27,
						["Vivid"] = 12,
						["Magenius"] = 12,
						["Xndr"] = 33,
						["Baldwen"] = 15,
						["Melodiana"] = 60,
						["Warann"] = 30,
						["Warguy"] = 77,
						["Lazerwolf"] = 9,
						["Thederex"] = 9,
						["Kaljier"] = 3,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 587.1539259999997,
					["on_hold"] = false,
					["dps_started"] = false,
					["end_time"] = 1755735677,
					["serial"] = "0xF130000101002844",
					["friendlyfire"] = {
					},
					["nome"] = "Kobold Worker",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 5,
								["b_amt"] = 1,
								["c_dmg"] = 30,
								["g_amt"] = 0,
								["n_max"] = 3,
								["targets"] = {
									["Sorion"] = 36,
									["Igon"] = 30,
									["Tugboatt"] = 39,
									["Xwife"] = 3,
									["Arcanjo"] = 144,
									["Sunchlp"] = 42,
									["Gowno"] = 3,
									["Narcine"] = 3,
									["Prezcamacho"] = 27,
									["Vivid"] = 12,
									["Magenius"] = 12,
									["Xndr"] = 33,
									["Baldwen"] = 15,
									["Warguy"] = 77,
									["Warann"] = 30,
									["Melodiana"] = 60,
									["Lazerwolf"] = 9,
									["Thederex"] = 9,
									["Kaljier"] = 3,
								},
								["n_dmg"] = 557,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 227,
								["total"] = 587,
								["c_max"] = 6,
								["id"] = 1,
								["r_dmg"] = 0,
								["MISS"] = 9,
								["DODGE"] = 27,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 186,
								["b_dmg"] = 2,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["total"] = 587.1539259999997,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 3037.153926,
					["start_time"] = 1755735448,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [4]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.109111,
					["damage_from"] = {
						["Badtrip"] = true,
						["Rulqua"] = true,
						["Brumbl"] = true,
						["Zodiarkk"] = true,
						["Xwife"] = true,
						["Valavar"] = true,
						["Cherrywulf"] = true,
						["Palkane"] = true,
						["Apteczka"] = true,
						["Huntinyou"] = true,
						["Prezcamacho"] = true,
						["Narcine"] = true,
						["Succubi"] = true,
						["Wovv"] = true,
						["Baldwen"] = true,
						["Zeppep"] = true,
						["Aeliri"] = true,
						["Jonmaple"] = true,
						["Sampson"] = true,
						["Pyriah"] = true,
						["Igon"] = true,
						["Crislet"] = true,
						["Airwin"] = true,
						["Tuggboat"] = true,
						["Delek"] = true,
						["Vivid"] = true,
						["Dakota"] = true,
						["Siluca"] = true,
						["Magenius"] = true,
						["Staccato"] = true,
						["Warann"] = true,
						["Arcanjo"] = true,
						["Kleinhunt"] = true,
						["Misfired"] = true,
						["Mullenkamp"] = true,
					},
					["targets"] = {
						["Jonmaple"] = 41,
						["Sampson"] = 126,
						["Badtrip"] = 12,
						["Pyriah"] = 3,
						["Valavar"] = 9,
						["Brumbl"] = 60,
						["Zodiarkk"] = 18,
						["Mindchill"] = 0,
						["Xwife"] = 4,
						["Delek"] = 15,
						["Arcanjo"] = 355,
						["Siluca"] = 31,
						["Crislet"] = 10,
						["Baldwen"] = 163,
						["Palkane"] = 12,
						["Apteczka"] = 5,
						["Narcine"] = 28,
						["Magenius"] = 97,
						["Prezcamacho"] = 83,
						["Tuggboat"] = 12,
						["Succubi"] = 8,
						["Wovv"] = 32,
						["Vivid"] = 9,
						["Dakota"] = 49,
						["Igon"] = 15,
						["Lhommeananas"] = 0,
						["Staccato"] = 27,
						["Warann"] = 50,
						["Kleinhunt"] = 6,
						["Misfired"] = 12,
						["Aeliri"] = 37,
						["Mullenkamp"] = 10,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["friendlyfire"] = {
					},
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1339.109111,
					["serial"] = "0xF130000026002AFF",
					["dps_started"] = false,
					["end_time"] = 1755736357,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "Defias Thug",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 23,
								["b_amt"] = 2,
								["c_dmg"] = 172,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["Jonmaple"] = 41,
									["Sampson"] = 126,
									["Badtrip"] = 12,
									["Pyriah"] = 3,
									["Valavar"] = 9,
									["Igon"] = 15,
									["Zodiarkk"] = 18,
									["Mindchill"] = 0,
									["Xwife"] = 4,
									["Delek"] = 15,
									["Arcanjo"] = 355,
									["Siluca"] = 31,
									["Crislet"] = 10,
									["Baldwen"] = 163,
									["Palkane"] = 12,
									["Apteczka"] = 5,
									["Narcine"] = 28,
									["Kleinhunt"] = 6,
									["Prezcamacho"] = 83,
									["Tuggboat"] = 12,
									["Succubi"] = 8,
									["Wovv"] = 32,
									["Vivid"] = 9,
									["Dakota"] = 49,
									["Brumbl"] = 60,
									["Lhommeananas"] = 0,
									["Staccato"] = 27,
									["Warann"] = 50,
									["Magenius"] = 97,
									["Misfired"] = 12,
									["Aeliri"] = 37,
									["Mullenkamp"] = 10,
								},
								["n_dmg"] = 1167,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 384,
								["total"] = 1339,
								["c_max"] = 10,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 44,
								["MISS"] = 12,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 305,
								["b_dmg"] = 5,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["last_dps"] = 0,
					["total"] = 1339.109111,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 5652.109111000001,
					["start_time"] = 1755736094,
					["delay"] = 0,
					["monster"] = true,
				}, -- [5]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.019537,
					["damage_from"] = {
						["Garrick Padfoot"] = true,
						["Defias Thug"] = true,
					},
					["targets"] = {
						["Garrick Padfoot"] = 31,
						["Defias Thug"] = 26,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["classe"] = "DRUID",
					["raid_targets"] = {
					},
					["total_without_pet"] = 57.019537,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1755736562,
					["serial"] = "0x000000000001C352",
					["total"] = 57.019537,
					["nome"] = "Vivid",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 20,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["Garrick Padfoot"] = 20,
									["Defias Thug"] = 11,
								},
								["n_dmg"] = 11,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 31,
								["c_max"] = 20,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[5176] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 15,
								["targets"] = {
									["Garrick Padfoot"] = 11,
									["Defias Thug"] = 15,
								},
								["n_dmg"] = 26,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 26,
								["c_max"] = 0,
								["id"] = 5176,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 19.019537,
					["start_time"] = 1755736549,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [6]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.017495,
					["damage_from"] = {
					},
					["targets"] = {
						["Garrick Padfoot"] = 8,
						["Defias Thug"] = 33,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["classe"] = "HUNTER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 41.017495,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1755736562,
					["serial"] = "0x000000000001C365",
					["total"] = 41.017495,
					["nome"] = "Huntinyou",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["Garrick Padfoot"] = 8,
									["Defias Thug"] = 11,
								},
								["n_dmg"] = 19,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 19,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[75] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 22,
								["targets"] = {
									["Defias Thug"] = 22,
								},
								["n_dmg"] = 22,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 22,
								["c_max"] = 0,
								["id"] = 75,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.017495,
					["start_time"] = 1755736556,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [7]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.012011,
					["damage_from"] = {
						["Garrick Padfoot"] = true,
					},
					["targets"] = {
						["Garrick Padfoot"] = 34,
						["Defias Thug"] = 11,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 45.012011,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1755736562,
					["serial"] = "0x000000000001C4E4",
					["total"] = 45.012011,
					["nome"] = "Cherrywulf",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 11,
								["targets"] = {
									["Defias Thug"] = 11,
								},
								["n_dmg"] = 11,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 11,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 1,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
							[116] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 18,
								["targets"] = {
									["Garrick Padfoot"] = 34,
								},
								["n_dmg"] = 34,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 34,
								["c_max"] = 0,
								["id"] = 116,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 2,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["on_hold"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 5.012011,
					["start_time"] = 1755736552,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [8]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.018288,
					["damage_from"] = {
						["Huntinyou"] = true,
						["Arcanjo"] = true,
						["Cherrywulf"] = true,
						["Vivid"] = true,
						["Wovv"] = true,
					},
					["targets"] = {
						["Vivid"] = 10,
						["Arcanjo"] = 16,
						["Cherrywulf"] = 5,
					},
					["pets"] = {
					},
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 31.018288,
					["serial"] = "0xF130000067002BD6",
					["dps_started"] = false,
					["total"] = 31.018288,
					["classe"] = "UNKNOW",
					["on_hold"] = false,
					["nome"] = "Garrick Padfoot",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 6,
								["targets"] = {
									["Vivid"] = 10,
									["Arcanjo"] = 16,
									["Cherrywulf"] = 5,
								},
								["n_dmg"] = 31,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 31,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 6,
								["r_amt"] = 0,
								["DODGE"] = 1,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["damage_taken"] = 247.018288,
					["end_time"] = 1755736576,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1755736559,
					["delay"] = 0,
					["monster"] = true,
				}, -- [9]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.004017,
					["damage_from"] = {
						["Arcanjo"] = true,
					},
					["targets"] = {
						["Arcanjo"] = 42,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_taken"] = 165.004017,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 42.004017,
					["serial"] = "0xF13000B2D3002CF8",
					["monster"] = true,
					["end_time"] = 1755736909,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "Swiftpaw",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["Arcanjo"] = 42,
								},
								["n_dmg"] = 42,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 42,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["DODGE"] = 6,
								["MISS"] = 1,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 42.004017,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1755736884,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [10]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.029983,
					["damage_from"] = {
						["Defias Thug"] = true,
					},
					["targets"] = {
						["Rabbit"] = 5,
						["Defias Thug"] = 54,
						["Garrick Padfoot"] = 39,
					},
					["pets"] = {
					},
					["damage_taken"] = 14.029983,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 98.029983,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1755738373,
					["delay"] = 0,
					["total"] = 98.029983,
					["nome"] = "Wovv",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["Defias Thug"] = 22,
									["Garrick Padfoot"] = 5,
								},
								["n_dmg"] = 27,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 27,
								["c_max"] = 0,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 4,
								["a_dmg"] = 0,
								["MISS"] = 3,
							}, -- [1]
							[1752] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 22,
								["g_amt"] = 0,
								["n_max"] = 10,
								["targets"] = {
									["Defias Thug"] = 32,
									["Garrick Padfoot"] = 19,
								},
								["n_dmg"] = 29,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 51,
								["c_max"] = 22,
								["id"] = 1752,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							[2764] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["Defias Thug"] = 0,
									["Rabbit"] = 5,
								},
								["n_dmg"] = 5,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 5,
								["c_max"] = 0,
								["id"] = 2764,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							[2098] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 15,
								["targets"] = {
									["Defias Thug"] = 0,
									["Garrick Padfoot"] = 15,
								},
								["n_dmg"] = 15,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 15,
								["c_max"] = 0,
								["id"] = 2098,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["on_hold"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1755738360,
					["serial"] = "0x000000000001C681",
					["friendlyfire_total"] = 0,
				}, -- [11]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.006911000000000001,
					["damage_from"] = {
						["Wovv"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006911000000000001,
					["last_dps"] = 0,
					["fight_component"] = true,
					["end_time"] = 1755738373,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "Rabbit",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 5.006911,
					["total"] = 0.006911000000000001,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1755738370,
					["serial"] = "0xF1300002D10001C7",
					["dps_started"] = false,
				}, -- [12]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 0.07897900000000002,
					["damage_from"] = {
						["Rulqua"] = true,
						["Holynow"] = true,
						["Lazerwolf"] = true,
						["Dakota"] = true,
						["Arcanjo"] = true,
						["Mullenkamp"] = true,
						["Viennetta"] = true,
						["Bohunter"] = true,
						["Evander"] = true,
					},
					["targets"] = {
						["Bohunter"] = 25,
						["Holynow"] = 6,
						["Lazerwolf"] = 25,
						["Misfired"] = 0,
						["Arcanjo"] = 124,
						["Strixter"] = 0,
						["Mullenkamp"] = 6,
						["Viennetta"] = 9,
						["Rulqua"] = 3,
						["Evander"] = 78,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 276.078979,
					["damage_taken"] = 1967.078979,
					["fight_component"] = true,
					["total"] = 276.078979,
					["delay"] = 0,
					["friendlyfire"] = {
					},
					["nome"] = "Kobold Laborer",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 8,
								["g_amt"] = 0,
								["n_max"] = 5,
								["targets"] = {
									["Bohunter"] = 25,
									["Holynow"] = 6,
									["Lazerwolf"] = 25,
									["Misfired"] = 0,
									["Arcanjo"] = 124,
									["Strixter"] = 0,
									["Mullenkamp"] = 6,
									["Viennetta"] = 9,
									["Rulqua"] = 3,
									["Evander"] = 78,
								},
								["n_dmg"] = 268,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 87,
								["total"] = 276,
								["c_max"] = 8,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 71,
								["MISS"] = 4,
								["DODGE"] = 11,
							}, -- [1]
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["end_time"] = 1755738736,
					["classe"] = "UNKNOW",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1755738652,
					["serial"] = "0xF1300000500033E2",
					["dps_started"] = false,
				}, -- [13]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.063281,
					["damage_from"] = {
						["Kobold Laborer"] = true,
					},
					["targets"] = {
						["Kobold Laborer"] = 348,
					},
					["pets"] = {
					},
					["damage_taken"] = 9.063281000000002,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 348.063281,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1755738826,
					["delay"] = 0,
					["total"] = 348.063281,
					["nome"] = "Viennetta",
					["spells"] = {
						["_ActorTable"] = {
							{
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 12,
								["g_amt"] = 0,
								["n_max"] = 8,
								["targets"] = {
									["Kobold Laborer"] = 137,
								},
								["n_dmg"] = 125,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 137,
								["c_max"] = 12,
								["id"] = 1,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 18,
								["a_dmg"] = 0,
								["MISS"] = 1,
							}, -- [1]
							[1752] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 22,
								["g_amt"] = 0,
								["n_max"] = 12,
								["targets"] = {
									["Kobold Laborer"] = 180,
								},
								["n_dmg"] = 158,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 180,
								["c_max"] = 22,
								["id"] = 1752,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 15,
								["a_dmg"] = 0,
								["MISS"] = 2,
							},
							[2098] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 20,
								["targets"] = {
									["Kobold Laborer"] = 31,
								},
								["n_dmg"] = 31,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 31,
								["c_max"] = 0,
								["id"] = 2098,
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["on_hold"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1755738794,
					["serial"] = "0x000000000000C7E6",
					["friendlyfire_total"] = 0,
				}, -- [14]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["nome"] = "Arcanjo",
					["spec"] = 0,
					["grupo"] = true,
					["classe"] = "ROGUE",
					["spell_cast"] = {
						[1752] = 158,
						[53] = 2,
						[2764] = 8,
						[2098] = 70,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 4,
					["tipo"] = 4,
					["pets"] = {
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[1784] = {
								["counter"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 1784,
								["uptime"] = 4,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "0x000000000000887D",
					["last_event"] = 0,
				}, -- [1]
				{
					["fight_component"] = true,
					["nome"] = "Young Wolf",
					["tipo"] = 4,
					["spell_cast"] = {
						[87635] = 7,
					},
					["flag_original"] = 2600,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["serial"] = "0xF13000012B010558",
					["pets"] = {
					},
				}, -- [2]
				{
					["flag_original"] = 1047,
					["nome"] = "Vivid",
					["grupo"] = true,
					["buff_uptime_targets"] = {
					},
					["spell_cast"] = {
						[5176] = 2,
					},
					["classe"] = "DRUID",
					["pets"] = {
					},
					["last_event"] = 0,
					["buff_uptime"] = 30,
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[3219] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 3219,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[2374] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 2374,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[86624] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 86624,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "0x000000000001C352",
					["tipo"] = 4,
				}, -- [3]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							[116] = {
								["refreshamt"] = 1,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 116,
								["uptime"] = 4,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[6136] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = 6136,
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 20,
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							[1459] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 1459,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
							[168] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = 168,
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 4,
					["nome"] = "Cherrywulf",
					["grupo"] = true,
					["spell_cast"] = {
						[116] = 1,
						[133] = 1,
					},
					["debuff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["pets"] = {
					},
					["serial"] = "0x000000000001C4E4",
					["last_event"] = 0,
				}, -- [4]
				{
					["flag_original"] = 1298,
					["nome"] = "Wovv",
					["grupo"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						[1752] = 5,
						[2098] = 1,
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["serial"] = "0x000000000001C681",
					["classe"] = "ROGUE",
				}, -- [5]
				{
					["flag_original"] = 1298,
					["nome"] = "Viennetta",
					["grupo"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						[1752] = 16,
						[2098] = 2,
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["serial"] = "0x000000000000C7E6",
					["classe"] = "ROGUE",
				}, -- [6]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1755568656,
		["cleu_timeline"] = {
		},
		["frags"] = {
		},
		["combat_counter"] = 11,
		["totals"] = {
			14430.74395499999, -- [1]
			-0.008344000000001017, -- [2]
			{
				-0.007428999999998354, -- [1]
				[0] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
			["voidzone_damage"] = 0,
			["frags_total"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "23:05:57",
		["end_time"] = 9641.826000000001,
		["cleu_events"] = {
			["n"] = 1,
		},
		["segments_added"] = {
			{
				["elapsed"] = 7.00800000000163,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:18:12",
			}, -- [1]
			{
				["elapsed"] = 7.014000000001033,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:18:05",
			}, -- [2]
			{
				["elapsed"] = 5.003000000000611,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:17:56",
			}, -- [3]
			{
				["elapsed"] = 8.019000000000233,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:17:32",
			}, -- [4]
			{
				["elapsed"] = 5.007999999999811,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:16:55",
			}, -- [5]
			{
				["elapsed"] = 6.006000000001222,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:15:40",
			}, -- [6]
			{
				["elapsed"] = 6.009000000000015,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:15:16",
			}, -- [7]
			{
				["elapsed"] = 4.004000000000815,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:15:08",
			}, -- [8]
			{
				["elapsed"] = 3.998999999999796,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:14:55",
			}, -- [9]
			{
				["elapsed"] = 8.014999999999418,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:14:39",
			}, -- [10]
			{
				["elapsed"] = 4.003000000000611,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:14:31",
			}, -- [11]
			{
				["elapsed"] = 3.996999999999389,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:13:46",
			}, -- [12]
			{
				["elapsed"] = 3.006999999999607,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:13:43",
			}, -- [13]
			{
				["elapsed"] = 8.014999999999418,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:12:34",
			}, -- [14]
			{
				["elapsed"] = 12.01100000000042,
				["type"] = 0,
				["name"] = "Kobold Laborer",
				["clock"] = "22:12:04",
			}, -- [15]
			{
				["elapsed"] = 8.0049999999992,
				["type"] = 0,
				["name"] = "Garrick Padfoot",
				["clock"] = "22:07:45",
			}, -- [16]
			{
				["elapsed"] = 5.012000000000626,
				["type"] = 0,
				["name"] = "Defias Thug",
				["clock"] = "22:07:31",
			}, -- [17]
			{
				["elapsed"] = 0.9980000000014115,
				["type"] = 0,
				["name"] = "Rabbit",
				["clock"] = "22:06:12",
			}, -- [18]
			{
				["elapsed"] = 18.06900000000132,
				["type"] = 0,
				["name"] = "Defias Thug",
				["clock"] = "22:03:01",
			}, -- [19]
			{
				["elapsed"] = 11.01699999999983,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "22:01:41",
			}, -- [20]
			{
				["elapsed"] = 9.018000000000029,
				["type"] = 0,
				["name"] = "Kobold Vermin",
				["clock"] = "22:01:28",
			}, -- [21]
			{
				["elapsed"] = 9.014999999999418,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "22:01:18",
			}, -- [22]
			{
				["elapsed"] = 11.02599999999984,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "22:01:03",
			}, -- [23]
			{
				["elapsed"] = 8.022000000000844,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "22:00:16",
			}, -- [24]
			{
				["elapsed"] = 12.02800000000025,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "21:59:56",
			}, -- [25]
			{
				["elapsed"] = 10.02299999999923,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "21:59:41",
			}, -- [26]
			{
				["elapsed"] = 13.03199999999924,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "21:59:24",
			}, -- [27]
			{
				["elapsed"] = 9.011999999998807,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "21:59:12",
			}, -- [28]
			{
				["elapsed"] = 9.011999999998807,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "21:58:58",
			}, -- [29]
			{
				["elapsed"] = 12.37700000000041,
				["type"] = 0,
				["name"] = "Kobold Worker",
				["clock"] = "21:58:38",
			}, -- [30]
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
		},
		["overall_refreshed"] = true,
		["hasSaved"] = true,
		["spells_cast_timeline"] = {
		},
		["data_fim"] = "22:18:19",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["last_events_tables"] = {
		},
		["start_time"] = 8923.692000000008,
		["TimeData"] = {
			["Player Damage Done"] = {
			},
			["Raid Damage Done"] = {
			},
		},
		["totals_grupo"] = {
			6008.535470000001, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
		},
	},
	["last_day"] = "22",
	["nick_tag_cache"] = {
		["nextreset"] = 1756864634,
		["last_version"] = 11,
	},
	["character_data"] = {
		["logons"] = 28,
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 1,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
	},
}
