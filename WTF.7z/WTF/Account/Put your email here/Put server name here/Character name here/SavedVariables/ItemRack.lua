
ItemRackUser = {
	["Alpha"] = 1,
	["Queues"] = {
	},
	["SetMenuWrapValue"] = 3,
	["Buttons"] = {
	},
	["Hidden"] = {
	},
	["Sets"] = {
		["~CombatQueue"] = {
			["equip"] = {
			},
		},
		["~Unequip"] = {
			["equip"] = {
			},
		},
	},
	["EnableQueues"] = "ON",
	["MainScale"] = 1,
	["QueuesEnabled"] = {
	},
	["ItemsUsed"] = {
	},
	["Events"] = {
		["Enabled"] = {
		},
		["Set"] = {
		},
	},
	["ButtonSpacing"] = 4,
	["Locked"] = "OFF",
	["EnableEvents"] = "ON",
	["MenuScale"] = 0.85,
	["SetMenuWrap"] = "OFF",
}
