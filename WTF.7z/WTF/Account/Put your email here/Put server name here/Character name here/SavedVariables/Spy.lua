
SpyPerCharDB = {
	["PlayerData"] = {
	},
	["IgnoreData"] = {
	},
	["version"] = "1.1",
	["KOSData"] = {
	},
}
