
qFPSDB = {
	["enabled"] = true,
	["xOfs"] = 4.001280209122707,
	["point"] = "BOTTOMRIGHT",
	["yOfs"] = 1.999257451353934,
}
