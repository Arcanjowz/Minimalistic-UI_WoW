
ACP_Data = {
	["sorter"] = "Default",
	["NoRecurse"] = true,
	["NoChildren"] = true,
	["collapsed"] = {
	},
	["ProtectedAddons"] = {
		["ACP"] = true,
	},
}
