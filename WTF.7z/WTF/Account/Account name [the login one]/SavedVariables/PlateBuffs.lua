
PB_DB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Gursaf - Kezan"] = "Default",
		["Arcanjo - Kezan"] = "Default",
		["Arcanjo - Menethil"] = "Default",
		["Arcanjo - Gurubashi"] = "Default",
		["Tesafs - Kezan"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
