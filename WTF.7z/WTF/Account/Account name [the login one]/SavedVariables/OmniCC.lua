
OmniCCGlobalSettings = {
	["fontSize"] = 11,
	["version"] = "3.0.4",
	["fontOutline"] = "THICKOUTLINE",
	["styles"] = {
		["minutes"] = {
			["r"] = 0.5529411764705883,
			["g"] = 0.4549019607843137,
		},
	},
}
