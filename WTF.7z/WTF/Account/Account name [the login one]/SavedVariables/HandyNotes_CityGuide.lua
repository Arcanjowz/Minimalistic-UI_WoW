
HandyNotes_CityGuideDB = {
	["factionrealm"] = {
		["Alliance - Kezan"] = {
			["nodes"] = {
				["Stormwind"] = {
					[64158046] = "B:Olivia Burnside:Banker:2455",
					[61157119] = "A:Auctioneer Fitch::8719",
					[63828073] = "B:Newton Burnside:Banker:2456",
					[61047063] = "A:Auctioneer Jaxon::15659",
				},
				["Ironforge"] = {
					[24207454] = "A:Auctioneer Redmuse::8720",
				},
			},
			["dbversion"] = 2,
		},
		["Alliance - Gurubashi"] = {
			["dbversion"] = 2,
		},
		["Alliance - Menethil"] = {
			["dbversion"] = 2,
		},
	},
	["profileKeys"] = {
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Kezan"] = {
		},
	},
}
