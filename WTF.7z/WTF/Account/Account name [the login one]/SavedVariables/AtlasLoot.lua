
AtlasLootOptions = nil
AtlasLootDB = {
	["profileKeys"] = {
		["Gursaf - Kezan"] = "Gursaf - Kezan",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Tesafs - Kezan"] = "Tesafs - Kezan",
	},
	["profiles"] = {
		["Gursaf - Kezan"] = {
			["AtlasType"] = "Unknown",
		},
		["Arcanjo - Kezan"] = {
			["AtlasType"] = "Unknown",
		},
		["Arcanjo - Menethil"] = {
			["AtlasType"] = "Unknown",
		},
		["Arcanjo - Gurubashi"] = {
			["AtlasType"] = "Unknown",
		},
		["Tesafs - Kezan"] = {
			["AtlasType"] = "Unknown",
		},
	},
}
AtlasLootWishList = {
	["Shared"] = {
	},
	["Options"] = {
		["Arcanjo"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
		["Tesafs"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["markInTable"] = "own",
			["AllowShareWishlist"] = true,
		},
		["Gursaf"] = {
			["AllowShareWishlistInCombat"] = true,
			["UseDefaultWishlist"] = false,
			["Mark"] = true,
			["AllowShareWishlist"] = true,
			["markInTable"] = "own",
		},
	},
	["Own"] = {
		["Arcanjo"] = {
		},
		["Tesafs"] = {
		},
		["Gursaf"] = {
		},
	},
}
