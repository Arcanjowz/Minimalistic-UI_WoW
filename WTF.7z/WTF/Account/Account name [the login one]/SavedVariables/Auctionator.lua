
AUCTIONATOR_SAVEDVARS = {
	["_5000000"] = 10000,
	["_50000"] = 500,
	["_200000"] = 1000,
	["_1000000"] = 2500,
	["_10000"] = 200,
	["_500"] = 5,
	["STARTING_DISCOUNT"] = 5,
	["_2000"] = 100,
}
AUCTIONATOR_PRICING_HISTORY = {
	["Blackened Defias Belt"] = {
		["is"] = "10403:0",
		["8985107"] = "1395:1",
	},
	["Soldier's Leggings of the Boar"] = {
		["8984160:hd"] = "1095:1",
		["is"] = "6546:1099",
		["8988316"] = "2900:1",
	},
	["Okra"] = {
		["is"] = "732:0",
		["8989747"] = "62:10",
	},
	["Willow Bracers of Stamina"] = {
		["is"] = "6543:19",
		["8973630"] = "347:1",
	},
	["Green Leather Bag"] = {
		["is"] = "5573:0",
		["8995687"] = "1300:1",
	},
	["Wool Bandage"] = {
		["is"] = "3530:0",
		["8989747"] = "51:4",
	},
	["Iron Ore"] = {
		["is"] = "2772:0",
		["8989747"] = "770:1",
	},
	["Moss Agate"] = {
		["is"] = "1206:0",
		["8985107"] = "497:2",
		["8995688"] = "530:1",
	},
	["Light Leather Quiver"] = {
		["is"] = "7278:0",
		["8996461"] = "192:1",
		["8995687"] = "196:1",
	},
	["Linen Cloth"] = {
		["is"] = "2589:0",
		["8996461"] = "27:11",
	},
	["Grunt's Handwraps of the Whale"] = {
		["is"] = "15509:1013",
		["8982634"] = "1590:1",
	},
	["Bard's Tunic of the Owl"] = {
		["is"] = "6552:763",
		["8995688"] = "1445:1",
	},
	["Shadowgem"] = {
		["is"] = "1210:0",
		["8975368"] = "274:1",
		["8985107"] = "242:1",
		["8995688"] = "272:2",
	},
	["Tin Ore"] = {
		["is"] = "2771:0",
		["8989747"] = "197:6",
	},
	["Copper Ore"] = {
		["is"] = "2770:0",
		["8989747"] = "81:7",
	},
	["Journeyman's Stave"] = {
		["is"] = "15925:0",
		["8973629"] = "439:1",
	},
	["Pattern: Reinforced Woolen Shoulders"] = {
		["is"] = "4347:0",
		["8985107"] = "188:1",
		["8988316"] = "164:1",
	},
	["Bear Meat"] = {
		["is"] = "3173:0",
		["8995687"] = "5:8",
	},
	["Training Sword of the Eagle"] = {
		["is"] = "8178:842",
		["8985107"] = "400:1",
	},
	["Coarse Stone"] = {
		["is"] = "2836:0",
		["8989747"] = "163:5",
	},
	["Schematic: Small Seaforium Charge"] = {
		["is"] = "4409:0",
		["8985107"] = "197:1",
	},
	["Small Leather Ammo Pouch"] = {
		["is"] = "7279:0",
		["8996461"] = "750:1",
		["8995687"] = "765:1",
	},
	["Notched Shortsword of Stamina"] = {
		["is"] = "727:15",
		["8973628"] = "530:1",
	},
	["Goblin Mail Leggings"] = {
		["is"] = "1943:0",
		["8985107"] = "1055:1",
	},
	["Silverleaf"] = {
		["is"] = "765:0",
		["8995687"] = "8:20",
	},
	["Lesser Moonstone"] = {
		["is"] = "1705:0",
		["8996585"] = "1595:1",
		["8995689"] = "1380:1",
	},
	["Burnished Gloves"] = {
		["is"] = "2992:0",
		["8985107"] = "785:1",
	},
	["Silver Bar"] = {
		["is"] = "2842:0",
		["8973629"] = "347:2",
		["8975368"] = "398:1",
	},
	["Buccaneer's Robes of the Owl"] = {
		["is"] = "14172:764",
		["8995688"] = "1545:1",
		["8996461"] = "1975:1",
	},
	["Mageroyal"] = {
		["is"] = "785:0",
		["8995687"] = "26:1",
	},
	["Disciple's Stein of the Whale"] = {
		["is"] = "15932:1009",
		["8975368"] = "690:1",
	},
	["Mystic's Sphere"] = {
		["is"] = "15946:0",
		["8982634"] = "1095:1",
	},
	["Bloodspattered Sabatons of the Bear"] = {
		["is"] = "15489:1182",
		["8982633"] = "2000:1",
	},
	["Blue Leather Bag"] = {
		["is"] = "856:0",
		["8995687"] = "1190:1",
	},
	["Buccaneer's Pants of the Whale"] = {
		["is"] = "14171:1020",
		["8975368"] = "2900:1",
	},
	["Charger's Pants of the Bear"] = {
		["is"] = "15477:1179",
		["8975368"] = "394:1",
	},
	["Schematic: EZ-Thro Dynamite"] = {
		["is"] = "6716:0",
		["8996585"] = "198:1",
	},
	["Buccaneer's Boots of the Falcon"] = {
		["is"] = "14174:238",
		["8995688"] = "1395:1",
		["8996461"] = "1390:1",
	},
	["Tigerseye"] = {
		["is"] = "818:0",
		["8975368"] = "97:1",
		["8985107"] = "226:1",
	},
	["Forest Leather Chestpiece"] = {
		["is"] = "3055:0",
		["8982634"] = "2000:1",
	},
}
AUCTIONATOR_SHOPPING_LISTS = {
	{
		["items"] = {
			"Container/Bag", -- [1]
		},
		["isRecents"] = 1,
		["name"] = "Recent Searches",
	}, -- [1]
	{
		["items"] = {
			"Abyss Crystal", -- [1]
			"Dream Shard", -- [2]
			"Greater Cosmic Essence", -- [3]
			"Infinite Dust", -- [4]
		},
		["name"] = "Sample Shopping List #1",
		["isSorted"] = true,
	}, -- [2]
}
AUCTIONATOR_PRICE_DATABASE = {
	["Kezan_Alliance"] = {
		["Mystic's Sphere"] = 1100,
		["Forest Leather Chestpiece"] = 2100,
		["Okra"] = 63,
		["Fel Steed Saddlebags"] = 8300,
		["Wool Bandage"] = 52,
		["Runecloth Bag"] = 23400,
		["Small Black Pouch"] = 250,
		["Wildhammer Pouch"] = 8400,
		["Traveler's Backpack"] = 131000,
		["Bard's Tunic of the Owl"] = 1450,
		["Infused Bag"] = 4700,
		["Tin Ore"] = 198,
		["Large Red Sack"] = 4299,
		["Mooncloth Bag"] = 356000,
		["Large Green Sack"] = 4399,
		["Green Woolen Bag"] = 1995,
		["Buccaneer's Robes of the Owl"] = 1980,
		["Coarse Stone"] = 164,
		["Schematic: Small Seaforium Charge"] = 198,
		["Small Silk Pack"] = 2100,
		["Small Brown Pouch"] = 180,
		["Woolen Bag"] = 700,
		["Notched Shortsword of Stamina"] = 535,
		["Heavy Brown Bag"] = 9900,
		["Large Rucksack"] = 5000,
		["Shiny Fish Scales"] = 7,
		["Buccaneer's Pants of the Whale"] = 3000,
		["Charger's Pants of the Bear"] = 395,
		["Smuggling Pouch"] = 7700,
		["Red Woolen Bag"] = 1195,
		["Green Leather Bag"] = 1312,
		["Red Mageweave Bag"] = 8100,
		["Small Red Pouch"] = 240,
		["Moss Agate"] = 535,
		["Light Leather Quiver"] = 193,
		["Linen Cloth"] = 28,
		["Large Blue Sack"] = 3900,
		["Grunt's Handwraps of the Whale"] = 1595,
		["Linen Bag"] = 269,
		["Shadowgem"] = 273,
		["Copper Ore"] = 82,
		["Journeyman's Stave"] = 440,
		["Goblin Mail Leggings"] = 1059,
		["Bear Meat"] = 6,
		["Troll-hide Bag"] = 26000,
		["White Leather Bag"] = 1085,
		["Revantusk Pouch"] = 18799,
		["Green Silk Pack"] = 9700,
		["Brown Leather Satchel"] = 1695,
		["Red Leather Bag"] = 1170,
		["Large Knapsack"] = 10400,
		["Lesser Moonstone"] = 1599,
		["Silver Bar"] = 399,
		["Mageroyal"] = 27,
		["Soldier's Leggings of the Boar"] = 2999,
		["Bloodspattered Sabatons of the Bear"] = 2100,
		["Iron Ore"] = 775,
		["Disciple's Stein of the Whale"] = 695,
		["Silverleaf"] = 9,
		["Gold Ore"] = 525,
		["Burnished Gloves"] = 790,
		["Mageweave Bag"] = 7900,
		["Pattern: Reinforced Woolen Shoulders"] = 165,
		["Large Brown Sack"] = 4300,
		["Snakeskin Bag"] = 5500,
		["Small Green Pouch"] = 240,
		["Small Blue Pouch"] = 256,
		["Black Silk Pack"] = 7799,
		["Blue Leather Bag"] = 1195,
		["Blackened Defias Belt"] = 1400,
		["Small Leather Ammo Pouch"] = 755,
		["Schematic: EZ-Thro Dynamite"] = 199,
		["Journeyman's Backpack"] = 26400,
		["Tigerseye"] = 99,
		["Buccaneer's Boots of the Falcon"] = 1395,
	},
	["__dbversion"] = 2,
	["Gurubashi_Alliance"] = {
	},
	["Menethil_Alliance"] = {
	},
}
AUCTIONATOR_MEAN_PRICE_DATABASE = {
	["Kezan_Alliance"] = {
	},
}
AUCTIONATOR_LAST_SCAN_TIME = 1756517720
AUCTIONATOR_TOONS = {
	["Gursaf"] = {
		["firstSeen"] = 1755714597,
		["firstVersion"] = "2.6.3",
	},
	["Arcanjo"] = {
		["firstSeen"] = 1755566954,
		["firstVersion"] = "2.6.3",
	},
	["Tesafs"] = {
		["firstSeen"] = 1755714733,
		["firstVersion"] = "2.6.3",
		["guid"] = "0x000000000001B926",
	},
}
AUCTIONATOR_STACKING_PREFS = {
}
AUCTIONATOR_SCAN_MINLEVEL = 1
