
EnhancedFriendsListDB = {
	["Kezan"] = {
		["Nisky"] = {
			12, -- [1]
			"Mage", -- [2]
			"Westfall", -- [3]
			"1756060946", -- [4]
		},
		["Tanquecita"] = {
			35, -- [1]
			"Warrior", -- [2]
			"Scarlet Monastery", -- [3]
			"1758588538", -- [4]
		},
		["Vih"] = {
			60, -- [1]
			"Rogue", -- [2]
			"Stormwind City", -- [3]
			"1758993810", -- [4]
		},
		["Propaganda"] = {
			19, -- [1]
			"Warlock", -- [2]
			"The Deadmines", -- [3]
			"1756083653", -- [4]
		},
		["Blackmagic"] = {
			60, -- [1]
			"Mage", -- [2]
			"Blackrock Mountain", -- [3]
			"1759099708", -- [4]
		},
		["Hallelujaah"] = {
			19, -- [1]
			"Paladin", -- [2]
			"The Deadmines", -- [3]
			"1755986357", -- [4]
		},
		["Gaff"] = {
			7, -- [1]
			"Hunter", -- [2]
			"Elwynn Forest", -- [3]
			"1755898290", -- [4]
		},
		["Garresh"] = {
			28, -- [1]
			"Warrior", -- [2]
			"Stonetalon Mountains", -- [3]
			"1757301443", -- [4]
		},
	},
	["Gurubashi"] = {
	},
	["Menethil"] = {
	},
}
