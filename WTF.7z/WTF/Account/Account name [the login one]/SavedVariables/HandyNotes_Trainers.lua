
HandyNotes_TrainersDB = {
	["factionrealm"] = {
		["Alliance - Kezan"] = {
			["nodes"] = {
				["Elwynn"] = {
					[38947059] = "PALADIN:Brother Wilhelm:Paladin Trainer:927",
				},
				["Stormwind"] = {
					[71656278] = "Leatherworking:Simon Tanner:Leatherworking Trainer:5564",
					[77316536] = "ROGUE:Osborne the Night Man:Rogue Trainer:918",
					[72176241] = "Skinning:Maris Granger:Skinning Trainer:1292",
					[63906903] = "Crossbows:Woo Ping:Weapon Master:11867",
					[63846904] = "WeaponMaster:Woo Ping:Weapon Master:11867",
					[53024488] = "First Aid:Shaina Fuller:First Aid Trainer:2327",
				},
				["Ironforge"] = {
					[62058931] = "Crossbows:Bixi Wobblebonk:Weapon Master:13084",
				},
			},
			["dbversion"] = 2,
		},
		["Alliance - Gurubashi"] = {
			["dbversion"] = 2,
		},
		["Alliance - Menethil"] = {
			["dbversion"] = 2,
		},
	},
	["profileKeys"] = {
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Kezan"] = {
			["icon_scale"] = 1.5,
		},
	},
}
