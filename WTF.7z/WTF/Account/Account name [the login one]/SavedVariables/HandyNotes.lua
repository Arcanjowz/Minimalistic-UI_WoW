
HandyNotesDB = {
	["profileKeys"] = {
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Menethil"] = {
		},
		["Arcanjo - Gurubashi"] = {
		},
		["Arcanjo - Kezan"] = {
		},
	},
}
HandyNotes_HandyNotesDB = {
	["profileKeys"] = {
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Menethil"] = {
		},
		["Arcanjo - Gurubashi"] = {
		},
		["Arcanjo - Kezan"] = {
		},
	},
}
