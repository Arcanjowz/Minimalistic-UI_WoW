
MagnifyOptions = {
	["zoomStep"] = 0.1,
	["maxZoom"] = 4,
	["enablePersistZoom"] = false,
	["enableOldPartyIcons"] = false,
}
