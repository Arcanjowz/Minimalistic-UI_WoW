
sdm_version = "1.8.3"
sdm_listFilters = {
	["true"] = true,
	["s"] = true,
	["b"] = true,
	["false"] = true,
	["global"] = true,
	["f"] = true,
}
sdm_iconSize = 36
sdm_mainContents = {
	0, -- [1]
}
sdm_macros = {
	[0] = {
		["type"] = "b",
		["name"] = "TEST",
		["ID"] = 0,
		["text"] = "/console characterambient 1\n/console componentemissive 1\n/console componentspecular 1\n/console detaildoodadalpha 100\n/console doodadloddist 2000\n/console entityloddist 100\n/console environmentdetail 150\n/console groundeffectfade 1277\n\n/console extshadowquality 5\n/console farclip 1600\n/console ffxglow 1\n/console ffxnetherworld 1\n/console smallcull 0\n/console groundeffectdensity 256\n/console groundeffectdist 600\n/console weatherdensity 3\n/console worldbasemip 0\n/console ssaodistance 750\n\n/console gxmultisample 8\n/console horizonfarclipscale 6\n/console horizonfarclip 6226\n/console lodobjectculldist 200\n/console lodobjectcullsize 1\n/console lodobjectfadescale 300\n/console lodobjectminsize 1\n/console overridefarclip 1\n\n/console texturefilteringmode 5\n/console particlemtdensity 100\n/console reflectionmode 3\n/console rippledetail 3\n/console shadowmode 3\n/console shadowtexturesize 2048\n/console showfootprintparticles 1\n/console showfootprints 1\n/console skycloudlod 3\n\n/console specular 1\n/console spelleffectlevel 150\n/console ssao 2\n/console ssaoblur 2\n/console sunshafts 2\n/console terrainmiplevel 0\n/console violencelevel 5\n/console waterdetail 3\n/console ffxspecial 1\n/console ffxdeath 1\n/console particledensity 100",
		["icon"] = 1,
	},
}
