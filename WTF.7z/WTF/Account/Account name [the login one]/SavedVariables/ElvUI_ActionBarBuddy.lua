
ABBDB = nil
