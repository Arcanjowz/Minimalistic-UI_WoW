
HandyNotes_VendorsDB = {
	["factionrealm"] = {
		["Alliance - Kezan"] = {
			["nodes"] = {
				["LochModan"] = {
					[34044632] = "R:Morhan Coppertongue:Metalsmith:167",
					[26442283] = "N:Greishan Ironstove:Traveling Merchant:3291",
					[35454853] = "I:Innkeeper Hearthstove:Innkeeper:6734",
					[36014591] = "N:Rann Flamespinner:Tailoring Supplies:1474",
					[24101815] = "R:Gothor Brumn:Armorer:1362",
					[34784886] = "N:Yanni Stoutheart:General Supplies:1682",
				},
				["Ironforge"] = {
					[62188870] = "R:Kelomir Ironhand:Maces & Staves:5121",
					[36346605] = "R:Grenil Steelfury:Weapon Merchant:5103",
				},
				["Wetlands"] = {
					[11325823] = "R:Naela Trance:Bowyer:1459",
					[11355955] = "R:Murndan Derth:Gunsmith:1461",
					[27226657] = "R:Hernag Cragpike:Weaponsmith:46825",
					[27516639] = "N:Ori Cragpike:General Supplies:46820",
					[11395963] = "R:Brak Durnad:Weaponsmith:1441",
					[11475975] = "R:Brahnmar:Armorer:1450",
					[7975818] = "N:Stuart Fleming:Fishing Supplies:3178",
				},
				["Elwynn"] = {
					[38377018] = "N:Tharynn Bouden:Trade Supplies:66",
					[39076835] = "N:Antonio Perelli:Traveling Salesman:844",
				},
				["Stormwind"] = {
					[75956680] = "R:Captain O'Neal:Weapons Quartermaster:12782",
					[75586689] = "N:Sergeant Major Clate:Food and Drink:12785",
					[64096875] = "R:Gunther Weller:Weapons Merchant:1289",
					[75866705] = "R:Captain Dirgehammer:Armor Quartermaster:12777",
					[77045742] = "R:Heinrich Stone:Blade Merchant:1324",
					[75426723] = "N:Lieutenant Jackspring:Reagent Vendor:12784",
					[63463761] = "R:Kaita Deepforge:Blacksmithing Supplies:5512",
					[75256656] = "N:Master Sergeant Biggins:Battle Quartermaster:12781",
					[77056114] = "R:Osric Strang:Heavy Armor Merchant:1323",
					[60357527] = "I:Innkeeper Allison:Innkeeper:6740",
					[74175821] = "N:Miles Sidney:Poison Supplies:28347",
					[53104497] = "N:Brother Cassius:Reagents:1351",
					[71656278] = "N:Jillian Tanner:Leatherworking Supplies:5565",
					[49246039] = "N:Lil Timmy:Boy with kittens:8666",
					[71886225] = "N:Alyssa Griffith:Bag Vendor:1321",
					[62226782] = "R:Carla Granger:Cloth Armor Merchant:1291",
					[76286518] = "N:Lieutenant Karter:War Mount Quartermaster:12783",
				},
				["Westfall"] = {
					[52805355] = "I:Innkeeper Heather:Innkeeper:8931",
					[56914723] = "N:Quartermaster Lewis:Quartermaster:491",
					[52335293] = "N:Christopher Hewen:Trade Supplies:8934",
					[43466690] = "R:Defias Profiteer:Free Wheeling Merchant:1669",
					[55923131] = "N:Farmer Saldean::233",
				},
				["Darkshore"] = {
					[38074125] = "N:Gorbold Steelhand:Trade Supplies:6301",
					[36874394] = "N:Taldan:Drink Vendor:4192",
					[36824432] = "N:Laird:Fish Vendor:4200",
					[36894456] = "N:Kyndri:Baker:4190",
					[37484045] = "N:Dalmond:General Goods:4182",
					[37774102] = "R:Quartermaster Nyana:Auberdine Quartermaster:45036",
					[37544038] = "R:Naram Longclaw:Weaponsmith:4183",
				},
				["DunMorogh"] = {
					[68805590] = "R:Frast Dokner:Apprentice Weaponsmith:1698",
					[68701897] = "N:Kromren Stoutbraid:Bartender:46616",
				},
			},
			["dbversion"] = 2,
		},
		["Alliance - Gurubashi"] = {
			["dbversion"] = 2,
		},
		["Alliance - Menethil"] = {
			["dbversion"] = 2,
		},
	},
	["profileKeys"] = {
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Kezan"] = {
			["icon_scale"] = 1.5,
		},
	},
}
