
AbbreviatedStatusDB = {
	["profileKeys"] = {
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["global"] = {
		{
			["pet"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["party"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["player"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = 1,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["version"] = "1.2.1",
			["focus"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["target"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["arena"] = {
				["healthbar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
				["manabar"] = {
					["percent"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
					["status"] = {
						["enable"] = true,
						["xOff"] = 2.37487256526947e-007,
						["yOff"] = 2.37487256526947e-007,
					},
				},
			},
			["remainder"] = 1,
			["prefix"] = 3,
		}, -- [1]
	},
}
