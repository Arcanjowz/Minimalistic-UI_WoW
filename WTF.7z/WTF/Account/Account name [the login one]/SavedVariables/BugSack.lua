
BugSackDB = nil
BugSackLDBIconDB = nil
