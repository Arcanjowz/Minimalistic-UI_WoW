
SpyDB = {
	["kosData"] = {
		["Kezan"] = {
			["Alliance"] = {
				["Tesafs"] = {
				},
				["Gursaf"] = {
				},
				["Arcanjo"] = {
				},
			},
		},
		["Gurubashi"] = {
			["Alliance"] = {
				["Arcanjo"] = {
				},
			},
		},
		["Menethil"] = {
			["Alliance"] = {
				["Arcanjo"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["Kezan"] = {
			["Alliance"] = {
			},
		},
		["Gurubashi"] = {
			["Alliance"] = {
			},
		},
		["Menethil"] = {
			["Alliance"] = {
			},
		},
	},
	["profileKeys"] = {
		["Gursaf - Kezan"] = "Gursaf - Kezan",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Tesafs - Kezan"] = "Tesafs - Kezan",
	},
	["profiles"] = {
		["Gursaf - Kezan"] = {
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindow"] = {
				["Position"] = {
					["y"] = 192.9993728206269,
					["x"] = 432.9999363314801,
					["w"] = 130.0000061548516,
					["h"] = 45.00000280387682,
				},
			},
		},
		["Arcanjo - Kezan"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 193.0000205845591,
					["x"] = 433.0000063600133,
					["w"] = 158.0000047871068,
					["h"] = 45.00000280387682,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
		},
		["Arcanjo - Menethil"] = {
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindow"] = {
				["Position"] = {
					["y"] = 760.0000629162603,
					["x"] = 10.00000013677448,
					["w"] = 130.0000061548516,
					["h"] = 45.00000280387682,
				},
			},
		},
		["Arcanjo - Gurubashi"] = {
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindow"] = {
				["Position"] = {
					["y"] = 760.0000629162603,
					["x"] = 10.00000013677448,
					["w"] = 130.0000061548516,
					["h"] = 45.00000280387682,
				},
			},
		},
		["Tesafs - Kezan"] = {
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindow"] = {
				["Position"] = {
					["y"] = 192.9966242006985,
					["x"] = 434.0033751838163,
					["w"] = 130.0000236619848,
					["h"] = 45.00000280387682,
				},
			},
		},
	},
}
