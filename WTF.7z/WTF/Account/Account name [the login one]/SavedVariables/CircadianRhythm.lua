
CircadianRhythmSettings = {
	["showGameTimeOnHover"] = true,
	["showButton"] = true,
	["showLockIcon"] = true,
	["buttonPosition"] = {
		["y"] = -208.0000448620291,
		["x"] = -23.99997756898546,
		["point"] = "TOPRIGHT",
	},
}
