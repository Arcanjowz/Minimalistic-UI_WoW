
TalentedDB = {
	["profileKeys"] = {
		["Arcanjo - Menethil"] = "Arcanjo - Menethil",
		["Arcanjo - Gurubashi"] = "Arcanjo - Gurubashi",
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Menethil"] = {
			["framepos"] = {
				["TalentedGlyphs"] = {
					["y"] = 0,
					["x"] = 0,
					["anchorTo"] = "CENTER",
					["anchor"] = "CENTER",
				},
			},
		},
		["Arcanjo - Gurubashi"] = {
			["framepos"] = {
				["TalentedGlyphs"] = {
					["y"] = 0,
					["x"] = 0,
					["anchor"] = "CENTER",
					["anchorTo"] = "CENTER",
				},
			},
		},
		["Arcanjo - Kezan"] = {
			["framepos"] = {
				["TalentedFrame"] = {
					["y"] = 0.9999699096146373,
					["x"] = -1.999939819229275,
					["anchor"] = "CENTER",
					["anchorTo"] = "CENTER",
				},
				["TalentedGlyphs"] = {
					["y"] = -4.3768108740656e-005,
					["x"] = -8.7536217481312e-005,
					["anchor"] = "CENTER",
					["anchorTo"] = "CENTER",
				},
			},
		},
	},
}
