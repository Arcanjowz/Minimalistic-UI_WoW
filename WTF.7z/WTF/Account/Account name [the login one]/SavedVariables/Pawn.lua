
PawnCommon = {
	["ShowEnchanted"] = false,
	["Digits"] = 1,
	["ShowSpace"] = false,
	["AlignNumbersRight"] = false,
	["ShowTooltipIcons"] = true,
	["ShowItemID"] = false,
	["ShowUnenchanted"] = true,
	["ButtonPosition"] = 2,
	["ShownGettingStarted"] = true,
	["Debug"] = false,
	["ShowAsterisks"] = 1,
	["Scales"] = {
		["\"Wowhead\":ShamanEnhancement"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "526fbf",
			["LocalizedName"] = "Shaman: enhancement",
		},
		["\"Wowhead\":DeathKnightUnholyDps"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["LocalizedName"] = "DK: unholy DPS",
		},
		["\"Wowhead\":DeathKnightFrostDps"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["LocalizedName"] = "DK: frost DPS",
		},
		["\"Wowhead\":WarriorArms"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "957552",
			["LocalizedName"] = "Warrior: arms",
		},
		["\"Wowhead\":WarlockDestruction"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "8d7bbf",
			["LocalizedName"] = "Warlock: destruction",
		},
		["\"Wowhead\":PaladinTank"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "b7698b",
			["LocalizedName"] = "Paladin: tank",
		},
		["\"Wowhead\":HunterBeastMastery"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "809f56",
			["LocalizedName"] = "Hunter: beast mastery",
		},
		["\"Wowhead\":PaladinHoly"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "b7698b",
			["LocalizedName"] = "Paladin: holy",
		},
		["\"Wowhead\":RogueCombat"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
					["Visible"] = true,
				},
				["Arcanjo-Menethil"] = {
					["Visible"] = true,
				},
				["Arcanjo-Kezan"] = {
					["Visible"] = true,
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfb74e",
			["LocalizedName"] = "Rogue: combat",
		},
		["\"Wowhead\":PriestDiscipline"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfbfbf",
			["LocalizedName"] = "Priest: discipline",
		},
		["\"Wowhead\":DeathKnightBloodTank"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["LocalizedName"] = "DK: blood tank",
		},
		["\"Wowhead\":MageFrost"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "4e99b3",
			["LocalizedName"] = "Mage: frost",
		},
		["\"Wowhead\":ShamanRestoration"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "526fbf",
			["LocalizedName"] = "Shaman: restoration",
		},
		["\"Wowhead\":MageFire"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "4e99b3",
			["LocalizedName"] = "Mage: fire",
		},
		["\"Wowhead\":WarriorFury"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "957552",
			["LocalizedName"] = "Warrior: fury",
		},
		["\"Wowhead\":DeathKnightBloodDps"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["LocalizedName"] = "DK: blood DPS",
		},
		["\"Wowhead\":WarlockDemonology"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "8d7bbf",
			["LocalizedName"] = "Warlock: demonology",
		},
		["\"Wowhead\":DruidRestoration"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["LocalizedName"] = "Druid: restoration",
		},
		["\"Wowhead\":DruidFeralTank"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["LocalizedName"] = "Druid: feral bear",
		},
		["\"Wowhead\":HunterMarksman"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "809f56",
			["LocalizedName"] = "Hunter: marksman",
		},
		["\"Wowhead\":ShamanElemental"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "526fbf",
			["LocalizedName"] = "Shaman: elemental",
		},
		["\"Wowhead\":DeathKnightFrostTank"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf3950",
			["LocalizedName"] = "DK: frost tank",
		},
		["\"Wowhead\":PaladinRetribution"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "b7698b",
			["LocalizedName"] = "Paladin: retribution",
		},
		["\"Wowhead\":MageArcane"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "4e99b3",
			["LocalizedName"] = "Mage: arcane",
		},
		["\"Wowhead\":WarlockAffliction"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "8d7bbf",
			["LocalizedName"] = "Warlock: affliction",
		},
		["\"Wowhead\":WarriorTank"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "957552",
			["LocalizedName"] = "Warrior: tank",
		},
		["\"Wowhead\":RogueAssassination"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
					["Visible"] = true,
				},
				["Arcanjo-Menethil"] = {
					["Visible"] = true,
				},
				["Arcanjo-Kezan"] = {
					["Visible"] = true,
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfb74e",
			["LocalizedName"] = "Rogue: assassination",
		},
		["\"Wowhead\":DruidBalance"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["LocalizedName"] = "Druid: balance",
		},
		["\"Wowhead\":PriestShadow"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfbfbf",
			["LocalizedName"] = "Priest: shadow",
		},
		["\"Wowhead\":HunterSurvival"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "809f56",
			["LocalizedName"] = "Hunter: survival",
		},
		["\"Wowhead\":DruidFeralDps"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bf5d07",
			["LocalizedName"] = "Druid: feral cat",
		},
		["\"Wowhead\":PriestHoly"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
				},
				["Arcanjo-Menethil"] = {
				},
				["Arcanjo-Kezan"] = {
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfbfbf",
			["LocalizedName"] = "Priest: holy",
		},
		["\"Wowhead\":RogueSubtlety"] = {
			["PerCharacterOptions"] = {
				["Arcanjo-Gurubashi"] = {
					["Visible"] = true,
				},
				["Arcanjo-Menethil"] = {
					["Visible"] = true,
				},
				["Arcanjo-Kezan"] = {
					["Visible"] = true,
				},
			},
			["MetaGemQualityLevel"] = 81,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["GemQualityLevel"] = 81,
			["NormalizationFactor"] = 1,
			["SmartGemSocketing"] = true,
			["Provider"] = "Wowhead",
			["UnenchantedColor"] = "bfb74e",
			["LocalizedName"] = "Rogue: subtlety",
		},
	},
}
