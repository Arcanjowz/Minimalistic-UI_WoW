
QTR_PS = {
	["transtitle"] = "0",
	["other3"] = "1",
	["active"] = "1",
	["other2"] = "1",
	["patch"] = "3.3.5",
	["period"] = 15,
	["channel"] = "0",
	["control"] = "1",
	["reklama"] = "1",
	["other1"] = "1",
	["enablegoss"] = "1",
}
QTRTTT_PS = {
	["isstat"] = "1",
	["ener"] = "1",
	["active"] = "1",
	["try"] = "0",
	["body"] = "1",
	["mats"] = "1",
	["compOR"] = "0",
	["info"] = "1",
	["questHelp"] = "1",
	["saveNW"] = "0",
	["weapon"] = "1",
	["showID"] = "0",
	["saveWH"] = "0",
}
