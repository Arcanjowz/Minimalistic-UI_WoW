
HandyNotes_GuildDB = nil
