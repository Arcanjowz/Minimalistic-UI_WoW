
oGlowDB = {
	["version"] = 1,
	["EnabledFilters"] = {
		["Quality border"] = {
			["merchant"] = true,
			["bags"] = true,
			["char"] = true,
			["char-flyout"] = true,
			["gbank"] = true,
			["trade"] = true,
			["mail"] = true,
			["inspect"] = true,
			["tradeskill"] = true,
			["bank"] = true,
		},
	},
	["EnabledPipes"] = {
		["merchant"] = true,
		["bags"] = true,
		["char"] = true,
		["char-flyout"] = true,
		["gbank"] = true,
		["trade"] = true,
		["mail"] = true,
		["inspect"] = true,
		["tradeskill"] = true,
		["bank"] = true,
	},
	["Colors"] = {
	},
	["FilterSettings"] = {
	},
}
