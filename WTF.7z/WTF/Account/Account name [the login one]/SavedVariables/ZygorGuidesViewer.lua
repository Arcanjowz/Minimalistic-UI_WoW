
ZygorGuidesViewerSettings = {
	["char"] = {
		["Arcanjo - Kezan"] = {
			["step"] = 5,
			["guidename"] = "Leveling Guides\\Ashenvale (24-24)",
			["maint_fetchquestdata"] = true,
			["debuglog"] = {
				"00:22:12> &sticky (parser) closing %s", -- [1]
				"00:22:12> &sticky (parser) closing %s", -- [2]
				"00:22:12> &sticky (parser) closing %s", -- [3]
				"00:22:12> &sticky (parser) closing %s", -- [4]
				"00:22:12> &sticky (parser) closing %s", -- [5]
				"00:22:12> &sticky (parser) closing %s", -- [6]
				"00:22:12> &sticky (parser) closing %s", -- [7]
				"00:22:12> &sticky (parser) closing %s", -- [8]
				"00:22:12> &sticky (parser) closing %s", -- [9]
				"00:22:12> &sticky (parser) closing %s", -- [10]
				"00:22:12> &sticky (parser) closing %s", -- [11]
				"00:22:12> &sticky (parser) closing %s", -- [12]
				"00:22:12> &sticky (parser) closing %s", -- [13]
				"00:22:12> &sticky (parser) closing %s", -- [14]
				"00:22:12> &sticky (parser) closing %s", -- [15]
				"00:22:12> &sticky (parser) closing %s", -- [16]
				"00:22:12> &sticky (parser) closing %s", -- [17]
				"00:22:12> &sticky (parser) closing %s", -- [18]
				"00:22:12> &sticky (parser) closing %s", -- [19]
				"00:22:12> &sticky (parser) closing %s", -- [20]
				"00:22:12> &sticky (parser) closing %s", -- [21]
				"00:22:12> &sticky (parser) closing %s", -- [22]
				"00:22:12> &sticky (parser) closing %s", -- [23]
				"00:22:12> &sticky (parser) closing %s", -- [24]
				"00:22:12> &sticky (parser) closing %s", -- [25]
				"00:22:12> &sticky (parser) closing %s", -- [26]
				"00:22:12> &sticky (parser) closing %s", -- [27]
				"00:22:12> &sticky (parser) closing %s", -- [28]
				"00:22:12> &sticky (parser) closing %s", -- [29]
				"00:22:12> &sticky (parser) closing %s", -- [30]
				"00:22:12> &sticky (parser) closing %s", -- [31]
				"00:22:12> &sticky (parser) closing %s", -- [32]
				"00:22:12> &sticky (parser) closing %s", -- [33]
				"00:22:12> &sticky (parser) closing %s", -- [34]
				"00:22:12> &sticky (parser) closing %s", -- [35]
				"00:22:12> &sticky (parser) closing %s", -- [36]
				"00:22:12> &sticky (parser) closing %s", -- [37]
				"00:22:12> &sticky (parser) closing %s", -- [38]
				"00:22:12> &sticky (parser) closing %s", -- [39]
				"00:22:12> &sticky (parser) closing %s", -- [40]
				"00:22:12> &sticky (parser) closing %s", -- [41]
				"00:22:12> &sticky (parser) closing %s", -- [42]
				"00:22:12> &sticky (parser) closing %s", -- [43]
				"00:22:12> &sticky (parser) closing %s", -- [44]
				"00:22:12> &sticky (parser) closing %s", -- [45]
				"00:22:12> &sticky (parser) closing %s", -- [46]
				"00:22:12> &sticky (parser) closing %s", -- [47]
				"00:22:12> &sticky (parser) closing %s", -- [48]
				"00:22:12> &sticky (parser) closing %s", -- [49]
				"00:22:12> &sticky (parser) closing %s", -- [50]
				"00:22:12> &sticky (parser) closing %s", -- [51]
				"00:22:12> &sticky (parser) closing %s", -- [52]
				"00:22:12> &sticky (parser) closing %s", -- [53]
				"00:22:12> &sticky (parser) closing %s", -- [54]
				"00:22:12> &sticky (parser) closing %s", -- [55]
				"00:22:12> &sticky (parser) closing %s", -- [56]
				"00:22:12> &sticky (parser) closing %s", -- [57]
				"00:22:12> &sticky (parser) closing %s", -- [58]
				"00:22:12> &sticky (parser) closing %s", -- [59]
				"00:22:12> &sticky (parser) closing %s", -- [60]
				"00:22:12> &sticky (parser) closing %s", -- [61]
				"00:22:12> &sticky (parser) closing %s", -- [62]
				"00:22:12> &sticky (parser) closing %s", -- [63]
				"00:22:12> &sticky (parser) closing %s", -- [64]
				"00:22:12> &sticky (parser) closing %s", -- [65]
				"00:22:12> &sticky (parser) closing %s", -- [66]
				"00:22:12> &sticky (parser) closing %s", -- [67]
				"00:22:12> &sticky (parser) closing %s", -- [68]
				"00:22:12> &sticky (parser) closing %s", -- [69]
				"00:22:12> &sticky (parser) closing %s", -- [70]
				"00:22:12> &sticky (parser) closing %s", -- [71]
				"00:22:12> &sticky (parser) closing %s", -- [72]
				"00:22:12> &sticky (parser) closing %s", -- [73]
				"00:22:12> &sticky (parser) closing %s", -- [74]
				"00:22:12> &sticky (parser) closing %s", -- [75]
				"00:22:12> &sticky (parser) closing %s", -- [76]
				"00:22:12> &sticky (parser) closing %s", -- [77]
				"00:22:12> &sticky (parser) closing %s", -- [78]
				"00:22:12> &sticky (parser) closing %s", -- [79]
				"00:22:12> &sticky (parser) closing %s", -- [80]
				"00:22:12> &sticky (parser) closing %s", -- [81]
				"00:22:12> &sticky (parser) closing %s", -- [82]
				"00:22:12> &sticky (parser) closing %s", -- [83]
				"00:22:12> &sticky (parser) closing %s", -- [84]
				"00:22:12> &sticky (parser) closing %s", -- [85]
				"00:22:12> &sticky (parser) closing %s", -- [86]
				"00:22:12> &sticky (parser) closing %s", -- [87]
				"00:22:12> &sticky (parser) closing %s", -- [88]
				"00:22:12> &sticky (parser) closing %s", -- [89]
				"00:22:12> &sticky (parser) closing %s", -- [90]
				"00:22:12> &sticky (parser) closing %s", -- [91]
				"00:22:12> &sticky (parser) closing %s", -- [92]
				"00:22:12> Guides loaded. -----", -- [93]
				"00:22:12> SetGuide Leveling Guides\\Ashenvale (24-24) (5", -- [94]
				"00:22:12> Guide loaded: Leveling Guides\\Ashenvale (24-24)", -- [95]
				"00:22:12> FocusStep 5", -- [96]
				"00:22:12> Translated: 'kill' An Aggressive Defense", -- [97]
				"00:22:12> unpausing", -- [98]
				"00:22:12> frameNeedsUpdating, so updating.", -- [99]
				"00:22:22> Got completed quests list", -- [100]
			},
			["starting"] = false,
			["guides_history"] = {
				{
					["short"] = "Loch Modan (17-18)",
					["full"] = "Leveling Guides\\Loch Modan (17-18)",
					["step"] = 39,
				}, -- [1]
				{
					["short"] = "Ashenvale (22-23)",
					["full"] = "Leveling Guides\\Ashenvale (22-23)",
					["step"] = 40,
				}, -- [2]
				{
					["short"] = "Darkshore (20-22)",
					["full"] = "Leveling Guides\\Darkshore (20-22)",
					["step"] = 65,
				}, -- [3]
				{
					["short"] = "Stonetalon Mountains (23-24)",
					["full"] = "Leveling Guides\\Stonetalon Mountains (23-24)",
					["step"] = 13,
				}, -- [4]
				{
					["short"] = "Ashenvale (24-24)",
					["full"] = "Leveling Guides\\Ashenvale (24-24)",
					["step"] = 5,
				}, -- [5]
			},
			["RecipesKnown"] = {
				[2149] = true,
				[2153] = true,
				[7934] = true,
				[3275] = true,
				[3277] = true,
				[9058] = true,
				[2161] = true,
				[3756] = true,
				[3816] = true,
				[9059] = true,
				[2539] = true,
				[9060] = true,
				[3753] = true,
				[2152] = true,
				[7126] = true,
				[86842] = true,
				[2881] = true,
				[2160] = true,
				[8604] = true,
				[3278] = true,
				[2538] = true,
				[9062] = true,
				[2162] = true,
				[7751] = true,
				[3276] = true,
				[2540] = true,
				[86843] = true,
				[86841] = true,
			},
			["taxis"] = {
				true, -- [1]
				true, -- [2]
				["Ironforge Airfield"] = true,
				["Thelsamar"] = true,
				["Stonetalon Grove"] = true,
				["Auberdine"] = true,
				["Lakeshire"] = true,
				["Astranaar"] = true,
				["Menethil Harbor"] = true,
				["Ironforge"] = true,
				["Sentinel Hill"] = true,
				["Stormwind"] = true,
				["Rut'theran Village"] = true,
			},
			["maint_fetchitemdata"] = true,
		},
	},
	["profileKeys"] = {
		["Arcanjo - Kezan"] = "Arcanjo - Kezan",
	},
	["profiles"] = {
		["Arcanjo - Kezan"] = {
			["Border_Title"] = false,
			["arrowmeters"] = true,
			["Boarder_Settings_anchor_offsetX"] = -75,
			["Boarder_Settings_anchor"] = "TOPRIGHT",
			["fullheight"] = 222.0009195348218,
			["disableGuideAnim"] = true,
			["arrowsmooth"] = true,
			["Boarder_Close_topright_offsetY"] = -13,
			["showallsteps"] = false,
			["skipimpossible"] = true,
			["fontsize"] = 12,
			["foglight"] = false,
			["arrowposx"] = 2045.016029490219,
			["Boarder_Settings_anchor_offsetY"] = -13,
			["disableBackDrop"] = true,
			["Boarder_Lock_offsetX"] = 10,
			["Boarder_topright_offsetY"] = 0,
			["Boarder_Close_topright_offsetX"] = -15,
			["Boarder_Mini_topright_offsetX"] = -35,
			["arrowcam"] = false,
			["audiocues"] = false,
			["fontsecsize"] = 12,
			["arrowposy"] = 417.0020382816721,
			["Skipper_anchor"] = "CENTER",
			["windowlocked"] = true,
			["Boarder_topleft_offsetY"] = 5,
			["Boarder_Guide_topright_offsetX"] = -55,
			["showmapbutton"] = false,
			["Skipper_yOffset"] = 0,
			["Boarder_Mini_topright_offsetY"] = -13,
			["resizeup"] = false,
			["hideborder"] = true,
			["Boarder_topleft_offsetX"] = 0,
			["Skipper_xOffset"] = 0,
			["Boarder_Guide_topright_offsetY"] = -27,
		},
	},
}
