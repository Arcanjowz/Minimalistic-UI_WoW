
SwiftSkiDB = {
	["lastCompanionSpellID"] = 13548,
	["options"] = {
		["qReward"] = {
			["attr"] = "ANY",
			["autoChoose"] = false,
			["armor"] = "ANY",
			["strategy"] = "ATTRIBUTE",
		},
		["autoCollect"] = true,
		["autoAccept"] = false,
		["showAbandonAllBtn"] = true,
		["vendor"] = {
			["enabled"] = false,
			["safeSell"] = true,
			["mats"] = {
				["Elemental"] = true,
				["Jewelcrafting"] = true,
				["MetalStone"] = true,
				["Cooking"] = true,
				["Herb"] = true,
				["Cloth"] = true,
				["Enchanting"] = true,
				["Leather"] = true,
				["Parts"] = true,
			},
			["quality"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				[0] = true,
			},
		},
		["itemLockEnabled"] = true,
		["autoHeirlooms"] = true,
		["autoTurnIn"] = false,
		["missedLootNotify"] = true,
		["fastRoulette"] = true,
		["autoCompanion"] = false,
		["msBuffs"] = true,
		["disableMinimap"] = false,
	},
	["mmPos"] = {
		["y"] = -22.6,
		["x"] = -66.09999999999999,
	},
	["locked"] = {
		[5060] = true,
		[5140] = true,
	},
	["itemLockFilters"] = {
		true, -- [1]
		true, -- [2]
		true, -- [3]
		true, -- [4]
		true, -- [5]
		true, -- [6]
		true, -- [7]
		[0] = true,
	},
	["firstRunShown"] = true,
}
