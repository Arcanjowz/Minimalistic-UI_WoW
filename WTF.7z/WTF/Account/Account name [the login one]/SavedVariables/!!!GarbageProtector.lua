
GarbageProtectorDB = {
	["Enabled"] = true,
	["HandleUpdateAddOnMemoryUsage"] = true,
	["Handlecollectgarbage"] = true,
}
