
SoundAlerterDB = {
	["profileKeys"] = {
		["Arcanjo - Menethil"] = "Default",
		["Arcanjo - Gurubashi"] = "Default",
		["Arcanjo - Kezan"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["path"] = "Interface\\Addons\\SoundAlerter\\Voice\\",
		},
	},
}
