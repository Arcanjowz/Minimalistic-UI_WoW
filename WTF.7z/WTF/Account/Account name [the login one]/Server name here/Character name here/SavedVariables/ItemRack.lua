
ItemRackUser = {
	["Hidden"] = {
	},
	["Queues"] = {
	},
	["SetMenuWrapValue"] = 3,
	["SetMenuWrap"] = "OFF",
	["Alpha"] = 1,
	["Sets"] = {
		["~CombatQueue"] = {
			["equip"] = {
			},
		},
		["~Unequip"] = {
			["equip"] = {
			},
		},
	},
	["EnableQueues"] = "ON",
	["MainScale"] = 1,
	["QueuesEnabled"] = {
	},
	["ItemsUsed"] = {
	},
	["Events"] = {
		["Enabled"] = {
		},
		["Set"] = {
		},
	},
	["ButtonSpacing"] = 4,
	["Locked"] = "OFF",
	["EnableEvents"] = "ON",
	["MenuScale"] = 0.85,
	["Buttons"] = {
	},
}
