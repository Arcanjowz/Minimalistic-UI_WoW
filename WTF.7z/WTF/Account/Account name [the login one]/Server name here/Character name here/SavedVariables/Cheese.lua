
cheeseDisplaySpellActivationOverlays = "1"
cheeseSpellActivationOverlayOpacity = 1
