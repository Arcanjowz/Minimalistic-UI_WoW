
QuestieConfigCharacter = nil
QuestieDataCollection = {
	["sessionStart"] = "2025-09-02 23:57:46",
	["version"] = 1,
	["quests"] = {
		[26848] = {
			["incompleteData"] = true,
			["id"] = 26848,
			["items"] = {
			},
			["wasAlreadyAccepted"] = true,
			["name"] = "Clyde's Special Thread",
			["npcs"] = {
				[4200] = {
					["name"] = "Laird",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868324,
					["level"] = 14,
				},
				[6737] = {
					["name"] = "Innkeeper Shaussiy",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868323,
					["level"] = 30,
				},
				[55835] = {
					["name"] = "Bird of Prey",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868289,
					["level"] = 13,
				},
			},
			["sessionStart"] = "2025-09-02 23:57:48",
			["level"] = 23,
			["objects"] = {
			},
			["objectives"] = {
				{
					["lastText"] = "Clyde's Special Thread: 0/1",
					["type"] = "item",
					["index"] = 1,
					["text"] = "Clyde's Special Thread: 0/1",
					["progressLocations"] = {
					},
					["completed"] = false,
					["containers"] = {
					},
					["total"] = 1,
					["current"] = 0,
				}, -- [1]
			},
		},
		[26663] = {
			["incompleteData"] = true,
			["id"] = 26663,
			["items"] = {
			},
			["wasAlreadyAccepted"] = true,
			["name"] = "The Ironforge Airfield",
			["npcs"] = {
				[4200] = {
					["name"] = "Laird",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868324,
					["level"] = 14,
				},
				[6737] = {
					["name"] = "Innkeeper Shaussiy",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868323,
					["level"] = 30,
				},
				[45038] = {
					["name"] = "Bill Wheeland",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.8,
						["x"] = 37.5,
					},
					["timestamp"] = 1756869004,
					["level"] = 12,
				},
				[2913] = {
					["name"] = "Archaeologist Hollee",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.8,
						["x"] = 37.5,
					},
					["timestamp"] = 1756869004,
					["level"] = 12,
				},
				[3701] = {
					["name"] = "Tharnariun Treetender",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 43.1,
						["x"] = 38.6,
					},
					["timestamp"] = 1756869044,
					["level"] = 18,
				},
				[6086] = {
					["name"] = "Auberdine Sentinel",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.9,
						["x"] = 37.5,
					},
					["level"] = 40,
					["timestamp"] = 1756868967,
				},
				[6667] = {
					["name"] = "Gelkak Gyromast",
					["zone"] = "Darkshore",
					["subzone"] = "Mist's Edge",
					["coords"] = {
						["y"] = 13.4,
						["x"] = 56.7,
					},
					["timestamp"] = 1756869840,
					["level"] = 18,
				},
				[55835] = {
					["name"] = "Bird of Prey",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868289,
					["level"] = 13,
				},
				[2236] = {
					["name"] = "Raging Reef Crawler",
					["zone"] = "Darkshore",
					["subzone"] = "Mist's Edge",
					["coords"] = {
						["y"] = 17.8,
						["x"] = 55.7,
					},
					["timestamp"] = 1756869796,
					["level"] = 21,
				},
			},
			["sessionStart"] = "2025-09-02 23:57:48",
			["level"] = 17,
			["objects"] = {
			},
			["objectives"] = {
			},
		},
		[26208] = {
			["incompleteData"] = true,
			["id"] = 26208,
			["acceptTime"] = 1756868344,
			["items"] = {
			},
			["wasAlreadyAccepted"] = true,
			["name"] = "Wanted: Grizzletooth",
			["npcs"] = {
				[4200] = {
					["name"] = "Laird",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868324,
					["level"] = 14,
				},
				[6737] = {
					["name"] = "Innkeeper Shaussiy",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868323,
					["level"] = 30,
				},
				[45038] = {
					["name"] = "Bill Wheeland",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.8,
						["x"] = 37.5,
					},
					["timestamp"] = 1756869004,
					["level"] = 12,
				},
				[2913] = {
					["name"] = "Archaeologist Hollee",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.8,
						["x"] = 37.5,
					},
					["timestamp"] = 1756869004,
					["level"] = 12,
				},
				[3701] = {
					["name"] = "Tharnariun Treetender",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 43.1,
						["x"] = 38.6,
					},
					["timestamp"] = 1756869044,
					["level"] = 18,
				},
				[6086] = {
					["name"] = "Auberdine Sentinel",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.9,
						["x"] = 37.5,
					},
					["level"] = 40,
					["timestamp"] = 1756868967,
				},
				[6667] = {
					["name"] = "Gelkak Gyromast",
					["zone"] = "Darkshore",
					["subzone"] = "Mist's Edge",
					["coords"] = {
						["y"] = 13.4,
						["x"] = 56.7,
					},
					["timestamp"] = 1756869840,
					["level"] = 18,
				},
				[55835] = {
					["name"] = "Bird of Prey",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868289,
					["level"] = 13,
				},
				[2236] = {
					["name"] = "Raging Reef Crawler",
					["zone"] = "Darkshore",
					["subzone"] = "Mist's Edge",
					["coords"] = {
						["y"] = 17.8,
						["x"] = 55.7,
					},
					["timestamp"] = 1756869796,
					["level"] = 21,
				},
			},
			["sessionStart"] = "2025-09-02 23:57:48",
			["level"] = 18,
			["objects"] = {
			},
			["objectives"] = {
				{
					["completed"] = false,
					["type"] = "monster",
					["index"] = 1,
					["total"] = 1,
					["current"] = 0,
					["text"] = "Grizzletooth slain: 0/1",
					["progressLocations"] = {
					},
					["lastText"] = "Grizzletooth slain: 0/1",
				}, -- [1]
			},
		},
		[26281] = {
			["incompleteData"] = true,
			["id"] = 26281,
			["items"] = {
			},
			["wasAlreadyAccepted"] = true,
			["name"] = "An Eternal Flame",
			["npcs"] = {
				[4200] = {
					["name"] = "Laird",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868324,
					["level"] = 14,
				},
				[6737] = {
					["name"] = "Innkeeper Shaussiy",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44.1,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868323,
					["level"] = 30,
				},
				[45038] = {
					["name"] = "Bill Wheeland",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.8,
						["x"] = 37.5,
					},
					["timestamp"] = 1756869004,
					["level"] = 12,
				},
				[2913] = {
					["name"] = "Archaeologist Hollee",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.8,
						["x"] = 37.5,
					},
					["timestamp"] = 1756869004,
					["level"] = 12,
				},
				[3701] = {
					["name"] = "Tharnariun Treetender",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 43.1,
						["x"] = 38.6,
					},
					["timestamp"] = 1756869044,
					["level"] = 18,
				},
				[6086] = {
					["name"] = "Auberdine Sentinel",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 42.9,
						["x"] = 37.5,
					},
					["level"] = 40,
					["timestamp"] = 1756868967,
				},
				[6667] = {
					["name"] = "Gelkak Gyromast",
					["zone"] = "Darkshore",
					["subzone"] = "Mist's Edge",
					["coords"] = {
						["y"] = 13.4,
						["x"] = 56.7,
					},
					["timestamp"] = 1756869840,
					["level"] = 18,
				},
				[55835] = {
					["name"] = "Bird of Prey",
					["zone"] = "Darkshore",
					["subzone"] = "Auberdine",
					["coords"] = {
						["y"] = 44,
						["x"] = 36.9,
					},
					["timestamp"] = 1756868289,
					["level"] = 13,
				},
				[2236] = {
					["name"] = "Raging Reef Crawler",
					["zone"] = "Darkshore",
					["subzone"] = "Mist's Edge",
					["coords"] = {
						["y"] = 17.8,
						["x"] = 55.7,
					},
					["timestamp"] = 1756869796,
					["level"] = 21,
				},
			},
			["sessionStart"] = "2025-09-02 23:57:48",
			["level"] = 20,
			["objects"] = {
			},
			["objectives"] = {
				{
					["lastText"] = "Eternal Ember: 1/1",
					["type"] = "item",
					["index"] = 1,
					["text"] = "Eternal Ember: 1/1",
					["progressLocations"] = {
					},
					["completed"] = 1,
					["containers"] = {
					},
					["total"] = 1,
					["current"] = 1,
				}, -- [1]
			},
		},
	},
}
