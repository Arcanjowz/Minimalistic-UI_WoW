
pfQuest_config = {
	["trackerpos"] = {
		"TOPRIGHT", -- [1]
		-20, -- [2]
		-247, -- [3]
	},
	["welcome"] = "1",
	["currentquestgivers"] = "1",
	["showclustermini"] = "0",
	["worldmapmenu"] = "1",
	["clustermono"] = "0",
	["minimapnodes"] = "1",
	["showcluster"] = "1",
	["mouseover"] = "1",
	["trackerexpand"] = "0",
	["favonlogin"] = "0",
	["minimapbutton"] = "1",
	["spawncolors"] = "0",
	["cutoutminimap"] = "1",
	["arrow"] = "1",
	["showspawnmini"] = "1",
	["showids"] = "0",
	["routeender"] = "1",
	["minimaptransp"] = "1.0",
	["nodefade"] = "0.3",
	["showhighlevel"] = "0",
	["mindropchance"] = "1",
	["routestarter"] = "0",
	["trackerlevel"] = "1",
	["questlogbuttons"] = "1",
	["worldmaptransp"] = "1.0",
	["tooltiphelp"] = "1",
	["showlowlevel"] = "0",
	["trackerfontsize"] = "12",
	["showspawn"] = "1",
	["showtooltips"] = "1",
	["trackingicons"] = "1",
	["trackeralpha"] = "0",
	["trackingmethod"] = 1,
	["showfestival"] = "0",
	["cutoutworldmap"] = "0",
	["routecluster"] = "1",
	["allquestgivers"] = "1",
	["questloglevel"] = "0",
	["showtracker"] = "1",
	["routes"] = "1",
	["routeminimap"] = "0",
	["questlinks"] = "1",
}
pfBrowser_fav = {
	["objects"] = {
	},
	["items"] = {
	},
	["quests"] = {
	},
	["units"] = {
	},
}
pfQuest_history = {
	[783] = {
		1755568506, -- [1]
		1, -- [2]
	},
	[5261] = {
		1755639034, -- [1]
		3, -- [2]
	},
}
pfQuest_colors = {
}
pfQuest_server = {
	["items"] = {
	},
}
pfQuest_track = {
}
