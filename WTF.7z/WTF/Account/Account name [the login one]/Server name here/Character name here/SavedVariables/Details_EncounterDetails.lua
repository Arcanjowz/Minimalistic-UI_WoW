
EncounterDetailsDB = {
	["encounter_spells"] = {
	},
	["emotes"] = {
	},
}
