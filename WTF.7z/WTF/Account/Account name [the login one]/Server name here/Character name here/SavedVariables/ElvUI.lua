
ElvCharacterDB = {
	["ChatEditHistory"] = {
		"/s trump on top", -- [1]
		"/qfps", -- [2]
		"/s GG", -- [3]
		"/wa", -- [4]
		"/s beatiful weapon", -- [5]
		"/s danm", -- [6]
		"/1 No Bathrans hair is working rn", -- [7]
		"/s haha", -- [8]
		"/p gg", -- [9]
		"/p gl guys", -- [10]
		"/p <3", -- [11]
		"/s gl", -- [12]
		"/thanks", -- [13]
		"/1  |cffffff00|Hquest:1016:24|h[Elemental Bracers]|h|r its bugged?", -- [14]
		"/1 I have the item, but the scroll dont work", -- [15]
		"/p im done", -- [16]
		"/p gl", -- [17]
		"/g mn, o cabeça da guild parou de jogar no epoch?", -- [18]
		"/g n entendi o ponto dele sobre o lançamento do sv pra ser sincero", -- [19]
		"/spit", -- [20]
	},
	["ChatHistoryLog"] = {
		{
			"Tank LFG ST", -- [1]
			"Mt", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Mt", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			720, -- [11]
			"0x0000000000003695", -- [12]
			0, -- [13]
			[51] = 1759101997,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dMt|r",
			["styled"] = true,
		}, -- [1]
		{
			"LF 3x DPS JED/REND + sol RUN", -- [1]
			"Asfalto", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Asfalto", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			721, -- [11]
			"0x000000000000786C", -- [12]
			0, -- [13]
			[51] = 1759102006,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffAsfalto|r",
			["styled"] = true,
		}, -- [2]
		{
			"LF one more DPS GMM", -- [1]
			"Glandore", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Glandore", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			722, -- [11]
			"0x0000000000001A3F", -- [12]
			0, -- [13]
			[51] = 1759102012,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddGlandore|r",
			["styled"] = true,
		}, -- [3]
		{
			"LF HEALS ARENA SPAM! ", -- [1]
			"Wilzyiak", -- [2]
			"", -- [3]
			"World", -- [4]
			"Wilzyiak", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			723, -- [11]
			"0x000000000002D5FF", -- [12]
			0, -- [13]
			[51] = 1759102024,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Wilzyiak",
			["styled"] = true,
		}, -- [4]
		{
			"LF1M Strat UD need tank, doing timed Baron run", -- [1]
			"Thash", -- [2]
			"", -- [3]
			"World", -- [4]
			"Thash", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			724, -- [11]
			"0x0000000000000EE0", -- [12]
			0, -- [13]
			[51] = 1759102034,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Thash",
			["styled"] = true,
		}, -- [5]
		{
			"Healer LFG GMM", -- [1]
			"Xyrelle", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Xyrelle", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			726, -- [11]
			"0x000000000001ECE5", -- [12]
			0, -- [13]
			[51] = 1759102034,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aXyrelle|r",
			["styled"] = true,
		}, -- [6]
		{
			"Healer LFG SM-Cath", -- [1]
			"Kalvhin", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kalvhin", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			727, -- [11]
			"0x0000000000056EF2", -- [12]
			0, -- [13]
			[51] = 1759102034,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaKalvhin|r",
			["styled"] = true,
		}, -- [7]
		{
			"where is this turned in? |cffff2020|Hquest:26320:60|h[A Legacy of Knowledge]|h|r |cffff2020|Hquest:6133:60|h[The Ranger Lord's Behest]|h|r", -- [1]
			"Ashwyn", -- [2]
			"", -- [3]
			"World", -- [4]
			"Ashwyn", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			728, -- [11]
			"0x00000000000039E4", -- [12]
			0, -- [13]
			[51] = 1759102034,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Ashwyn",
			["styled"] = true,
		}, -- [8]
		{
			"LF1M RFK", -- [1]
			"Omnipotent", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Omnipotent", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			729, -- [11]
			"0x000000000003BC4C", -- [12]
			0, -- [13]
			[51] = 1759102040,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dOmnipotent|r",
			["styled"] = true,
		}, -- [9]
		{
			"|cffFFFF00Cizieg has reached level 20 with a Soul of Iron.|r", -- [1]
			"", -- [2]
			"", -- [3]
			"Challenges", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			731, -- [11]
			"", -- [12]
			0, -- [13]
			[51] = 1759102058,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "",
			["styled"] = true,
		}, -- [10]
		{
			"|cffFFFF00Cizieg has reached level 20 with an Explorer's Contract.|r", -- [1]
			"", -- [2]
			"", -- [3]
			"Challenges", -- [4]
			"", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			732, -- [11]
			"", -- [12]
			0, -- [13]
			[51] = 1759102058,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "",
			["styled"] = true,
		}, -- [11]
		{
			"{Star} LFW |cffffd000|Htrade:13920:300:300:11B7E:4D|h[Enchanting]|h|r; Crusader/Fiery/Panacea/Swashbuckler/Unholy/Icy/Elusive/Agi/Strength/Spirit Weapon & many more! Your mats&fee (can ench horde in BB) {Star}", -- [1]
			"Yui", -- [2]
			"", -- [3]
			"World", -- [4]
			"Yui", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			733, -- [11]
			"0x0000000000011B7E", -- [12]
			0, -- [13]
			[51] = 1759102058,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Yui",
			["styled"] = true,
		}, -- [12]
		{
			"LF1m healer scholo", -- [1]
			"Brem", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Brem", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			734, -- [11]
			"0x0000000000005223", -- [12]
			0, -- [13]
			[51] = 1759102058,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaBrem|r",
			["styled"] = true,
		}, -- [13]
		{
			"LF 2x DPS JED/REND + SOL RUN (pref casters)", -- [1]
			"Asfalto", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Asfalto", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			736, -- [11]
			"0x000000000000786C", -- [12]
			0, -- [13]
			[51] = 1759102060,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffAsfalto|r",
			["styled"] = true,
		}, -- [14]
		{
			"LF2M UBRS 1 DPS 1 Healer, We have seals!", -- [1]
			"Frankietanky", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Frankietanky", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			737, -- [11]
			"0x00000000000003F7", -- [12]
			0, -- [13]
			[51] = 1759102070,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaFrankietanky|r",
			["styled"] = true,
		}, -- [15]
		{
			"LF1M Strat UD need tank, doing timed Baron run", -- [1]
			"Thash", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Thash", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			739, -- [11]
			"0x0000000000000EE0", -- [12]
			0, -- [13]
			[51] = 1759102070,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefThash|r",
			["styled"] = true,
		}, -- [16]
		{
			"gz cizi", -- [1]
			"Soner", -- [2]
			"", -- [3]
			"World", -- [4]
			"Soner", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			740, -- [11]
			"0x000000000005AF1F", -- [12]
			0, -- [13]
			[51] = 1759102070,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Soner",
			["styled"] = true,
		}, -- [17]
		{
			"LF Healer Mara, Celebras-Princess pst!", -- [1]
			"Megameat", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Megameat", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			742, -- [11]
			"0x000000000004DCD2", -- [12]
			0, -- [13]
			[51] = 1759102070,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aMegameat|r",
			["styled"] = true,
		}, -- [18]
		{
			"LF1M SCHOLO - HEALER", -- [1]
			"Kfcmanager", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kfcmanager", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			743, -- [11]
			"0x0000000000000AF2", -- [12]
			0, -- [13]
			[51] = 1759102077,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddKfcmanager|r",
			["styled"] = true,
		}, -- [19]
		{
			"da bears", -- [1]
			"Rizzo", -- [2]
			"", -- [3]
			"World", -- [4]
			"Rizzo", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			745, -- [11]
			"0x00000000000031E2", -- [12]
			0, -- [13]
			[51] = 1759102078,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Rizzo",
			["styled"] = true,
		}, -- [20]
		{
			"DPS LFG GM", -- [1]
			"Melstar", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Melstar", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			746, -- [11]
			"0x000000000004C75D", -- [12]
			0, -- [13]
			[51] = 1759102083,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Melstar|r",
			["styled"] = true,
		}, -- [21]
		{
			"daaaa Bears", -- [1]
			"Tankhill", -- [2]
			"", -- [3]
			"World", -- [4]
			"Tankhill", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			748, -- [11]
			"0x000000000000818A", -- [12]
			0, -- [13]
			[51] = 1759102088,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Tankhill",
			["styled"] = true,
		}, -- [22]
		{
			"LF HEALER SCHOLOMANCE SKIP RUNS", -- [1]
			"Perkyz", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Perkyz", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			750, -- [11]
			"0x0000000000028C92", -- [12]
			0, -- [13]
			[51] = 1759102093,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefPerkyz|r",
			["styled"] = true,
		}, -- [23]
		{
			"Still suck", -- [1]
			"Walcanar", -- [2]
			"", -- [3]
			"World", -- [4]
			"Walcanar", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			751, -- [11]
			"0x0000000000057AA6", -- [12]
			0, -- [13]
			[51] = 1759102096,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Walcanar",
			["styled"] = true,
		}, -- [24]
		{
			"W", -- [1]
			"Rizzo", -- [2]
			"", -- [3]
			"World", -- [4]
			"Rizzo", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			753, -- [11]
			"0x00000000000031E2", -- [12]
			0, -- [13]
			[51] = 1759102104,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Rizzo",
			["styled"] = true,
		}, -- [25]
		{
			"===Healer lfg |cffffff00|Hachievement:634:0000000000004F8B:0:0:0:-1:0:0:0:0|h[Gnomeregan]|h|r |cffffff00|Hachievement:635:0000000000004F8B:0:0:0:-1:0:0:0:0|h[Razorfen Kraul]|h|r", -- [1]
			"Icyhammer", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Icyhammer", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			754, -- [11]
			"0x0000000000004F8B", -- [12]
			0, -- [13]
			[51] = 1759102113,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaIcyhammer|r",
			["styled"] = true,
		}, -- [26]
		{
			"LFM || BH || Tank last spot", -- [1]
			"Cantstop", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Cantstop", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			756, -- [11]
			"0x000000000001E1CB", -- [12]
			0, -- [13]
			[51] = 1759102122,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aCantstop|r",
			["styled"] = true,
		}, -- [27]
		{
			"Healer LFG GMM", -- [1]
			"Xyrelle", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Xyrelle", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			757, -- [11]
			"0x000000000001ECE5", -- [12]
			0, -- [13]
			[51] = 1759102134,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aXyrelle|r",
			["styled"] = true,
		}, -- [28]
		{
			"are those |cffff2020|Hquest:2284:41|h[Necklace Recovery, Take 2]|h|r |cffff2020|Hquest:2342:43|h[Reclaimed Treasures]|h|rin or out dung?", -- [1]
			"Zkurwilka", -- [2]
			"", -- [3]
			"World", -- [4]
			"Zkurwilka", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			758, -- [11]
			"0x000000000005297B", -- [12]
			0, -- [13]
			[51] = 1759102135,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Zkurwilka",
			["styled"] = true,
		}, -- [29]
		{
			"LF1M Strat UD need tank, doing timed Baron run", -- [1]
			"Thash", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Thash", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			759, -- [11]
			"0x0000000000000EE0", -- [12]
			0, -- [13]
			[51] = 1759102135,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefThash|r",
			["styled"] = true,
		}, -- [30]
		{
			"DA BEARSSSS", -- [1]
			"Senseitrunks", -- [2]
			"", -- [3]
			"World", -- [4]
			"Senseitrunks", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			761, -- [11]
			"0x000000000002EFBD", -- [12]
			0, -- [13]
			[51] = 1759102140,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Senseitrunks",
			["styled"] = true,
		}, -- [31]
		{
			"LF 2x DPS JED/REND + SOL RUN (pref casters)", -- [1]
			"Asfalto", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Asfalto", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			762, -- [11]
			"0x000000000000786C", -- [12]
			0, -- [13]
			[51] = 1759102141,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffAsfalto|r",
			["styled"] = true,
		}, -- [32]
		{
			"LF1M SCHOLO - HEALER", -- [1]
			"Kfcmanager", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kfcmanager", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			763, -- [11]
			"0x0000000000000AF2", -- [12]
			0, -- [13]
			[51] = 1759102142,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddKfcmanager|r",
			["styled"] = true,
		}, -- [33]
		{
			"LF2M Ulda - dps/heal", -- [1]
			"Beefyboy", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Beefyboy", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			765, -- [11]
			"0x000000000001DC1F", -- [12]
			0, -- [13]
			[51] = 1759102146,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dBeefyboy|r",
			["styled"] = true,
		}, -- [34]
		{
			"LF1M Healer UBRS, We have seals!", -- [1]
			"Frankietanky", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Frankietanky", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			766, -- [11]
			"0x00000000000003F7", -- [12]
			0, -- [13]
			[51] = 1759102147,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaFrankietanky|r",
			["styled"] = true,
		}, -- [35]
		{
			"DPS/TANK LF WC", -- [1]
			"Gooeybutt", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Gooeybutt", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			767, -- [11]
			"0x0000000000059B15", -- [12]
			0, -- [13]
			[51] = 1759102147,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aGooeybutt|r",
			["styled"] = true,
		}, -- [36]
		{
			"LF1m healer scholo", -- [1]
			"Brem", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Brem", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			768, -- [11]
			"0x0000000000005223", -- [12]
			0, -- [13]
			[51] = 1759102151,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaBrem|r",
			["styled"] = true,
		}, -- [37]
		{
			"LFM for ST, need heals and DPS", -- [1]
			"Mt", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Mt", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			769, -- [11]
			"0x0000000000003695", -- [12]
			0, -- [13]
			[51] = 1759102152,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dMt|r",
			["styled"] = true,
		}, -- [38]
		{
			"The block was HUGE", -- [1]
			"Xorrus", -- [2]
			"", -- [3]
			"World", -- [4]
			"Xorrus", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			770, -- [11]
			"0x0000000000003B35", -- [12]
			0, -- [13]
			[51] = 1759102153,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Xorrus",
			["styled"] = true,
		}, -- [39]
		{
			"Mike Ditka vs Lich king", -- [1]
			"Brewlight", -- [2]
			"", -- [3]
			"World", -- [4]
			"Brewlight", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			771, -- [11]
			"0x000000000005B249", -- [12]
			0, -- [13]
			[51] = 1759102156,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Brewlight",
			["styled"] = true,
		}, -- [40]
		{
			"LF1M Scholo need heal", -- [1]
			"Tommyy", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Tommyy", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			772, -- [11]
			"0x000000000002C691", -- [12]
			0, -- [13]
			[51] = 1759102159,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dTommyy|r",
			["styled"] = true,
		}, -- [41]
		{
			"LF HEALER SCHOLOMANCE SKIP RUNS", -- [1]
			"Perkyz", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Perkyz", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			773, -- [11]
			"0x0000000000028C92", -- [12]
			0, -- [13]
			[51] = 1759102160,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefPerkyz|r",
			["styled"] = true,
		}, -- [42]
		{
			"Healer LFG SM-Cath", -- [1]
			"Kalvhin", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kalvhin", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			775, -- [11]
			"0x0000000000056EF2", -- [12]
			0, -- [13]
			[51] = 1759102166,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaKalvhin|r",
			["styled"] = true,
		}, -- [43]
		{
			"hell yea id rather that than hope for a drive for a fg", -- [1]
			"Senseitrunks", -- [2]
			"", -- [3]
			"World", -- [4]
			"Senseitrunks", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			779, -- [11]
			"0x000000000002EFBD", -- [12]
			0, -- [13]
			[51] = 1759102174,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Senseitrunks",
			["styled"] = true,
		}, -- [44]
		{
			"LF2M need HEAL and DPS for BRD EMP farm open roll on IF HoJ res", -- [1]
			"Joeychips", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Joeychips", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			780, -- [11]
			"0x000000000001E737", -- [12]
			0, -- [13]
			[51] = 1759102187,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dJoeychips|r",
			["styled"] = true,
		}, -- [45]
		{
			"LF 2x DPS JED/REND + SOL RUN (pref casters)", -- [1]
			"Asfalto", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Asfalto", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			781, -- [11]
			"0x000000000000786C", -- [12]
			0, -- [13]
			[51] = 1759102193,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffAsfalto|r",
			["styled"] = true,
		}, -- [46]
		{
			"[Aube] Premier roster en construction – recherche Heal (Paladin / Prêtre / Chaman). Guilde conviviale & sérieuse, objectif progress HL. /w pour + d’infos !", -- [1]
			"Lazarglace", -- [2]
			"", -- [3]
			"World", -- [4]
			"Lazarglace", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			782, -- [11]
			"0x00000000000078FC", -- [12]
			0, -- [13]
			[51] = 1759102195,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Lazarglace",
			["styled"] = true,
		}, -- [47]
		{
			"<Figuring It Out As We Go> is now recruiting! Currently a leveling guild working towards building a raid team. Join a relaxed but efficient raid environment with experienced leads to guide you through! Participate in group PVP and other guild events.", -- [1]
			"Rythann", -- [2]
			"", -- [3]
			"World", -- [4]
			"Rythann", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			783, -- [11]
			"0x0000000000022785", -- [12]
			0, -- [13]
			[51] = 1759102195,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Rythann",
			["styled"] = true,
		}, -- [48]
		{
			"DPS LFG GM", -- [1]
			"Melstar", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Melstar", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			784, -- [11]
			"0x000000000004C75D", -- [12]
			0, -- [13]
			[51] = 1759102196,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfffff468Melstar|r",
			["styled"] = true,
		}, -- [49]
		{
			"heals lfg ud strat must do pallid/live strat must summon t0.5/ubrs must do solakar/scholo gandling only/bh // lf enchanter 22 int", -- [1]
			"Sillplain", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Sillplain", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			785, -- [11]
			"0x0000000000002643", -- [12]
			0, -- [13]
			[51] = 1759102199,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffSillplain|r",
			["styled"] = true,
		}, -- [50]
		{
			"Ditka is weilding a prok chop and takes the Lich King down", -- [1]
			"Tankhill", -- [2]
			"", -- [3]
			"World", -- [4]
			"Tankhill", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			786, -- [11]
			"0x000000000000818A", -- [12]
			0, -- [13]
			[51] = 1759102200,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Tankhill",
			["styled"] = true,
		}, -- [51]
		{
			"LFM GMM 3 dps", -- [1]
			"Xyrelle", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Xyrelle", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			787, -- [11]
			"0x000000000001ECE5", -- [12]
			0, -- [13]
			[51] = 1759102204,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aXyrelle|r",
			["styled"] = true,
		}, -- [52]
		{
			"DPS/TANK LF WC", -- [1]
			"Gooeybutt", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Gooeybutt", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			788, -- [11]
			"0x0000000000059B15", -- [12]
			0, -- [13]
			[51] = 1759102205,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aGooeybutt|r",
			["styled"] = true,
		}, -- [53]
		{
			"{star}Ethically Sourced Degens{star} Recruiting for raids and general nonsense. Come have a great time and develop a bad sleep schedule. Casual/social guild. Ethically Sourced, questionably sane. DM if interested.", -- [1]
			"Ayame", -- [2]
			"", -- [3]
			"World", -- [4]
			"Ayame", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			789, -- [11]
			"0x00000000000008DF", -- [12]
			0, -- [13]
			[51] = 1759102209,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Ayame",
			["styled"] = true,
		}, -- [54]
		{
			"LF2m dps/heal for Uldaman", -- [1]
			"Beefyboy", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Beefyboy", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			790, -- [11]
			"0x000000000001DC1F", -- [12]
			0, -- [13]
			[51] = 1759102209,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dBeefyboy|r",
			["styled"] = true,
		}, -- [55]
		{
			"LF1M Strat UD need tank, doing timed Baron run", -- [1]
			"Thash", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Thash", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			791, -- [11]
			"0x0000000000000EE0", -- [12]
			0, -- [13]
			[51] = 1759102211,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefThash|r",
			["styled"] = true,
		}, -- [56]
		{
			"Healer LFG SM-Cath", -- [1]
			"Kalvhin", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kalvhin", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			792, -- [11]
			"0x0000000000056EF2", -- [12]
			0, -- [13]
			[51] = 1759102212,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaKalvhin|r",
			["styled"] = true,
		}, -- [57]
		{
			"LF2M need HEAL and DPS for BRD EMP farm open roll on IF", -- [1]
			"Joeychips", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Joeychips", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			794, -- [11]
			"0x000000000001E737", -- [12]
			0, -- [13]
			[51] = 1759102215,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dJoeychips|r",
			["styled"] = true,
		}, -- [58]
		{
			"LF Healer Mara, Celebras-Princess pst!", -- [1]
			"Megameat", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Megameat", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			795, -- [11]
			"0x000000000004DCD2", -- [12]
			0, -- [13]
			[51] = 1759102229,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aMegameat|r",
			["styled"] = true,
		}, -- [59]
		{
			"LF1m healer scholo", -- [1]
			"Brem", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Brem", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			796, -- [11]
			"0x0000000000005223", -- [12]
			0, -- [13]
			[51] = 1759102230,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaBrem|r",
			["styled"] = true,
		}, -- [60]
		{
			"LF2M for Uldaman - dps/heal", -- [1]
			"Beefyboy", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Beefyboy", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			797, -- [11]
			"0x000000000001DC1F", -- [12]
			0, -- [13]
			[51] = 1759102232,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dBeefyboy|r",
			["styled"] = true,
		}, -- [61]
		{
			"LF 2x DPS JED/REND + SOL RUN (pref casters)", -- [1]
			"Asfalto", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Asfalto", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			798, -- [11]
			"0x000000000000786C", -- [12]
			0, -- [13]
			[51] = 1759102235,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffAsfalto|r",
			["styled"] = true,
		}, -- [62]
		{
			"LF1M SCHOLO - HEALER", -- [1]
			"Kfcmanager", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kfcmanager", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			800, -- [11]
			"0x0000000000000AF2", -- [12]
			0, -- [13]
			[51] = 1759102239,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddKfcmanager|r",
			["styled"] = true,
		}, -- [63]
		{
			"LFM || BH || Tank last spot", -- [1]
			"Cantstop", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Cantstop", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			802, -- [11]
			"0x000000000001E1CB", -- [12]
			0, -- [13]
			[51] = 1759102242,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aCantstop|r",
			["styled"] = true,
		}, -- [64]
		{
			"anyone selling Warden Staff", -- [1]
			"Hakuji", -- [2]
			"", -- [3]
			"World", -- [4]
			"Hakuji", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			803, -- [11]
			"0x0000000000058BAD", -- [12]
			0, -- [13]
			[51] = 1759102250,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Hakuji",
			["styled"] = true,
		}, -- [65]
		{
			"LF1M Strat UD need tank, doing timed Baron run", -- [1]
			"Thash", -- [2]
			"", -- [3]
			"World", -- [4]
			"Thash", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			804, -- [11]
			"0x0000000000000EE0", -- [12]
			0, -- [13]
			[51] = 1759102250,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Thash",
			["styled"] = true,
		}, -- [66]
		{
			"War dps /Tank LF Brd arena ", -- [1]
			"Mostralata", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Mostralata", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			806, -- [11]
			"0x0000000000000787", -- [12]
			0, -- [13]
			[51] = 1759102258,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dMostralata|r",
			["styled"] = true,
		}, -- [67]
		{
			"One trick you can do is instead of buying finger cots, just tear the individual fingers off of latex gloves. You can then wear the glove finger on your index and use it to apply the preparation H, it saves a ton of money.", -- [1]
			"Jakewell", -- [2]
			"", -- [3]
			"World", -- [4]
			"Jakewell", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			807, -- [11]
			"0x000000000001F9D6", -- [12]
			0, -- [13]
			[51] = 1759102260,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Jakewell",
			["styled"] = true,
		}, -- [68]
		{
			"LF1M for RFK!", -- [1]
			"Terrabella", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Terrabella", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			808, -- [11]
			"0x0000000000024457", -- [12]
			0, -- [13]
			[51] = 1759102263,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddTerrabella|r",
			["styled"] = true,
		}, -- [69]
		{
			"Healer LFG SM-Cath", -- [1]
			"Kalvhin", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kalvhin", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			809, -- [11]
			"0x0000000000056EF2", -- [12]
			0, -- [13]
			[51] = 1759102266,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaKalvhin|r",
			["styled"] = true,
		}, -- [70]
		{
			"LF 2x DPS JED/REND + SOL RUN (pref casters)", -- [1]
			"Asfalto", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Asfalto", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			810, -- [11]
			"0x000000000000786C", -- [12]
			0, -- [13]
			[51] = 1759102269,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffAsfalto|r",
			["styled"] = true,
		}, -- [71]
		{
			"LF1M SCHOLO - HEALER", -- [1]
			"Kfcmanager", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Kfcmanager", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			811, -- [11]
			"0x0000000000000AF2", -- [12]
			0, -- [13]
			[51] = 1759102277,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddKfcmanager|r",
			["styled"] = true,
		}, -- [72]
		{
			"{star} <Selfless> EU is looking for players interested in racing content on release. Our leadership comes from R1 Classic RWF/Speedrun experience. Apply here: https://discord.gg/e8EUNAGGa8", -- [1]
			"Getmilkhere", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Getmilkhere", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			813, -- [11]
			"0x0000000000018409", -- [12]
			0, -- [13]
			[51] = 1759102284,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaGetmilkhere|r",
			["styled"] = true,
		}, -- [73]
		{
			"DPS/TANK LF WC", -- [1]
			"Gooeybutt", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Gooeybutt", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			814, -- [11]
			"0x0000000000059B15", -- [12]
			0, -- [13]
			[51] = 1759102284,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffff7c0aGooeybutt|r",
			["styled"] = true,
		}, -- [74]
		{
			"LF1m healer scholo", -- [1]
			"Brem", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Brem", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			815, -- [11]
			"0x0000000000005223", -- [12]
			0, -- [13]
			[51] = 1759102295,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaBrem|r",
			["styled"] = true,
		}, -- [75]
		{
			"LF1M Healer UBRS, We have seals!", -- [1]
			"Frankietanky", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Frankietanky", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			816, -- [11]
			"0x00000000000003F7", -- [12]
			0, -- [13]
			[51] = 1759102297,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaFrankietanky|r",
			["styled"] = true,
		}, -- [76]
		{
			"thxs", -- [1]
			"Beltedorange", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Beltedorange", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			6, -- [11]
			"0x000000000005095E", -- [12]
			0, -- [13]
			[51] = 1759116140,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffaad372Beltedorange|r",
		}, -- [77]
		{
			"LF3M Heals/DPS for UBRS speed runs (Rend+drakk only). PST", -- [1]
			"Xachiuitl", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Xachiuitl", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			7, -- [11]
			"0x000000000002ACD8", -- [12]
			0, -- [13]
			[51] = 1759116145,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaXachiuitl|r",
		}, -- [78]
		{
			"heals lfg ud strat must do pallid/live strat must summon t0.5/ubrs must do solakar/scholo gandling only/bh // lf enchanter 22 int", -- [1]
			"Sillplain", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Sillplain", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			8, -- [11]
			"0x0000000000002643", -- [12]
			0, -- [13]
			[51] = 1759116147,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffffffffSillplain|r",
		}, -- [79]
		{
			"LF Enchanter to stay in group for D/E please", -- [1]
			"Gopnik", -- [2]
			"", -- [3]
			"World", -- [4]
			"Gopnik", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			12, -- [11]
			"0x000000000002DC7D", -- [12]
			0, -- [13]
			[51] = 1759116177,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Gopnik",
		}, -- [80]
		{
			"LF tank for GMM", -- [1]
			"Hellah", -- [2]
			"", -- [3]
			"World", -- [4]
			"Hellah", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			13, -- [11]
			"0x00000000000085DE", -- [12]
			0, -- [13]
			[51] = 1759116177,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Hellah",
		}, -- [81]
		{
			"where tf is paula |cffff2020|Hquest:26570:37|h[Waterlogged Journal]|h|r", -- [1]
			"Mescaline", -- [2]
			"", -- [3]
			"World", -- [4]
			"Mescaline", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			14, -- [11]
			"0x0000000000029FE6", -- [12]
			0, -- [13]
			[51] = 1759116179,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Mescaline",
		}, -- [82]
		{
			"LF2M Heals/DPS for UBRS speed runs (Rend+drakk only). PST", -- [1]
			"Xachiuitl", -- [2]
			"", -- [3]
			"World", -- [4]
			"Xachiuitl", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			16, -- [11]
			"0x000000000002ACD8", -- [12]
			0, -- [13]
			[51] = 1759116182,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Xachiuitl",
		}, -- [83]
		{
			"plinglebob", -- [1]
			"Spikeynihh", -- [2]
			"", -- [3]
			"World", -- [4]
			"Spikeynihh", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			18, -- [11]
			"0x0000000000027A69", -- [12]
			0, -- [13]
			[51] = 1759116185,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Spikeynihh",
		}, -- [84]
		{
			"any cuties starting deamines?", -- [1]
			"Fridakahlo", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Fridakahlo", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			19, -- [11]
			"0x0000000000058A34", -- [12]
			0, -- [13]
			[51] = 1759116189,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaFridakahlo|r",
		}, -- [85]
		{
			"LF1M Tank GMM", -- [1]
			"Cromgol", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Cromgol", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			21, -- [11]
			"0x000000000000E862", -- [12]
			0, -- [13]
			[51] = 1759116190,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddCromgol|r",
		}, -- [86]
		{
			"lf3m ZF", -- [1]
			"Krockaw", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Krockaw", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			23, -- [11]
			"0x000000000004B03E", -- [12]
			0, -- [13]
			[51] = 1759116226,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dKrockaw|r",
		}, -- [87]
		{
			"LF1M RFK any role", -- [1]
			"Thwak", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Thwak", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			24, -- [11]
			"0x0000000000054F01", -- [12]
			0, -- [13]
			[51] = 1759116239,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddThwak|r",
		}, -- [88]
		{
			"LF1M - ST - heals - have egg", -- [1]
			"Karava", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Karava", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			25, -- [11]
			"0x000000000002EC42", -- [12]
			0, -- [13]
			[51] = 1759116244,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaKarava|r",
		}, -- [89]
		{
			"LF tank for GMM", -- [1]
			"Hellah", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Hellah", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			31, -- [11]
			"0x00000000000085DE", -- [12]
			0, -- [13]
			[51] = 1759116250,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff9382c9Hellah|r",
		}, -- [90]
		{
			"LF1M Heals for UBRS speed runs (Rend+drakk only). PST", -- [1]
			"Xachiuitl", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Xachiuitl", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			32, -- [11]
			"0x000000000002ACD8", -- [12]
			0, -- [13]
			[51] = 1759116252,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaXachiuitl|r",
		}, -- [91]
		{
			"LF1M Healer ST", -- [1]
			"Ginntonic", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Ginntonic", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			40, -- [11]
			"0x000000000000ADE2", -- [12]
			0, -- [13]
			[51] = 1759116290,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefGinntonic|r",
		}, -- [92]
		{
			"LF2M Tank/DPS GMM", -- [1]
			"Cromgol", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Cromgol", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			41, -- [11]
			"0x000000000000E862", -- [12]
			0, -- [13]
			[51] = 1759116301,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff0070ddCromgol|r",
		}, -- [93]
		{
			"lf2m ZF, need heal", -- [1]
			"Krockaw", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Krockaw", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			42, -- [11]
			"0x000000000004B03E", -- [12]
			0, -- [13]
			[51] = 1759116317,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dKrockaw|r",
		}, -- [94]
		{
			"LF1M - ST - heals - have egg", -- [1]
			"Karava", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Karava", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			43, -- [11]
			"0x000000000002EC42", -- [12]
			0, -- [13]
			[51] = 1759116318,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaKarava|r",
		}, -- [95]
		{
			"LFM UBRS rend run need heal!", -- [1]
			"Coraorao", -- [2]
			"", -- [3]
			"World", -- [4]
			"Coraorao", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			44, -- [11]
			"0x0000000000031AA9", -- [12]
			0, -- [13]
			[51] = 1759116345,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Coraorao",
		}, -- [96]
		{
			"LF Emporer farm group", -- [1]
			"Icebane", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Icebane", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			45, -- [11]
			"0x00000000000547BB", -- [12]
			0, -- [13]
			[51] = 1759116371,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cff68ccefIcebane|r",
		}, -- [97]
		{
			"LF1M - ST - heals - have egg", -- [1]
			"Karava", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Karava", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			46, -- [11]
			"0x000000000002EC42", -- [12]
			0, -- [13]
			[51] = 1759116384,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cfff48cbaKarava|r",
		}, -- [98]
		{
			"LF3M - Tank/Heal/Pet puller. emp runs", -- [1]
			"Ringer", -- [2]
			"", -- [3]
			"4. LookingForGroup", -- [4]
			"Ringer", -- [5]
			"", -- [6]
			26, -- [7]
			4, -- [8]
			"LookingForGroup", -- [9]
			0, -- [10]
			51, -- [11]
			"0x0000000000029FAC", -- [12]
			0, -- [13]
			[51] = 1759116431,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "|cffc69b6dRinger|r",
		}, -- [99]
		{
			"LFM UBRS rend run need heal!", -- [1]
			"Coraorao", -- [2]
			"", -- [3]
			"World", -- [4]
			"Coraorao", -- [5]
			"", -- [6]
			0, -- [7]
			0, -- [8]
			"", -- [9]
			0, -- [10]
			52, -- [11]
			"0x0000000000031AA9", -- [12]
			0, -- [13]
			[51] = 1759116432,
			[50] = "CHAT_MSG_CHANNEL",
			[52] = "Coraorao",
		}, -- [100]
	},
}
