
PawnOptions = {
	["LastPlayerFullName"] = "Arcanjo-Kezan",
	["LastKeybindingsSet"] = 1,
}
PawnWowheadScaleProviderOptions = {
	["LastAdded"] = 2,
}
