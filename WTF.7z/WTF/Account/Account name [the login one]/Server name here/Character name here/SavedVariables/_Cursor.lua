
_CursorOptionsCharacter = {
	["Cursors"] = {
		{
			["Enabled"] = true,
			["Type"] = "Trail",
			["Name"] = "Layer 1",
			["Scale"] = 0.5,
			["Value"] = "Souls, small",
			["Strata"] = "TOOLTIP",
		}, -- [1]
		{
			["Enabled"] = true,
			["Strata"] = "FULLSCREEN_DIALOG",
			["Name"] = "Layer 2",
			["Value"] = "Shadow cloud",
			["Type"] = "Particle",
		}, -- [2]
		{
			["Enabled"] = false,
			["Strata"] = "FULLSCREEN_DIALOG",
			["Name"] = "Layer 3",
			["Value"] = "",
			["Type"] = "",
		}, -- [3]
	},
	["Version"] = "3.3.0.2",
}
